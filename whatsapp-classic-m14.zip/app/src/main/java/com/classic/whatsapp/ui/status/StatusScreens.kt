package com.classic.whatsapp.ui.status

import android.net.Uri
import android.view.LayoutInflater
import android.widget.Toast
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.draw.alpha
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import com.classic.whatsapp.ClassicApp
import com.classic.whatsapp.R
import com.classic.whatsapp.STATUS_CHAT
import com.classic.whatsapp.data.MessageEntity
import com.classic.whatsapp.ui.conversation.rememberBitmap
import com.classic.whatsapp.ui.formatTime
import java.io.File
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/**
 * Full-screen status viewer. No timer: a status stays until you tap Next (right side; left side = previous).
 * Opening starts at the oldest unread status of the person (else their oldest); Next past the last status goes on to
 * the next person with unread statuses, in the order of the status strip, within the same session. The reply bar is
 * hidden until you swipe up (swipe down hides it again). Long text is cut at three lines; tap it or swipe up to read
 * all of it over the media.
 */
@Composable
fun StatusViewerScreen(senderId: String, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val app = ctx.applicationContext as ClassicApp
    val repo = app.repo
    val scope = rememberCoroutineScope()
    val all by repo.statuses().collectAsState(initial = null as List<MessageEntity>?)
    var poster by remember { mutableStateOf(senderId) }
    var index by remember(poster) { mutableStateOf<Int?>(null) }
    var reply by remember { mutableStateOf("") }
    var replyVisible by remember { mutableStateOf(false) }
    var expanded by remember { mutableStateOf(false) }
    var truncated by remember { mutableStateOf(false) }
    val foreground by repo.foreground.collectAsState()

    val list = all
    if (list == null) {
        Box(Modifier.fillMaxSize().background(Color.Black))
        return
    }

    // People to go through in this session, fixed when the viewer opens: this person first, then everyone else who
    // still has unread statuses (same order as the strip: newest first).
    val queue = remember(list.isEmpty()) {
        val unread = list.groupBy { it.senderId }
            .filter { (_, v) -> v.any { !it.fromMe && !it.incomingRead } }
            .entries.sortedByDescending { e -> e.value.maxOf { it.timestamp } }
            .map { it.key }
        listOf(senderId) + unread.filter { it != senderId }
    }

    val items = list.filter { it.senderId == poster }
    if (items.isEmpty()) {
        LaunchedEffect(poster) { onBack() }
        return
    }
    // First unread status of this person when they are opened (their oldest if they are all read).
    val start = remember(poster, items.isEmpty()) {
        items.indexOfFirst { !it.fromMe && !it.incomingRead }.takeIf { it >= 0 } ?: 0
    }
    val i = (index ?: start).coerceIn(0, items.lastIndex)
    val m = items[i]

    fun next() {
        if (i < items.lastIndex) {
            index = i + 1
        } else {
            val nextPoster = queue.getOrNull(queue.indexOf(poster) + 1)
            if (nextPoster != null) poster = nextPoster else onBack()
        }
    }
    fun prev() { if (i > 0) index = i - 1 }

    // Fetch the media and tell the poster we viewed it (if read receipts are on).
    LaunchedEffect(m.messageId) {
        if ((m.kind == "image" || m.kind == "video" || m.kind == "audio") && m.mediaPath.isBlank()) repo.downloadMedia(STATUS_CHAT, m.messageId)
        repo.markStatusViewed(m)
    }
    // A new status starts collapsed with the reply bar hidden.
    LaunchedEffect(m.messageId) {
        expanded = false
        replyVisible = false
    }

    val isTextOnly = m.kind == "text"
    val caption = m.text
    val density = LocalDensity.current
    val swipeThreshold = with(density) { 60.dp.toPx() }

    Box(Modifier.fillMaxSize().background(Color.Black).statusBarsPadding().imePadding()) {
        Column(Modifier.fillMaxSize()) {
            // Media area: never covered by the caption (the caption sits below it).
            Box(
                Modifier.weight(1f).fillMaxWidth()
                    .pointerInput(m.messageId, replyVisible, expanded) {
                        detectTapGestures { offset ->
                            when {
                                expanded -> expanded = false
                                replyVisible -> replyVisible = false
                                offset.x < size.width / 3f -> prev()
                                else -> next()
                            }
                        }
                    }
                    .pointerInput(m.messageId) {
                        var total = 0f
                        detectVerticalDragGestures(
                            onDragStart = { total = 0f },
                            onDragEnd = {
                                if (total < -swipeThreshold) {
                                    replyVisible = !m.fromMe
                                    if (truncated && caption.isNotBlank()) expanded = true
                                } else if (total > swipeThreshold) {
                                    expanded = false
                                    replyVisible = false
                                }
                            },
                            onVerticalDrag = { _, dy -> total += dy },
                        )
                    },
                contentAlignment = Alignment.Center,
            ) {
                when (m.kind) {
                    "image" -> {
                        val bmp = rememberBitmap(if (m.mediaPath.isNotBlank()) m.mediaPath else m.thumbPath, 1600)
                        if (bmp != null) Image(bmp, contentDescription = null, contentScale = ContentScale.Fit, modifier = Modifier.fillMaxSize())
                        if (m.mediaPath.isBlank()) CircularProgressIndicator()
                    }
                    "video" -> if (m.mediaPath.isNotBlank()) {
                        key(m.messageId) { VideoStatus(m.mediaPath, paused = !foreground || reply.isNotBlank(), onDone = {}) }
                    } else {
                        val bmp = rememberBitmap(m.thumbPath, 800)
                        if (bmp != null) Image(bmp, contentDescription = null, contentScale = ContentScale.Fit, modifier = Modifier.fillMaxSize())
                        CircularProgressIndicator()
                    }
                    "audio" -> {
                        if (m.mediaPath.isNotBlank()) {
                            key(m.messageId) { VideoStatus(m.mediaPath, paused = !foreground || reply.isNotBlank(), onDone = {}) }
                        } else {
                            CircularProgressIndicator()
                        }
                        Text(
                            "Voice status" + if (m.durationSecs > 0) " · ${formatDuration(m.durationSecs)}" else "",
                            color = Color.White,
                            style = MaterialTheme.typography.titleMedium,
                        )
                    }
                    "viewonce" -> Text("View-once status. Open it on your phone.", color = Color.White, modifier = Modifier.padding(24.dp))
                    else -> Text(
                        caption,
                        color = Color.White,
                        style = MaterialTheme.typography.headlineSmall,
                        textAlign = TextAlign.Center,
                        maxLines = 3,
                        overflow = TextOverflow.Ellipsis,
                        onTextLayout = { truncated = it.hasVisualOverflow },
                        modifier = Modifier.padding(24.dp).clickable(enabled = truncated && !expanded) { expanded = true },
                    )
                }

                // Full text over the media.
                if (expanded && caption.isNotBlank()) {
                    Box(
                        Modifier.align(Alignment.BottomCenter).fillMaxWidth().fillMaxHeight(0.7f)
                            .background(Color.Black.copy(alpha = 0.8f))
                            .clickable { expanded = false },
                    ) {
                        Text(
                            caption,
                            color = Color.White,
                            style = if (isTextOnly) MaterialTheme.typography.headlineSmall else MaterialTheme.typography.bodyLarge,
                            textAlign = if (isTextOnly) TextAlign.Center else TextAlign.Start,
                            modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
                        )
                    }
                }
            }

            // Caption of photos/videos: below the media, at most three lines; tap to read all of it.
            if (!isTextOnly && caption.isNotBlank()) {
                Text(
                    caption,
                    color = Color.White,
                    maxLines = 3,
                    overflow = TextOverflow.Ellipsis,
                    onTextLayout = { truncated = it.hasVisualOverflow },
                    modifier = Modifier.fillMaxWidth()
                        .alpha(if (expanded) 0f else 1f)
                        .background(Color.Black.copy(alpha = 0.55f))
                        .clickable(enabled = truncated && !expanded) { expanded = true }
                        .padding(horizontal = 12.dp, vertical = 8.dp),
                )
            }

            if (replyVisible && !m.fromMe) {
                Row(Modifier.fillMaxWidth().background(Color.Black.copy(alpha = 0.55f)).padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    OutlinedTextField(
                        value = reply,
                        onValueChange = { reply = it },
                        placeholder = { Text("Reply…") },
                        maxLines = 3,
                        modifier = Modifier.weight(1f),
                    )
                    IconButton(
                        enabled = reply.isNotBlank(),
                        onClick = {
                            val text = reply.trim()
                            reply = ""
                            replyVisible = false
                            scope.launch {
                                repo.sendText(m.senderId, text, replyTo = m, quotedChat = STATUS_CHAT)
                                Toast.makeText(ctx, "Reply sent", Toast.LENGTH_SHORT).show()
                            }
                        },
                    ) { Icon(Icons.AutoMirrored.Filled.Send, contentDescription = "Send reply", tint = Color.White) }
                }
            }
        }

        Column(Modifier.align(Alignment.TopCenter).fillMaxWidth().padding(8.dp)) {
            Row(Modifier.fillMaxWidth()) {
                items.indices.forEach { n ->
                    Box(
                        Modifier.weight(1f).padding(horizontal = 2.dp).height(3.dp)
                            .background(if (n <= i) Color.White else Color.White.copy(alpha = 0.3f)),
                    )
                }
            }
            Row(Modifier.fillMaxWidth().padding(top = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                Text(
                    (if (m.fromMe) "You" else m.senderName.ifBlank { poster.substringBefore('@') }) + " · " + formatTime(m.timestamp),
                    color = Color.White,
                    style = MaterialTheme.typography.labelLarge,
                    modifier = Modifier.weight(1f),
                )
                if ((m.kind == "video" || m.kind == "audio") && m.durationSecs > 0) {
                    Text(formatDuration(m.durationSecs), color = Color.White, style = MaterialTheme.typography.labelLarge)
                }
            }
        }
    }
}

private fun formatDuration(secs: Int): String = "%d:%02d".format(secs / 60, secs % 60)

/** Story-style video/audio: no controls, stays put when it ends (or fails), pauses while [paused]. Recreated per file. */
@Composable
private fun VideoStatus(path: String, paused: Boolean, onDone: () -> Unit) {
    val ctx = LocalContext.current
    val done by rememberUpdatedState(onDone)
    val exo = remember(path) {
        ExoPlayer.Builder(ctx).build().apply {
            setAudioAttributes(
                AudioAttributes.Builder().setUsage(C.USAGE_MEDIA).setContentType(C.AUDIO_CONTENT_TYPE_MOVIE).build(),
                true,
            )
            setMediaItem(MediaItem.fromUri(Uri.fromFile(File(path))))
            addListener(object : Player.Listener {
                override fun onPlaybackStateChanged(state: Int) {
                    if (state == Player.STATE_ENDED) done()
                }

                override fun onPlayerError(error: PlaybackException) {
                    done()
                }
            })
            prepare()
        }
    }
    DisposableEffect(exo) { onDispose { exo.release() } }
    LaunchedEffect(exo, paused) { exo.playWhenReady = !paused }
    AndroidView(
        factory = { c ->
            (LayoutInflater.from(c).inflate(R.layout.status_player_view, null, false) as PlayerView).apply { player = exo }
        },
        update = { it.player = exo },
        modifier = Modifier.fillMaxSize(),
    )
}
