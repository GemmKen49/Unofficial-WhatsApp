package com.classic.whatsapp.ui.group

import android.content.ClipData
import android.content.ClipboardManager
import android.widget.Toast
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.classic.whatsapp.ClassicApp
import com.classic.whatsapp.messaging.GroupDetailsInfo
import com.classic.whatsapp.messaging.GroupMemberInfo
import com.classic.whatsapp.ui.Avatar
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.launch

private enum class Edit { Subject, Description, AddMember, Leave, ResetLink }

/**
 * Group info with admin tools: name and description, members with their roles, add / remove / promote / demote,
 * the two group restrictions, invite link and leaving. The server enforces who may do what: when this account is not
 * an admin, a refused action just shows the server's answer.
 */
@Composable
fun GroupInfoScreen(groupId: String, onBack: () -> Unit, onMessage: (String) -> Unit, onOpenInfo: (String) -> Unit, onLeft: () -> Unit) {
    val ctx = LocalContext.current
    val app = ctx.applicationContext as ClassicApp
    val repo = app.repo
    val avatars = app.avatars
    val scope = rememberCoroutineScope()
    val chat by repo.chat(groupId).collectAsState(initial = null)

    var details by remember { mutableStateOf<GroupDetailsInfo?>(null) }
    var loadError by remember { mutableStateOf<String?>(null) }
    var own by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }
    var edit by remember { mutableStateOf<Edit?>(null) }
    var memberMenu by remember { mutableStateOf<GroupMemberInfo?>(null) }

    fun toast(t: String) = Toast.makeText(ctx, t, Toast.LENGTH_SHORT).show()

    suspend fun reload() {
        try {
            val d = repo.groupDetails(groupId)
            d.members.forEach { avatars.rememberPerson(it.jid, it.phone, it.username) }
            details = d
            loadError = null
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            loadError = e.message ?: "Could not load the group"
        }
    }

    /** Runs a change on the server, then reloads the group. */
    fun act(done: String, block: suspend () -> Unit) {
        if (busy) return
        busy = true
        scope.launch {
            try {
                block()
                toast(done)
                reload()
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                toast(e.message ?: "Not allowed")
            } finally {
                busy = false
            }
        }
    }

    LaunchedEffect(groupId) {
        own = avatars.ownJid()
        reload()
    }

    val d = details
    val me = d?.members?.firstOrNull { m ->
        own != null && (avatars.normalize(m.jid) == own || (m.phone.isNotBlank() && avatars.normalize(m.phone) == own))
    }
    // When this account cannot be found in the list, still offer the tools; the server decides.
    val admin = me?.isAdmin == true || (d != null && me == null)

    Column(Modifier.fillMaxSize().statusBarsPadding()) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back") }
            Text("Group info", style = MaterialTheme.typography.titleLarge)
        }
        if (d == null) {
            Text(loadError ?: "Loading…", modifier = Modifier.padding(16.dp), color = if (loadError != null) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurface)
            return@Column
        }
        val canEditInfo = admin || !d.locked
        LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 24.dp)) {
            item {
                Column(Modifier.fillMaxWidth().padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Avatar(groupId, d.subject, Modifier.size(120.dp), MaterialTheme.typography.displayMedium, full = true)
                    Text(
                        d.subject.ifBlank { chat?.displayTitle.orEmpty() },
                        style = MaterialTheme.typography.headlineSmall,
                        modifier = Modifier.padding(top = 12.dp).clickable(enabled = canEditInfo) { edit = Edit.Subject },
                    )
                    Text("${d.members.size} members", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                HorizontalDivider()
                Column(Modifier.fillMaxWidth().clickable(enabled = canEditInfo) { edit = Edit.Description }.padding(16.dp)) {
                    Text("Description", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text(d.description.ifBlank { if (canEditInfo) "Add a group description" else "No description" })
                }
                HorizontalDivider()
                Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                    TextButton(onClick = {
                        scope.launch {
                            try {
                                val link = repo.groupInviteLink(groupId, false)
                                ctx.getSystemService(ClipboardManager::class.java).setPrimaryClip(ClipData.newPlainText("Invite link", link))
                                toast("Invite link copied")
                            } catch (e: CancellationException) {
                                throw e
                            } catch (e: Exception) {
                                toast(e.message ?: "Could not get the invite link")
                            }
                        }
                    }) { Text("Copy invite link") }
                    if (admin) TextButton(onClick = { edit = Edit.ResetLink }) { Text("Reset link") }
                }
                if (admin) {
                    HorizontalDivider()
                    SwitchRow("Only admins can send messages", d.announce, !busy) { v ->
                        act("Saved") { repo.groupSetRestrictions(groupId, v, d.locked) }
                    }
                    SwitchRow("Only admins can edit group info", d.locked, !busy) { v ->
                        act("Saved") { repo.groupSetRestrictions(groupId, d.announce, v) }
                    }
                }
                HorizontalDivider()
                Row(Modifier.fillMaxWidth().padding(start = 16.dp, end = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("Members", style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
                    if (admin) TextButton(onClick = { edit = Edit.AddMember }) { Text("Add member") }
                }
            }
            items(d.members, key = { it.jid }) { m ->
                val name = remember(m.jid, m.phone) { m.phone.ifBlank { m.jid }.substringBefore('@').substringBefore(':') }
                var shown by remember(m.jid) { mutableStateOf(name) }
                LaunchedEffect(m.jid, m.phone) {
                    val known = repo.title(m.phone.ifBlank { m.jid })
                    shown = if (known == name && m.username.isNotBlank()) "@${m.username}" else if (known == name) "+$name" else known
                }
                Row(
                    Modifier.fillMaxWidth().clickable { memberMenu = m }.padding(horizontal = 16.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Avatar(m.jid, shown, Modifier.padding(end = 12.dp).size(40.dp))
                    Column(Modifier.weight(1f)) {
                        Text(shown, style = MaterialTheme.typography.bodyLarge)
                        if (m.username.isNotBlank() && !shown.startsWith("@")) Text("@${m.username}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    if (m.isSuperAdmin) Text("Owner", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary)
                    else if (m.isAdmin) Text("Admin", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary)
                }
            }
            item {
                HorizontalDivider(Modifier.padding(top = 8.dp))
                TextButton(onClick = { edit = Edit.Leave }, modifier = Modifier.padding(horizontal = 8.dp)) {
                    Text("Leave group", color = MaterialTheme.colorScheme.error)
                }
            }
        }
    }

    memberMenu?.let { m ->
        AlertDialog(
            onDismissRequest = { memberMenu = null },
            title = { Text(m.phone.ifBlank { m.jid }.substringBefore('@').substringBefore(':').let { if (m.username.isNotBlank()) "@${m.username}" else "+$it" }) },
            text = {
                Column {
                    TextButton(onClick = { memberMenu = null; onOpenInfo(m.jid) }) { Text("Contact info") }
                    TextButton(onClick = { memberMenu = null; onMessage(m.phone.ifBlank { m.jid }) }) { Text("Message") }
                    if (admin && !m.isSuperAdmin) {
                        if (m.isAdmin) {
                            TextButton(onClick = { memberMenu = null; act("Admin removed") { repo.groupChangeMembers(groupId, "demote", listOf(m.jid)).failed("Could not remove admin") } }) { Text("Remove as admin") }
                        } else {
                            TextButton(onClick = { memberMenu = null; act("Made admin") { repo.groupChangeMembers(groupId, "promote", listOf(m.jid)).failed("Could not make admin") } }) { Text("Make admin") }
                        }
                        TextButton(onClick = { memberMenu = null; act("Removed") { repo.groupChangeMembers(groupId, "remove", listOf(m.jid)).failed("Could not remove") } }) {
                            Text("Remove from group", color = MaterialTheme.colorScheme.error)
                        }
                    }
                }
            },
            confirmButton = {},
            dismissButton = { TextButton(onClick = { memberMenu = null }) { Text("Close") } },
        )
    }

    when (edit) {
        Edit.Subject, Edit.Description -> {
            val isSubject = edit == Edit.Subject
            var text by remember(edit) { mutableStateOf(if (isSubject) d?.subject.orEmpty() else d?.description.orEmpty()) }
            AlertDialog(
                onDismissRequest = { edit = null },
                title = { Text(if (isSubject) "Group name" else "Group description") },
                text = {
                    OutlinedTextField(
                        value = text,
                        onValueChange = { text = it.take(if (isSubject) 100 else 2048) },
                        singleLine = isSubject,
                        supportingText = { Text("${text.length}/${if (isSubject) 100 else 2048}") },
                    )
                },
                confirmButton = {
                    TextButton(enabled = !isSubject || text.isNotBlank(), onClick = {
                        edit = null
                        if (isSubject) act("Name saved") { repo.groupSetSubject(groupId, text.trim()) }
                        else act("Description saved") { repo.groupSetDescription(groupId, text.trim()) }
                    }) { Text("Save") }
                },
                dismissButton = { TextButton(onClick = { edit = null }) { Text("Cancel") } },
            )
        }
        Edit.AddMember -> {
            var digits by remember { mutableStateOf("") }
            AlertDialog(
                onDismissRequest = { edit = null },
                title = { Text("Add member") },
                text = {
                    OutlinedTextField(
                        value = digits,
                        onValueChange = { digits = it.filter(Char::isDigit) },
                        label = { Text("Number with country code") },
                        prefix = { Text("+") },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                    )
                },
                confirmButton = {
                    TextButton(enabled = digits.length in 8..15, onClick = {
                        edit = null
                        act("Member added") { repo.groupChangeMembers(groupId, "add", listOf("$digits@s.whatsapp.net")).failed("Could not add this number (not on WhatsApp, or not allowed)") }
                    }) { Text("Add") }
                },
                dismissButton = { TextButton(onClick = { edit = null }) { Text("Cancel") } },
            )
        }
        Edit.ResetLink -> AlertDialog(
            onDismissRequest = { edit = null },
            title = { Text("Reset invite link?") },
            text = { Text("The old link stops working. The new one is copied to the clipboard.") },
            confirmButton = {
                TextButton(onClick = {
                    edit = null
                    act("New link copied") {
                        val link = repo.groupInviteLink(groupId, true)
                        ctx.getSystemService(ClipboardManager::class.java).setPrimaryClip(ClipData.newPlainText("Invite link", link))
                    }
                }) { Text("Reset") }
            },
            dismissButton = { TextButton(onClick = { edit = null }) { Text("Cancel") } },
        )
        Edit.Leave -> AlertDialog(
            onDismissRequest = { edit = null },
            title = { Text("Leave group?") },
            text = { Text("You will stop receiving its messages and the chat is deleted from this device.") },
            confirmButton = {
                TextButton(onClick = {
                    edit = null
                    scope.launch {
                        try {
                            repo.groupLeave(groupId)
                            onLeft()
                        } catch (e: CancellationException) {
                            throw e
                        } catch (e: Exception) {
                            toast(e.message ?: "Could not leave the group")
                        }
                    }
                }) { Text("Leave", color = MaterialTheme.colorScheme.error) }
            },
            dismissButton = { TextButton(onClick = { edit = null }) { Text("Cancel") } },
        )
        null -> Unit
    }
}

/** Turns "the server refused these ids" into an error the caller shows. */
private fun List<String>.failed(message: String) {
    if (isNotEmpty()) throw IllegalStateException(message)
}

@Composable
private fun SwitchRow(label: String, checked: Boolean, enabled: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(label, modifier = Modifier.weight(1f))
        Switch(checked = checked, onCheckedChange = onChange, enabled = enabled)
    }
}
