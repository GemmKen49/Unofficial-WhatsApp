package com.classic.whatsapp.ui.settings

import android.content.Intent
import android.net.Uri
import android.os.PowerManager
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.classic.whatsapp.ClassicApp
import kotlinx.coroutines.launch

@Composable
fun SettingsScreen(onBack: () -> Unit, onHidden: () -> Unit) {
    val ctx = LocalContext.current
    val app = ctx.applicationContext as ClassicApp
    val status by app.status.collectAsState()
    val scope = rememberCoroutineScope()
    val pm = ctx.getSystemService(PowerManager::class.java)
    var unrestricted by remember { mutableStateOf(pm.isIgnoringBatteryOptimizations(ctx.packageName)) }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) {
        unrestricted = pm.isIgnoringBatteryOptimizations(ctx.packageName)
    }
    var confirm by remember { mutableStateOf(false) }
    val readReceipts by app.settings.sendReadReceipts.collectAsState()
    val autoImages by app.settings.autoDownloadImages.collectAsState()

    Column(Modifier.fillMaxSize().statusBarsPadding().padding(24.dp)) {
        Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
            IconButton(onClick = onBack) {
                Icon(androidx.compose.material.icons.Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
            }
            Text("Settings", style = MaterialTheme.typography.titleLarge)
        }

        Row(Modifier.fillMaxWidth().padding(top = 16.dp), verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("Hidden chats", style = MaterialTheme.typography.titleMedium)
                Text("Chats you hid; they come back on their own with a new message.", style = MaterialTheme.typography.bodySmall)
            }
            TextButton(onClick = onHidden) { Text("Open") }
        }

        Text("Connection", style = MaterialTheme.typography.titleMedium, modifier = Modifier.padding(top = 24.dp))
        Text(status, modifier = Modifier.padding(top = 4.dp))
        Text(
            "Linked as an Electron companion (unofficial client).",
            style = MaterialTheme.typography.bodySmall,
            modifier = Modifier.padding(top = 4.dp),
        )

        Row(Modifier.fillMaxWidth().padding(top = 24.dp), verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("Send read receipts", style = MaterialTheme.typography.titleMedium)
                Text("Let people see when you have read their messages.", style = MaterialTheme.typography.bodySmall)
            }
            Switch(checked = readReceipts, onCheckedChange = { app.settings.setSendReadReceipts(it) })
        }

        Row(Modifier.fillMaxWidth().padding(top = 16.dp), verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("Auto-download images", style = MaterialTheme.typography.titleMedium)
                Text("Download received photos up to 8 MB automatically.", style = MaterialTheme.typography.bodySmall)
            }
            Switch(checked = autoImages, onCheckedChange = { app.settings.setAutoDownloadImages(it) })
        }

        Text("Background running", style = MaterialTheme.typography.titleMedium, modifier = Modifier.padding(top = 24.dp))
        Text(
            if (unrestricted) "Battery optimization: unrestricted" else "Battery optimization: on (messages may be delayed)",
            modifier = Modifier.padding(top = 4.dp),
        )
        if (!unrestricted) {
            Button(
                onClick = {
                    launcher.launch(
                        Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:${ctx.packageName}")),
                    )
                },
                modifier = Modifier.padding(top = 8.dp),
            ) { Text("Allow unrestricted") }
        }

        Button(onClick = { confirm = true }, modifier = Modifier.padding(top = 32.dp)) {
            Text("Disconnect and clear everything")
        }
    }

    if (confirm) {
        AlertDialog(
            onDismissRequest = { confirm = false },
            title = { Text("Clear session and chats?") },
            text = { Text("You will need to link again. Also remove this device in WhatsApp > Linked devices.") },
            confirmButton = {
                TextButton(onClick = {
                    confirm = false
                    scope.launch { app.clearEverything() }
                }) { Text("Clear") }
            },
            dismissButton = { TextButton(onClick = { confirm = false }) { Text("Cancel") } },
        )
    }
}
