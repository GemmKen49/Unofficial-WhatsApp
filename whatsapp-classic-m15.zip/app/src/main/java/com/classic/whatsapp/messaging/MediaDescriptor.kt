package com.classic.whatsapp.messaging

import android.util.Base64
import org.json.JSONObject

/**
 * Stable description of a media attachment (kind: image | video | document | viewonce).
 * The JSON form (without thumbnail) is persisted so media can be downloaded later.
 */
class MediaDescriptor(
    val kind: String,
    val mimeType: String,
    val fileName: String,
    val caption: String,
    val fileLength: Long,
    val directPath: String,
    val mediaKey: ByteArray,
    val fileSha256: ByteArray,
    val fileEncSha256: ByteArray,
    val thumbnail: ByteArray,
    val durationSecs: Int = 0,
    val voice: Boolean = false,
) {
    fun toJson(): String = JSONObject()
        .put("kind", kind)
        .put("mime", mimeType)
        .put("name", fileName)
        .put("caption", caption)
        .put("length", fileLength)
        .put("path", directPath)
        .put("key", b64(mediaKey))
        .put("sha", b64(fileSha256))
        .put("encSha", b64(fileEncSha256))
        .put("secs", durationSecs)
        .put("voice", voice)
        .toString()

    companion object {
        private fun b64(b: ByteArray) = Base64.encodeToString(b, Base64.NO_WRAP)
        private fun unb64(s: String) = Base64.decode(s, Base64.NO_WRAP)

        fun fromJson(json: String): MediaDescriptor? = try {
            val o = JSONObject(json)
            MediaDescriptor(
                kind = o.getString("kind"),
                mimeType = o.optString("mime"),
                fileName = o.optString("name"),
                caption = o.optString("caption"),
                fileLength = o.optLong("length"),
                directPath = o.optString("path"),
                mediaKey = unb64(o.optString("key")),
                fileSha256 = unb64(o.optString("sha")),
                fileEncSha256 = unb64(o.optString("encSha")),
                thumbnail = ByteArray(0),
                durationSecs = o.optInt("secs"),
                voice = o.optBoolean("voice"),
            )
        } catch (e: Exception) {
            null
        }
    }
}
