package com.classic.whatsapp

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.lifecycle.lifecycleScope
import com.classic.whatsapp.data.MediaFiles
import com.classic.whatsapp.data.ShareRequest
import com.classic.whatsapp.navigation.AppRoot
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import com.classic.whatsapp.ui.theme.ClassicTheme

class MainActivity : ComponentActivity() {
    private val app get() = application as ClassicApp
    private val notificationPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        handleIntent(intent)
        if (checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
        setContent { ClassicTheme { AppRoot() } }
    }

    override fun onStart() {
        super.onStart()
        app.repo.foreground.value = true
        app.ensureService()
    }

    override fun onStop() {
        app.repo.foreground.value = false
        super.onStop()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleIntent(intent)
    }

    private fun handleIntent(i: Intent?) {
        if (i == null) return
        i.getStringExtra(Notifier.EXTRA_CHAT_ID)?.let { app.openRequest.value = it }

        // Another app shared files/text with us (ACTION_SEND / ACTION_SEND_MULTIPLE).
        if (i.action == Intent.ACTION_SEND || i.action == Intent.ACTION_SEND_MULTIPLE) {
            val uris: List<Uri> = if (i.action == Intent.ACTION_SEND) {
                listOfNotNull(i.getParcelableExtra(Intent.EXTRA_STREAM, Uri::class.java))
            } else {
                i.getParcelableArrayListExtra(Intent.EXTRA_STREAM, Uri::class.java).orEmpty()
            }
            val text = i.getStringExtra(Intent.EXTRA_TEXT).orEmpty()
            if (uris.isEmpty() && text.isBlank()) return
            lifecycleScope.launch {
                val files = withContext(Dispatchers.IO) { uris.mapNotNull { MediaFiles.importUri(this@MainActivity, it) } }
                app.pendingShare.value = ShareRequest(files, text)
            }
            setIntent(Intent(this, MainActivity::class.java)) // do not re-handle on rotation
        }
    }
}
