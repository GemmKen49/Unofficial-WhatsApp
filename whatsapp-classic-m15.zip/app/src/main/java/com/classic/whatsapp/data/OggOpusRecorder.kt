package com.classic.whatsapp.data

import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaCodec
import android.media.MediaFormat
import android.media.MediaRecorder
import java.io.File
import java.io.FileOutputStream
import java.io.OutputStream
import kotlin.math.abs
import kotlin.random.Random

/**
 * Records the microphone as a standards-conforming Ogg Opus file (16 kHz mono, 24 kbit/s): PCM from [AudioRecord] is
 * encoded with the platform Opus encoder ([MediaCodec]) and written into Ogg pages by [OggWriter]. Android's own
 * `MediaRecorder` Ogg output plays locally but official WhatsApp rejects it, so the container is written here.
 */
class OggOpusRecorder(private val file: File) {
    /** [seconds] of audio and a WhatsApp-style 64-value (0..100) loudness [waveform]. */
    class Result(val seconds: Int, val waveform: ByteArray)

    @Volatile private var running = false
    @Volatile private var result: Result? = null
    private var thread: Thread? = null

    /** Throws if the microphone or the encoder cannot be opened. */
    fun start() {
        val minBuf = AudioRecord.getMinBufferSize(RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        if (minBuf <= 0) throw IllegalStateException("No audio input")
        val rec = AudioRecord.Builder()
            .setAudioSource(MediaRecorder.AudioSource.MIC)
            .setAudioFormat(
                AudioFormat.Builder()
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setSampleRate(RATE)
                    .setChannelMask(AudioFormat.CHANNEL_IN_MONO)
                    .build(),
            )
            .setBufferSizeInBytes(maxOf(minBuf, RATE * 2))
            .build()
        if (rec.state != AudioRecord.STATE_INITIALIZED) {
            rec.release()
            throw IllegalStateException("Microphone unavailable")
        }
        val enc = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_AUDIO_OPUS)
        try {
            val format = MediaFormat.createAudioFormat(MediaFormat.MIMETYPE_AUDIO_OPUS, RATE, 1)
            format.setInteger(MediaFormat.KEY_BIT_RATE, BITRATE)
            enc.configure(format, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
            enc.start()
            rec.startRecording()
        } catch (e: Exception) {
            runCatching { enc.release() }
            rec.release()
            throw e
        }
        running = true
        thread = Thread({ loop(rec, enc) }, "opus-recorder").also { it.start() }
    }

    /** Stops, finishes the file and returns what was recorded (null if it failed). */
    fun stop(): Result? {
        running = false
        thread?.join(5000)
        thread = null
        return result
    }

    /** Stops and deletes the file. */
    fun cancel() {
        running = false
        thread?.join(5000)
        thread = null
        file.delete()
    }

    private fun loop(rec: AudioRecord, enc: MediaCodec) {
        val levels = ArrayList<Int>()
        var samples = 0L
        var ok = false
        try {
            FileOutputStream(file).buffered().use { out ->
                val ogg = OggWriter(out)
                val info = MediaCodec.BufferInfo()

                // Returns true once the end-of-stream output was seen.
                fun drain(timeoutUs: Long): Boolean {
                    while (true) {
                        val i = enc.dequeueOutputBuffer(info, timeoutUs)
                        if (i == MediaCodec.INFO_TRY_AGAIN_LATER) return false
                        if (i < 0) continue // format / buffers changed
                        val bytes = ByteArray(info.size)
                        if (info.size > 0) {
                            val ob = enc.getOutputBuffer(i)!!
                            ob.position(info.offset)
                            ob.limit(info.offset + info.size)
                            ob.get(bytes)
                        }
                        if (info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG != 0) {
                            ogg.readConfig(bytes)
                        } else if (info.size > 0) {
                            ogg.addPacket(bytes)
                        }
                        val eos = info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0
                        enc.releaseOutputBuffer(i, false)
                        if (eos) return true
                    }
                }

                fun feed(data: ByteArray, len: Int, eos: Boolean) {
                    var tries = 0
                    var idx = enc.dequeueInputBuffer(10_000)
                    while (idx < 0) {
                        if (++tries > 300) throw IllegalStateException("Encoder stalled")
                        drain(0)
                        idx = enc.dequeueInputBuffer(10_000)
                    }
                    val ib = enc.getInputBuffer(idx)!!
                    ib.clear()
                    if (len > 0) ib.put(data, 0, len)
                    enc.queueInputBuffer(
                        idx, 0, len, samples * 1_000_000L / RATE,
                        if (eos) MediaCodec.BUFFER_FLAG_END_OF_STREAM else 0,
                    )
                }

                val pcm = ByteArray(FRAME_BYTES)
                while (running) {
                    val n = rec.read(pcm, 0, pcm.size)
                    if (n < 0) throw IllegalStateException("Microphone read failed ($n)")
                    if (n == 0) continue
                    var sum = 0L
                    var s = 0
                    while (s + 1 < n) {
                        sum += abs(((pcm[s + 1].toInt() shl 8) or (pcm[s].toInt() and 0xFF)).toShort().toInt())
                        s += 2
                    }
                    levels += (sum / (n / 2)).toInt()
                    feed(pcm, n, false)
                    samples += n / 2
                    drain(0)
                }

                feed(pcm, 0, true)
                var tries = 0
                while (!drain(10_000)) {
                    if (++tries > 300) throw IllegalStateException("Encoder did not finish")
                }
                ogg.finish()
                ok = true
            }
        } catch (e: Exception) {
            ok = false
        } finally {
            runCatching { rec.stop() }
            rec.release()
            runCatching { enc.stop() }
            runCatching { enc.release() }
        }
        if (ok) result = Result((samples / RATE).toInt(), waveform(levels)) else file.delete()
    }

    private fun waveform(levels: List<Int>): ByteArray {
        val out = ByteArray(WAVEFORM_BARS)
        if (levels.isEmpty()) return out
        val buckets = IntArray(WAVEFORM_BARS) { b ->
            val from = b * levels.size / WAVEFORM_BARS
            val to = maxOf(from + 1, (b + 1) * levels.size / WAVEFORM_BARS).coerceAtMost(levels.size)
            var sum = 0L
            for (i in from until to) sum += levels[i]
            (sum / (to - from).coerceAtLeast(1)).toInt()
        }
        val peak = (buckets.maxOrNull() ?: 0).coerceAtLeast(1)
        for (i in out.indices) out[i] = (buckets[i] * 100L / peak).toInt().coerceIn(0, 100).toByte()
        return out
    }

    private companion object {
        const val RATE = 16000
        const val BITRATE = 24000
        const val FRAME_BYTES = RATE / 50 * 2 // 20 ms of 16-bit mono
        const val WAVEFORM_BARS = 64
    }
}

/** Minimal Ogg Opus muxer (RFC 3533 / RFC 7845): header pages, then Opus packets of 20 ms, last page flagged EOS. */
private class OggWriter(private val out: OutputStream) {
    private val serial = Random.nextInt()
    private var seq = 0
    private var headersWritten = false
    private var preSkip = 312 // libopus look-ahead at 48 kHz; replaced by the encoder's own value when it reports one
    private val pending = ArrayList<ByteArray>()
    private var pendingSegments = 0
    private var flushedPackets = 0L

    /** The encoder's codec-config buffer is an OpusHead; take its pre-skip (headers are only written later). */
    fun readConfig(b: ByteArray) {
        if (headersWritten || b.size < 12 || String(b, 0, 8, Charsets.US_ASCII) != "OpusHead") return
        val v = (b[10].toInt() and 0xFF) or ((b[11].toInt() and 0xFF) shl 8)
        if (v in 0..10_000) preSkip = v
    }

    fun addPacket(p: ByteArray) {
        if (!headersWritten) writeHeaders()
        val segs = p.size / 255 + 1
        if (pendingSegments + segs > 255 || pending.size >= PACKETS_PER_PAGE) flush(false)
        pending += p
        pendingSegments += segs
    }

    fun finish() {
        if (!headersWritten) writeHeaders()
        flush(true)
        out.flush()
    }

    private fun writeHeaders() {
        val head = ByteArray(19)
        "OpusHead".toByteArray(Charsets.US_ASCII).copyInto(head)
        head[8] = 1 // version
        head[9] = 1 // channels
        head[10] = preSkip.toByte(); head[11] = (preSkip ushr 8).toByte()
        head.le32(12, 16000) // original input sample rate (informational)
        // output gain 0, channel mapping family 0
        page(0x02, 0, listOf(head))
        val vendor = "WhatsApp Classic".toByteArray(Charsets.US_ASCII)
        val tags = ByteArray(8 + 4 + vendor.size + 4)
        "OpusTags".toByteArray(Charsets.US_ASCII).copyInto(tags)
        tags.le32(8, vendor.size)
        vendor.copyInto(tags, 12)
        page(0, 0, listOf(tags)) // zero user comments
        headersWritten = true
    }

    private fun flush(eos: Boolean) {
        if (pending.isEmpty() && !eos) return
        flushedPackets += pending.size
        page(if (eos) 0x04 else 0, flushedPackets * SAMPLES_PER_PACKET, pending)
        pending.clear()
        pendingSegments = 0
    }

    private fun page(flags: Int, granule: Long, packets: List<ByteArray>) {
        val lacing = ArrayList<Int>()
        var dataLen = 0
        for (p in packets) {
            var l = p.size
            while (l >= 255) { lacing += 255; l -= 255 }
            lacing += l
            dataLen += p.size
        }
        val headerLen = 27 + lacing.size
        val buf = ByteArray(headerLen + dataLen)
        "OggS".toByteArray(Charsets.US_ASCII).copyInto(buf)
        buf[5] = flags.toByte()
        buf.le64(6, granule)
        buf.le32(14, serial)
        buf.le32(18, seq++)
        buf[26] = lacing.size.toByte()
        for (i in lacing.indices) buf[27 + i] = lacing[i].toByte()
        var o = headerLen
        for (p in packets) { p.copyInto(buf, o); o += p.size }
        buf.le32(22, crc(buf))
        out.write(buf)
    }

    private companion object {
        const val PACKETS_PER_PAGE = 25 // 0.5 s
        const val SAMPLES_PER_PACKET = 960L // 20 ms at 48 kHz, the unit Ogg Opus granule positions use

        val table = IntArray(256).also { t ->
            for (i in 0 until 256) {
                var r = i shl 24
                repeat(8) { r = if (r and Int.MIN_VALUE != 0) (r shl 1) xor 0x04C11DB7 else r shl 1 }
                t[i] = r
            }
        }

        fun crc(data: ByteArray): Int {
            var c = 0
            for (b in data) c = (c shl 8) xor table[((c ushr 24) xor b.toInt()) and 0xFF]
            return c
        }
    }
}

private fun ByteArray.le32(o: Int, v: Int) { for (i in 0..3) this[o + i] = (v ushr (8 * i)).toByte() }
private fun ByteArray.le64(o: Int, v: Long) { for (i in 0..7) this[o + i] = (v ushr (8 * i)).toByte() }
