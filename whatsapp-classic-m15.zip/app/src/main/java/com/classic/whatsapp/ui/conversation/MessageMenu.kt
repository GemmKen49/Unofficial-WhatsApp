package com.classic.whatsapp.ui.conversation

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.Layout
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.Constraints
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntRect
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Popup
import androidx.compose.ui.window.PopupPositionProvider
import androidx.compose.ui.window.PopupProperties

internal data class MenuEntry(val label: String, val destructive: Boolean = false, val onClick: () -> Unit)

private val REACTIONS = listOf("👍", "❤️", "😂", "😮", "😢", "🙏")

/**
 * Context menu of a message: a reaction dock and an options list placed around the message (whose window bounds are
 * [bounds]). Normal order, top to bottom: dock, message, options. When the options do not fit below the message they
 * move above it, over the dock: options, dock, message. When the message is too tall for that, both docks sit above
 * the typing bar. All of it stays inside [area].
 */
@Composable
internal fun MessageMenuPopup(
    bounds: Rect?,
    /** Window bounds of the message list; the docks never leave it. */
    area: Rect?,
    /** When set, the docks are centred on this x (window pixels) instead of being aligned to the message side. */
    anchorX: Float? = null,
    fromMe: Boolean,
    myReaction: String,
    showReactions: Boolean,
    entries: List<MenuEntry>,
    onReact: (String) -> Unit,
    onDismiss: () -> Unit,
) {
    val density = LocalDensity.current
    val gap = with(density) { 8.dp.roundToPx() }
    val margin = with(density) { 12.dp.roundToPx() }
    val minTop = maxOf(WindowInsets.statusBars.getTop(density), with(density) { 24.dp.roundToPx() })
    val minBottom = maxOf(WindowInsets.navigationBars.getBottom(density), with(density) { 16.dp.roundToPx() })

    // A popup at (0, 0) that fills the window: its content coordinates are window coordinates, like [bounds].
    Popup(
        popupPositionProvider = object : PopupPositionProvider {
            override fun calculatePosition(anchorBounds: IntRect, windowSize: IntSize, layoutDirection: LayoutDirection, popupContentSize: IntSize) = IntOffset.Zero
        },
        onDismissRequest = onDismiss,
        properties = PopupProperties(focusable = true, clippingEnabled = false),
    ) {
        Layout(
            modifier = Modifier.fillMaxSize().pointerInput(Unit) { detectTapGestures { onDismiss() } },
            content = {
                if (showReactions) {
                    Surface(shape = RoundedCornerShape(28.dp), tonalElevation = 6.dp, shadowElevation = 6.dp) {
                        Row(Modifier.padding(horizontal = 6.dp, vertical = 4.dp)) {
                            REACTIONS.forEach { e ->
                                Text(
                                    e,
                                    style = MaterialTheme.typography.headlineSmall,
                                    modifier = Modifier
                                        .background(if (e == myReaction) MaterialTheme.colorScheme.primary.copy(alpha = 0.2f) else Color.Transparent, RoundedCornerShape(20.dp))
                                        .clickable { onDismiss(); onReact(e) }
                                        .padding(horizontal = 6.dp, vertical = 6.dp),
                                )
                            }
                        }
                    }
                }
                Surface(shape = RoundedCornerShape(16.dp), tonalElevation = 6.dp, shadowElevation = 6.dp, modifier = Modifier.width(220.dp)) {
                    Column {
                        entries.forEachIndexed { i, entry ->
                            if (i > 0) HorizontalDivider()
                            Text(
                                entry.label,
                                style = MaterialTheme.typography.bodyLarge,
                                color = if (entry.destructive) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurface,
                                modifier = Modifier.fillMaxWidth().clickable { onDismiss(); entry.onClick() }.padding(horizontal = 16.dp, vertical = 12.dp),
                            )
                        }
                    }
                }
            },
        ) { measurables, c ->
            val loose = Constraints(maxWidth = c.maxWidth - 2 * margin, maxHeight = c.maxHeight)
            val dock = if (showReactions) measurables[0].measure(loose) else null
            val menu = measurables.last().measure(loose)
            val dockH = dock?.height ?: 0
            val dockGap = if (dock != null) gap else 0
            // Everything stays inside the message area (below the top bar, above the typing bar).
            val areaTop = maxOf(area?.top?.toInt() ?: minTop, minTop)
            val areaBottom = minOf(area?.bottom?.toInt() ?: (c.maxHeight - minBottom), c.maxHeight - minBottom)

            val b = bounds
            val top = (b?.top ?: (c.maxHeight / 2f)).toInt().coerceIn(areaTop, areaBottom)
            val bottom = (b?.bottom ?: (c.maxHeight / 2f)).toInt().coerceIn(areaTop, areaBottom)

            var dockY: Int
            var menuY: Int
            when {
                // Dock above the message, options below it.
                top - dockGap - dockH >= areaTop && bottom + gap + menu.height <= areaBottom -> {
                    dockY = top - dockGap - dockH
                    menuY = bottom + gap
                }
                // No room below: options above the dock, which stays above the message.
                top - dockGap - dockH - gap - menu.height >= areaTop -> {
                    dockY = top - dockGap - dockH
                    menuY = dockY - gap - menu.height
                }
                // The message is too tall for either: both docks sit just above the typing bar.
                else -> {
                    menuY = areaBottom - menu.height - gap
                    dockY = menuY - dockGap - dockH
                    if (dockY < areaTop) dockY = areaTop
                    if (menuY < areaTop) menuY = areaTop
                }
            }

            fun x(width: Int): Int {
                val anchor = when {
                    anchorX != null -> anchorX.toInt() - width / 2
                    b == null -> (c.maxWidth - width) / 2
                    fromMe -> b.right.toInt() - width
                    else -> b.left.toInt()
                }
                return anchor.coerceIn(margin, (c.maxWidth - width - margin).coerceAtLeast(margin))
            }

            layout(c.maxWidth, c.maxHeight) {
                dock?.place(x(dock.width), dockY)
                menu.place(x(menu.width), menuY)
            }
        }
    }
}
