package com.classic.whatsapp.data

import android.content.Context
import android.os.SystemClock
import java.io.File
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

sealed interface VoiceState {
    data object Idle : VoiceState
    data class Recording(val chatId: String, val startedAt: Long) : VoiceState
    /** Recording finished (e.g. the app went to the background) but not sent yet. */
    data class Ready(val chatId: String, val path: String, val secs: Int, val waveform: ByteArray = ByteArray(0)) : VoiceState
}

/** Records voice notes as ogg/opus (what WhatsApp expects). Lives in the Application so it survives rotation. */
class VoiceRecorder(private val ctx: Context) {
    private val _state = MutableStateFlow<VoiceState>(VoiceState.Idle)
    val state: StateFlow<VoiceState> = _state.asStateFlow()

    private var recorder: OggOpusRecorder? = null
    private var file: File? = null
    private var startedAt = 0L

    /** Throws if recording cannot start (e.g. the microphone permission was withdrawn). */
    fun start(chatId: String) {
        discard()
        val dir = File(ctx.cacheDir, "voice").apply { mkdirs() }
        val f = File(dir, "voice-${System.currentTimeMillis()}.ogg")
        val r = OggOpusRecorder(f)
        try {
            r.start()
        } catch (e: Exception) {
            f.delete()
            throw e
        }
        recorder = r
        file = f
        startedAt = SystemClock.elapsedRealtime()
        _state.value = VoiceState.Recording(chatId, startedAt)
    }

    /** Stops recording. Returns the finished note, or null if it was too short or failed. */
    fun stop(): VoiceState.Ready? {
        val st = _state.value as? VoiceState.Recording ?: return null
        val r = recorder
        val f = file
        recorder = null
        file = null
        val res = r?.stop()
        if (f == null || res == null || res.seconds < 1) {
            f?.delete()
            _state.value = VoiceState.Idle
            return null
        }
        val ready = VoiceState.Ready(st.chatId, f.path, res.seconds, res.waveform)
        _state.value = ready
        return ready
    }

    /** Hands the finished note over (the caller owns the file afterwards). */
    fun take(): VoiceState.Ready? {
        val r = _state.value as? VoiceState.Ready ?: return null
        _state.value = VoiceState.Idle
        return r
    }

    fun discard() {
        recorder?.cancel()
        recorder = null
        file?.delete()
        file = null
        (_state.value as? VoiceState.Ready)?.let { File(it.path).delete() }
        _state.value = VoiceState.Idle
    }
}
