package com.classic.whatsapp.ui.conversation

import android.Manifest
import android.content.ActivityNotFoundException
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.SystemClock
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.runtime.snapshotFlow
import kotlinx.coroutines.flow.first
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.core.content.FileProvider
import com.classic.whatsapp.ClassicApp
import com.classic.whatsapp.Notifier
import com.classic.whatsapp.R
import com.classic.whatsapp.data.*
import com.classic.whatsapp.ui.chats.ChatActionsDialog
import com.classic.whatsapp.ui.Avatar
import com.classic.whatsapp.ui.LinkText
import androidx.compose.ui.layout.boundsInWindow
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.LayoutCoordinates
import androidx.compose.ui.geometry.Rect
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.filled.Search
import com.classic.whatsapp.data.Reactions
import com.classic.whatsapp.ui.formatTime
import java.io.File
import java.util.UUID
import kotlin.math.abs
import kotlin.math.min
import kotlin.math.roundToInt
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** WhatsApp's read-receipt blue, fixed on purpose (independent of the dynamic theme colours). */
private val ReadBlue = Color(0xFF34B7F1)
private val MEDIA_KINDS = setOf("image", "video", "document", "audio")

private fun canReply(m: MessageEntity) = m.kind != "deleted" && m.status != STATUS_SENDING && m.status != STATUS_FAILED

internal fun hasFile(m: MessageEntity) = m.mediaPath.isNotBlank() && File(m.mediaPath).exists()

internal fun canForward(m: MessageEntity) =
    (m.kind == "text" && m.text.isNotBlank()) || (m.kind in MEDIA_KINDS && hasFile(m))

private fun mmss(secs: Long) = "%d:%02d".format(secs / 60, secs % 60)

@Composable
fun ConversationScreen(
    chatId: String,
    onBack: () -> Unit,
    onViewMedia: (String) -> Unit = {},
    onOpenInfo: (String) -> Unit = {},
    onOpenGroup: (String) -> Unit = {},
) {
    val ctx = LocalContext.current
    val app = ctx.applicationContext as ClassicApp
    val repo = app.repo
    val messages by repo.messages(chatId).collectAsState(initial = emptyList())
    val chat by repo.chat(chatId).collectAsState(initial = null as ChatEntity?)
    val foreground by repo.foreground.collectAsState()
    val downloading by repo.downloading.collectAsState()
    val error by repo.lastError.collectAsState()
    val share by app.pendingShare.collectAsState()
    val voiceState by app.voice.state.collectAsState()
    val playerState by app.player.state.collectAsState()
    val scope = rememberCoroutineScope()

    var draft by remember { mutableStateOf("") }
    var attach by remember { mutableStateOf<List<PendingFile>>(emptyList()) }
    var captionSeed by remember { mutableStateOf("") }
    var attachMenu by remember { mutableStateOf(false) }
    var showActions by remember { mutableStateOf(false) }
    var selected by remember { mutableStateOf<Set<String>>(emptySet()) }
    var confirmDelete by remember { mutableStateOf(false) }
    var replyTo by remember { mutableStateOf<MessageEntity?>(null) }
    val typingMap by repo.typing.collectAsState()
    var searching by remember { mutableStateOf(false) }
    var query by remember { mutableStateOf("") }
    var results by remember { mutableStateOf<List<MessageEntity>>(emptyList()) }
    var resultIdx by remember { mutableIntStateOf(0) }
    var editing by remember { mutableStateOf<MessageEntity?>(null) }
    var infoFor by remember { mutableStateOf<MessageEntity?>(null) }
    var reactFor by remember { mutableStateOf<MessageEntity?>(null) }
    var moreMenu by remember { mutableStateOf(false) }
    var menuFor by remember { mutableStateOf<Pair<MessageEntity, Rect?>?>(null) }
    var listBounds by remember { mutableStateOf<Rect?>(null) }

    // Auto-scroll rule: a new message scrolls the list to the newest one only if you were already at the bottom
    // (or you sent it yourself); while you are reading older messages the list stays where it is.
    val listState = rememberLazyListState()
    val showJump by remember { derivedStateOf { listState.firstVisibleItemIndex > 3 } }

    LaunchedEffect(query, searching) {
        if (!searching) { results = emptyList(); return@LaunchedEffect }
        delay(250)
        results = repo.searchMessages(chatId, query)
        resultIdx = results.lastIndex
    }
    val currentHit = if (searching) results.getOrNull(resultIdx) else null
    LaunchedEffect(currentHit?.messageId) {
        val hit = currentHit ?: return@LaunchedEffect
        val idx = messages.indexOfFirst { it.messageId == hit.messageId }
        if (idx >= 0) listState.animateScrollToItem(messages.lastIndex - idx)
    }

    // Numbers and usernames of group members are only known from the group's member list: remember them for Contact info.
    LaunchedEffect(chatId) {
        if (!chatId.endsWith("@g.us")) return@LaunchedEffect
        try {
            repo.groupDetails(chatId).members.forEach { app.avatars.rememberPerson(it.jid, it.phone, it.username) }
        } catch (e: kotlinx.coroutines.CancellationException) {
            throw e
        } catch (e: Exception) {
            // offline: numbers just stay unknown
        }
    }
    var lastNewestId by remember(chatId) { mutableStateOf<String?>(null) }
    val newest = messages.lastOrNull()
    LaunchedEffect(newest?.messageId) {
        val n = newest ?: return@LaunchedEffect
        val prev = lastNewestId
        lastNewestId = n.messageId
        if (prev == null || prev == n.messageId) return@LaunchedEffect
        val prevIdx = messages.indexOfLast { it.messageId == prev }
        val rekeyed = prevIdx < 0 // e.g. a pending message got its real id: not a new message
        val added = if (rekeyed) 0 else messages.lastIndex - prevIdx
        val atBottom = listState.firstVisibleItemIndex <= added // the old newest message has moved down by `added`
        if (atBottom || (!rekeyed && n.fromMe)) listState.animateScrollToItem(0)
    }

    // "N unread messages" divider: remember where the unread ones started before they are marked read.
    var unreadDivider by remember(chatId) { mutableStateOf<Pair<String, Int>?>(null) }
    var dividerChecked by remember(chatId) { mutableStateOf(false) }

    // With many unread messages open the chat at the divider instead of the bottom.
    LaunchedEffect(unreadDivider, messages.isNotEmpty()) {
        val d = unreadDivider ?: return@LaunchedEffect
        if (d.second < 6 || messages.isEmpty()) return@LaunchedEffect // few unread: they are on screen anyway
        val idx = messages.indexOfFirst { it.messageId == d.first }
        if (idx < 0) return@LaunchedEffect
        snapshotFlow { listState.layoutInfo.viewportSize.height }.first { it > 0 }
        val h = listState.layoutInfo.viewportSize.height
        // Reversed list (bottom = newest): a negative offset lifts the divider towards the top of the screen.
        listState.scrollToItem(messages.lastIndex - idx, -(h * 0.7f).toInt())
    }

    val selecting = selected.isNotEmpty()
    val selectedMessages = messages.filter { it.messageId in selected }

    // Take over files/text shared or forwarded here once this chat was chosen as the target.
    LaunchedEffect(share, chatId) {
        val s = share
        if (s != null && s.target == chatId) {
            if (s.files.isNotEmpty()) {
                attach = s.files
                captionSeed = s.text
            } else if (s.text.isNotBlank()) {
                draft = s.text
            }
            app.pendingShare.value = null
        }
    }

    // While this chat is visible: acknowledge incoming messages (read receipts) and clear unread.
    LaunchedEffect(chatId, foreground) {
        if (foreground) repo.openChat(chatId) else repo.closeChat()
    }
    LaunchedEffect(chatId, foreground, messages.size) {
        if (foreground) {
            if (!dividerChecked) {
                dividerChecked = true
                val pending = repo.unreadSnapshot(chatId).filter { it.kind != "deleted" }
                if (pending.isNotEmpty()) unreadDivider = pending.minBy { it.timestamp }.messageId to pending.size
            }
            repo.markConversationRead(chatId)
            Notifier.cancel(ctx, chatId)
        }
    }
    DisposableEffect(chatId) { onDispose { repo.closeChat() } }

    // Recording must not continue in the background (and "Ask every time" revokes the permission there).
    LaunchedEffect(foreground) {
        if (!foreground && app.voice.state.value is VoiceState.Recording) app.voice.stop()
    }

    val pickMedia = rememberLauncherForActivityResult(ActivityResultContracts.PickMultipleVisualMedia(10)) { uris ->
        if (uris.isNotEmpty()) scope.launch {
            captionSeed = ""
            attach = withContext(Dispatchers.IO) { uris.mapNotNull { MediaFiles.importUri(ctx, it) } }
        }
    }
    val pickFiles = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        if (uris.isNotEmpty()) scope.launch {
            captionSeed = ""
            attach = withContext(Dispatchers.IO) { uris.mapNotNull { MediaFiles.importUri(ctx, it) } }
        }
    }

    fun startRecording() {
        try {
            app.player.stop()
            app.voice.start(chatId)
        } catch (e: Exception) {
            Toast.makeText(ctx, "Cannot start recording", Toast.LENGTH_SHORT).show()
        }
    }
    // The permission is checked on every tap and never remembered, so "Ask every time" works.
    val micPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) startRecording() else Toast.makeText(ctx, "Microphone permission denied", Toast.LENGTH_SHORT).show()
    }
    fun onMicClick() {
        if (ctx.checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) startRecording()
        else micPermission.launch(Manifest.permission.RECORD_AUDIO)
    }

    fun playAudio(m: MessageEntity) {
        scope.launch {
            val path = if (hasFile(m)) m.mediaPath else {
                repo.downloadMedia(chatId, m.messageId)
                repo.mediaPath(chatId, m.messageId)
            }
            if (path != null) app.player.toggle(m.messageId, path)
        }
    }

    fun toggleSelect(id: String) {
        selected = if (id in selected) selected - id else selected + id
    }

    fun onTap(m: MessageEntity) {
        when {
            selecting -> toggleSelect(m.messageId)
            m.status == STATUS_FAILED -> scope.launch { repo.retry(chatId, m.messageId) }
            m.kind == "audio" -> playAudio(m)
            m.kind == "image" || m.kind == "video" -> {
                if (hasFile(m)) onViewMedia(m.messageId)
                else if (!m.fromMe) scope.launch { repo.downloadMedia(chatId, m.messageId) }
            }
            m.kind == "document" -> {
                if (hasFile(m)) openFile(ctx, m.mediaPath, m.mimeType)
                else if (!m.fromMe) scope.launch { repo.downloadMedia(chatId, m.messageId) }
            }
        }
    }

    fun forward(list: List<MessageEntity>) {
        scope.launch {
            val skipped = startForward(ctx, app, list)
            if (skipped > 0) Toast.makeText(ctx, "$skipped item(s) skipped (not downloaded or not forwardable)", Toast.LENGTH_SHORT).show()
        }
    }

    Column(Modifier.fillMaxSize().statusBarsPadding().imePadding()) {
        if (selecting) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = { selected = emptySet() }) { Icon(Icons.Default.Close, contentDescription = "Clear selection") }
                Text("${selected.size} selected", style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
                if (selectedMessages.size == 1 && canReply(selectedMessages[0])) {
                    TextButton(onClick = { replyTo = selectedMessages[0]; selected = emptySet() }) { Text("Reply") }
                }
                TextButton(onClick = { forward(selectedMessages); selected = emptySet() }) { Text("Forward") }
                TextButton(onClick = { confirmDelete = true }) { Text("Delete") }
                Box {
                    IconButton(onClick = { moreMenu = true }) { Icon(Icons.Default.MoreVert, contentDescription = "More") }
                    DropdownMenu(expanded = moreMenu, onDismissRequest = { moreMenu = false }) {
                        if (selectedMessages.any { it.text.isNotBlank() && it.kind != "deleted" }) {
                            DropdownMenuItem(text = { Text("Copy") }, onClick = {
                                moreMenu = false
                                val text = selectedMessages.filter { it.kind != "deleted" && it.text.isNotBlank() }.joinToString("\n") { it.text }
                                ctx.getSystemService(ClipboardManager::class.java).setPrimaryClip(ClipData.newPlainText("messages", text))
                                selected = emptySet()
                            })
                        }
                        val one = selectedMessages.singleOrNull()
                        if (one != null && one.kind != "deleted" && chatId != "status@broadcast" && !chatId.endsWith("@newsletter")) {
                            if (one.status != STATUS_SENDING && one.status != STATUS_FAILED) {
                                DropdownMenuItem(text = { Text("React") }, onClick = { moreMenu = false; reactFor = one; selected = emptySet() })
                            }
                            if (canEditMessage(one)) {
                                DropdownMenuItem(text = { Text("Edit") }, onClick = { moreMenu = false; editing = one; draft = one.text; selected = emptySet() })
                            }
                            if (one.fromMe) {
                                DropdownMenuItem(text = { Text("Info") }, onClick = { moreMenu = false; infoFor = one; selected = emptySet() })
                            }
                        }
                    }
                }
            }
        } else {
            if (searching) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = { searching = false; query = "" }) { Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Close search") }
                    OutlinedTextField(
                        value = query,
                        onValueChange = { query = it },
                        placeholder = { Text("Search in chat") },
                        singleLine = true,
                        modifier = Modifier.weight(1f),
                    )
                    Text(
                        if (results.isEmpty()) (if (query.isBlank()) "" else "0") else "${resultIdx + 1}/${results.size}",
                        style = MaterialTheme.typography.labelMedium,
                        modifier = Modifier.padding(horizontal = 6.dp),
                    )
                    IconButton(enabled = resultIdx > 0, onClick = { resultIdx-- }) { Icon(Icons.Default.KeyboardArrowUp, contentDescription = "Previous match") }
                    IconButton(enabled = resultIdx < results.lastIndex, onClick = { resultIdx++ }) { Icon(Icons.Default.KeyboardArrowDown, contentDescription = "Next match") }
                }
            } else Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back") }
                val title = chat?.displayTitle ?: chatId.substringBefore('@')
                val isChannel = chatId.endsWith("@newsletter")
                val personal = chat?.isGroup != true && !isChannel
                Row(
                    Modifier.weight(1f).clickable(enabled = !isChannel) { if (personal) onOpenInfo(chatId) else onOpenGroup(chatId) },
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Avatar(chatId, title, Modifier.padding(end = 10.dp).size(36.dp), MaterialTheme.typography.titleSmall)
                    Column {
                        Text(title, style = MaterialTheme.typography.titleMedium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        typingMap[chatId]?.let { t ->
                            Text(
                                if (t.second == "recording") "recording audio…" else "typing…",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.primary,
                            )
                        }
                    }
                }
                IconButton(onClick = { searching = true }) { Icon(Icons.Default.Search, contentDescription = "Search in chat") }
                IconButton(onClick = { showActions = true }) { Icon(Icons.Default.MoreVert, contentDescription = "Chat options") }
            }
        }
        HorizontalDivider()

        Box(Modifier.weight(1f).fillMaxWidth().onGloballyPositioned { listBounds = it.boundsInWindow() }) {
        LazyColumn(
            state = listState,
            modifier = Modifier.fillMaxSize(),
            reverseLayout = true,
            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp),
        ) {
            items(messages.asReversed(), key = { it.messageId }) { m ->
              Column(Modifier.fillMaxWidth()) {
                if (m.messageId == unreadDivider?.first) UnreadDivider(unreadDivider?.second ?: 0)
                SwipeToAct(
                    enabled = !selecting && m.kind != "deleted",
                    onReply = { if (canReply(m)) replyTo = m },
                    onForward = {
                        if (canForward(m)) forward(listOf(m))
                        else Toast.makeText(ctx, "Nothing to forward (download the media first)", Toast.LENGTH_SHORT).show()
                    },
                ) {
                    Bubble(
                        m,
                        isGroup = chat?.isGroup == true,
                        downloading = m.messageId in downloading,
                        selected = m.messageId in selected,
                        player = playerState,
                        onTap = { onTap(m) },
                        onLong = { r -> if (selecting) toggleSelect(m.messageId) else menuFor = m to r },
                        onPlay = { playAudio(m) },
                        onSender = { onOpenInfo(m.senderId) },
                        highlighted = m.messageId == currentHit?.messageId || m.messageId == menuFor?.first?.messageId,
                    )
                }
              }
            }
        }
        if (showJump) {
            SmallFloatingActionButton(
                onClick = { scope.launch { listState.animateScrollToItem(0) } },
                modifier = Modifier.align(Alignment.BottomEnd).padding(12.dp),
            ) { Icon(Icons.Default.KeyboardArrowDown, contentDescription = "Go to latest message") }
        }
        }

        error?.let {
            Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(horizontal = 12.dp))
        }

        editing?.let {
            Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.width(3.dp).height(32.dp).background(MaterialTheme.colorScheme.primary))
                Text("Editing message", style = MaterialTheme.typography.labelMedium, modifier = Modifier.weight(1f).padding(start = 8.dp))
                IconButton(onClick = { editing = null; draft = "" }) { Icon(Icons.Default.Close, contentDescription = "Cancel edit") }
            }
        }

        replyTo?.let { r ->
            Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.width(3.dp).height(32.dp).background(MaterialTheme.colorScheme.primary))
                Column(Modifier.weight(1f).padding(start = 8.dp)) {
                    Text(
                        if (r.fromMe) "Replying to yourself" else "Replying to ${r.senderName.ifBlank { chat?.displayTitle.orEmpty() }}",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.primary,
                    )
                    Text(repo.quoteText(r), maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodySmall)
                }
                IconButton(onClick = { replyTo = null }) { Icon(Icons.Default.Close, contentDescription = "Cancel reply") }
            }
        }

        val recording = (voiceState as? VoiceState.Recording)?.takeIf { it.chatId == chatId }
        val ready = (voiceState as? VoiceState.Ready)?.takeIf { it.chatId == chatId }
        when {
            recording != null -> {
                var now by remember { mutableLongStateOf(SystemClock.elapsedRealtime()) }
                LaunchedEffect(recording.startedAt) {
                    while (true) {
                        now = SystemClock.elapsedRealtime()
                        if (now - recording.startedAt >= 300_000) { app.voice.stop(); break } // 5 min limit
                        delay(250)
                    }
                }
                Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("● Recording  ${mmss((now - recording.startedAt) / 1000)}", color = MaterialTheme.colorScheme.error, modifier = Modifier.weight(1f))
                    TextButton(onClick = { app.voice.discard() }) { Text("Cancel") }
                    Button(onClick = {
                        if (app.voice.stop() != null) {
                            app.voice.take()?.let { t -> scope.launch { repo.sendVoice(chatId, t.path, t.secs, t.waveform) } }
                        }
                    }) { Text("Send") }
                }
            }
            ready != null -> Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("Voice note ${mmss(ready.secs.toLong())}", modifier = Modifier.weight(1f))
                TextButton(onClick = { app.voice.discard() }) { Text("Discard") }
                Button(onClick = {
                    app.voice.take()?.let { t -> scope.launch { repo.sendVoice(chatId, t.path, t.secs, t.waveform) } }
                }) { Text("Send") }
            }
            else -> Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.Bottom) {
                Box {
                    IconButton(onClick = { attachMenu = true }) { Icon(Icons.Default.Add, contentDescription = "Attach") }
                    DropdownMenu(expanded = attachMenu, onDismissRequest = { attachMenu = false }) {
                        DropdownMenuItem(text = { Text("Photo or video") }, onClick = {
                            attachMenu = false
                            pickMedia.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageAndVideo))
                        })
                        DropdownMenuItem(text = { Text("File") }, onClick = {
                            attachMenu = false
                            pickFiles.launch(arrayOf("*/*"))
                        })
                    }
                }
                OutlinedTextField(
                    value = draft,
                    onValueChange = { draft = it; repo.notifyTyping(chatId, it.isNotBlank() && editing == null) },
                    placeholder = { Text("Message") },
                    maxLines = 5,
                    modifier = Modifier.weight(1f),
                )
                if (draft.isBlank()) {
                    IconButton(onClick = { onMicClick() }) {
                        Icon(painterResource(R.drawable.ic_mic), contentDescription = "Record voice note")
                    }
                } else {
                    IconButton(onClick = {
                        val text = draft.trim()
                        val quoted = replyTo
                        val edit = editing
                        draft = ""
                        replyTo = null
                        editing = null
                        repo.notifyTyping(chatId, false)
                        if (edit != null) scope.launch { repo.editMessage(chatId, edit.messageId, text) }
                        else scope.launch { repo.sendText(chatId, text, quoted) }
                    }) { Icon(Icons.AutoMirrored.Filled.Send, contentDescription = "Send") }
                }
            }
        }
    }

    // ---- long-press menu ----
    menuFor?.let { (m, rect) ->
        val canReact = chatId != "status@broadcast" && !chatId.endsWith("@newsletter") && m.kind != "deleted" &&
            m.status != STATUS_SENDING && m.status != STATUS_FAILED
        val entries = buildList {
            if (canReply(m)) add(MenuEntry("Reply") { replyTo = m })
            if (m.text.isNotBlank() && m.kind != "deleted") {
                add(MenuEntry("Copy") {
                    ctx.getSystemService(ClipboardManager::class.java).setPrimaryClip(ClipData.newPlainText("message", m.text))
                })
            }
            if (m.kind != "deleted") add(MenuEntry("Forward") { forward(listOf(m)) })
            if (canEditMessage(m) && chatId != "status@broadcast" && !chatId.endsWith("@newsletter")) {
                add(MenuEntry("Edit") { editing = m; draft = m.text })
            }
            if (m.fromMe && m.kind != "deleted" && chatId != "status@broadcast" && !chatId.endsWith("@newsletter")) {
                add(MenuEntry("Info") { infoFor = m })
            }
            add(MenuEntry("Delete", destructive = true) { selected = setOf(m.messageId); confirmDelete = true })
            add(MenuEntry("Select") { toggleSelect(m.messageId) })
        }
        MessageMenuPopup(
            bounds = rect,
            area = listBounds,
            fromMe = m.fromMe,
            myReaction = Reactions.mine(m.reactions),
            showReactions = canReact,
            entries = entries,
            onReact = { e -> scope.launch { repo.react(chatId, m.messageId, e) } },
            onDismiss = { menuFor = null },
        )
    }

    // ---- reaction picker / message info ----
    reactFor?.let { m ->
        AlertDialog(
            onDismissRequest = { reactFor = null },
            title = { Text("React") },
            text = {
                val mine = Reactions.mine(m.reactions)
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                    listOf("👍", "❤️", "😂", "😮", "😢", "🙏").forEach { e ->
                        Text(
                            e,
                            style = MaterialTheme.typography.headlineSmall,
                            modifier = Modifier
                                .background(if (e == mine) MaterialTheme.colorScheme.primary.copy(alpha = 0.2f) else Color.Transparent, RoundedCornerShape(8.dp))
                                .clickable { reactFor = null; scope.launch { repo.react(chatId, m.messageId, e) } }
                                .padding(6.dp),
                        )
                    }
                }
            },
            confirmButton = {},
            dismissButton = { TextButton(onClick = { reactFor = null }) { Text("Close") } },
        )
    }
    infoFor?.let { m ->
        val fmt = remember { java.text.DateFormat.getDateTimeInstance(java.text.DateFormat.MEDIUM, java.text.DateFormat.SHORT) }
        fun at(ms: Long) = if (ms > 0) fmt.format(java.util.Date(ms)) else "—"
        AlertDialog(
            onDismissRequest = { infoFor = null },
            title = { Text("Message info") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(m.text.ifBlank { "(no text)" }, maxLines = 3, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodySmall)
                    Text("Sent: ${at(m.timestamp)}")
                    Text("Delivered: ${at(m.deliveredAt)}")
                    Text("Read: ${at(m.readAt)}")
                    if (chat?.isGroup == true) {
                        Text(
                            "Group chats: the times are those of the first recipient; per-person receipts are not available.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                }
            },
            confirmButton = { TextButton(onClick = { infoFor = null }) { Text("Close") } },
        )
    }

    // ---- attachment confirmation ----
    if (attach.isNotEmpty()) {
        var caption by remember(attach) { mutableStateOf(captionSeed) }
        AlertDialog(
            onDismissRequest = { attach.forEach { File(it.path).delete() }; attach = emptyList() },
            title = { Text("Send ${attach.size} file(s)?") },
            text = {
                Column {
                    attach.take(5).forEach {
                        Text("${it.name}  ${MediaFiles.formatSize(it.size)}", style = MaterialTheme.typography.bodySmall)
                    }
                    if (attach.size > 5) Text("+ ${attach.size - 5} more", style = MaterialTheme.typography.bodySmall)
                    OutlinedTextField(
                        value = caption,
                        onValueChange = { caption = it },
                        label = { Text("Caption (optional)") },
                        modifier = Modifier.padding(top = 12.dp),
                    )
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    val files = attach
                    attach = emptyList()
                    scope.launch {
                        files.forEachIndexed { i, f -> repo.sendMedia(chatId, f, if (i == 0) caption.trim() else "") }
                    }
                }) { Text("Send") }
            },
            dismissButton = {
                TextButton(onClick = { attach.forEach { File(it.path).delete() }; attach = emptyList() }) { Text("Cancel") }
            },
        )
    }

    // ---- delete selection ----
    if (confirmDelete) {
        val canAll = selectedMessages.isNotEmpty() && selectedMessages.all {
            it.fromMe && it.kind != "deleted" &&
                (it.status == STATUS_SENT || it.status == STATUS_DELIVERED || it.status == STATUS_READ)
        }
        AlertDialog(
            onDismissRequest = { confirmDelete = false },
            title = { Text("Delete ${selectedMessages.size} message(s)?") },
            text = { Text(if (canAll) "You can remove them for everyone or only on this device." else "They will be removed on this device only.") },
            confirmButton = {
                Column {
                    TextButton(onClick = {
                        val ids = selectedMessages.map { it.messageId }
                        confirmDelete = false
                        selected = emptySet()
                        scope.launch { ids.forEach { repo.deleteForMe(chatId, it) } }
                    }) { Text("Delete for me") }
                    if (canAll) TextButton(onClick = {
                        val ids = selectedMessages.map { it.messageId }
                        confirmDelete = false
                        selected = emptySet()
                        scope.launch { ids.forEach { repo.deleteForEveryone(chatId, it) } }
                    }) { Text("Delete for everyone") }
                }
            },
            dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text("Cancel") } },
        )
    }

    chat?.let { if (showActions) ChatActionsDialog(it, onDismiss = { showActions = false }, onGone = onBack) }
}

/** Swipe right = reply, swipe left = forward. */
@Composable
internal fun SwipeToAct(
    enabled: Boolean,
    onReply: () -> Unit,
    onForward: () -> Unit,
    allowReply: Boolean = true,
    content: @Composable () -> Unit,
) {
    val threshold = with(LocalDensity.current) { 64.dp.toPx() }
    var drag by remember { mutableFloatStateOf(0f) }
    var dragging by remember { mutableStateOf(false) }
    val shown by animateFloatAsState(
        targetValue = if (dragging) drag else 0f,
        animationSpec = tween(if (dragging) 0 else 140),
        label = "swipe",
    )
    Box(
        Modifier.fillMaxWidth().pointerInput(enabled) {
            if (enabled) {
                detectHorizontalDragGestures(
                    onDragStart = { dragging = true },
                    onDragEnd = {
                        dragging = false
                        if (drag > threshold) onReply() else if (drag < -threshold) onForward()
                        drag = 0f
                    },
                    onDragCancel = { dragging = false; drag = 0f },
                ) { _, delta -> drag = (drag + delta * 0.6f).coerceIn(-threshold * 1.6f, if (allowReply) threshold * 1.6f else 0f) }
            }
        },
    ) {
        val hintAlpha = min(1f, abs(shown) / threshold)
        if (shown > 8f) Text("↩ Reply", Modifier.align(Alignment.CenterStart).padding(start = 8.dp).alpha(hintAlpha), style = MaterialTheme.typography.labelMedium)
        else if (shown < -8f) Text("Forward ➜", Modifier.align(Alignment.CenterEnd).padding(end = 8.dp).alpha(hintAlpha), style = MaterialTheme.typography.labelMedium)
        Box(Modifier.offset { IntOffset(shown.roundToInt(), 0) }) { content() }
    }
}

/** Forward = open the "Share to…" chooser; once a chat is picked each message is sent on its own. Returns how many were skipped. */
/** Channel posts keep their channel attribution when forwarded (WhatsApp shows "Forwarded from <channel>"). */
private suspend fun originOf(app: ClassicApp, m: MessageEntity): String =
    if (m.chatId.endsWith("@newsletter")) app.repo.channelOrigin(m) else ""

internal suspend fun startForward(ctx: Context, app: ClassicApp, list: List<MessageEntity>): Int {
    val items = mutableListOf<ForwardItem>()
    var skipped = 0
    withContext(Dispatchers.IO) {
        for (m in list) {
            when {
                m.kind == "text" && m.text.isNotBlank() -> items += ForwardItem(text = m.text, origin = originOf(app, m))
                m.kind in MEDIA_KINDS && hasFile(m) -> {
                    val src = File(m.mediaPath)
                    val dir = File(ctx.cacheDir, "outgoing").apply { mkdirs() }
                    val name = m.fileName.ifBlank { src.name }
                    val copy = File(dir, UUID.randomUUID().toString() + "-" + MediaFiles.safe(name))
                    src.copyTo(copy, overwrite = true)
                    items += ForwardItem(
                        text = m.text,
                        file = PendingFile(copy.path, name, m.mimeType.ifBlank { "application/octet-stream" }, copy.length()),
                        voice = m.voice,
                        durationSecs = m.durationSecs,
                        origin = originOf(app, m),
                    )
                }
                else -> skipped++
            }
        }
    }
    if (items.isNotEmpty()) {
        app.pendingShare.value = ShareRequest(emptyList(), "", forward = items)
    }
    return skipped
}

private fun openFile(ctx: Context, path: String, mime: String) {
    try {
        val uri = FileProvider.getUriForFile(ctx, "${ctx.packageName}.files", File(path))
        val i = Intent(Intent.ACTION_VIEW)
            .setDataAndType(uri, mime.ifBlank { "*/*" })
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        ctx.startActivity(i)
    } catch (e: ActivityNotFoundException) {
        Toast.makeText(ctx, "No app can open this file", Toast.LENGTH_SHORT).show()
    } catch (e: Exception) {
        Toast.makeText(ctx, "Cannot open file", Toast.LENGTH_SHORT).show()
    }
}

@Composable
internal fun rememberBitmap(path: String, maxSide: Int): ImageBitmap? {
    val state = produceState<ImageBitmap?>(null, path) {
        value = if (path.isBlank()) null
        else withContext(Dispatchers.IO) { MediaFiles.decodeSampled(path, maxSide)?.asImageBitmap() }
    }
    return state.value
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun Bubble(
    m: MessageEntity,
    isGroup: Boolean,
    downloading: Boolean,
    selected: Boolean,
    player: PlayerState,
    onTap: () -> Unit,
    onLong: (Rect?) -> Unit,
    onPlay: () -> Unit,
    onSender: () -> Unit,
    highlighted: Boolean = false,
) {
    val bubbleCtx = LocalContext.current
    var coords by remember { mutableStateOf<LayoutCoordinates?>(null) }
    val hasReactions = m.reactions.isNotBlank() && m.kind != "deleted"
    Row(
        // The whole row is the touch target (like WhatsApp), not just the bubble.
        Modifier.fillMaxWidth()
            .combinedClickable(
                onClick = onTap,
                onLongClick = { onLong(coords?.takeIf { it.isAttached }?.boundsInWindow()) },
            )
            .background(
                when {
                    selected -> MaterialTheme.colorScheme.primary.copy(alpha = 0.18f)
                    highlighted -> MaterialTheme.colorScheme.tertiary.copy(alpha = 0.3f)
                    else -> Color.Transparent
                },
            ),
        horizontalArrangement = if (m.fromMe) Arrangement.End else Arrangement.Start,
    ) {
        Box(Modifier.padding(bottom = if (hasReactions) 12.dp else 0.dp)) {
        Surface(
            shape = RoundedCornerShape(6.dp),
            color = if (m.fromMe) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant,
            modifier = Modifier.widthIn(max = 300.dp).onGloballyPositioned { coords = it },
        ) {
            Column(Modifier.padding(horizontal = 10.dp, vertical = 6.dp)) {
                if (isGroup && !m.fromMe && m.senderName.isNotBlank()) {
                    Text(
                        m.senderName,
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.clickable(onClick = onSender),
                    )
                }
                if (m.forwarded && m.kind != "deleted") {
                    val from = m.forwardOrigin.split('\u0001').getOrNull(1).orEmpty()
                    Text(if (from.isNotBlank()) "↪ Forwarded from $from" else "↪ Forwarded", style = MaterialTheme.typography.labelSmall, fontStyle = FontStyle.Italic, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                if (m.replyToId.isNotBlank() && m.kind != "deleted") {
                    Row(Modifier.padding(bottom = 4.dp).height(IntrinsicSize.Min)) {
                        Box(Modifier.width(3.dp).fillMaxHeight().background(MaterialTheme.colorScheme.primary))
                        Text(
                            m.replyToText.ifBlank { "Message" },
                            style = MaterialTheme.typography.bodySmall,
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.padding(start = 6.dp),
                        )
                    }
                }
                when (m.kind) {
                    "image", "video" -> MediaPreview(m, downloading)
                    "audio" -> AudioBubble(m, downloading, player, onPlay)
                    "document" -> Column(Modifier.padding(vertical = 4.dp)) {
                        Text(m.fileName.ifBlank { "File" }, style = MaterialTheme.typography.bodyMedium)
                        Text(
                            when {
                                downloading -> "Downloading…"
                                m.mediaPath.isNotBlank() -> "Tap to open · ${MediaFiles.formatSize(m.fileLength)}"
                                m.fromMe -> MediaFiles.formatSize(m.fileLength)
                                else -> "Tap to download · ${MediaFiles.formatSize(m.fileLength)}"
                            },
                            style = MaterialTheme.typography.labelSmall,
                        )
                    }
                    "viewonce" -> Text(
                        "View-once message. Open it on your phone.",
                        style = MaterialTheme.typography.bodyMedium,
                        fontStyle = FontStyle.Italic,
                    )
                    "deleted" -> Text(
                        if (m.fromMe) "You deleted this message" else "This message was deleted",
                        style = MaterialTheme.typography.bodyMedium,
                        fontStyle = FontStyle.Italic,
                    )
                }
                if (m.text.isNotBlank() && m.kind != "deleted") LinkText(m.text, MaterialTheme.typography.bodyMedium)

                Row(Modifier.align(Alignment.End), verticalAlignment = Alignment.CenterVertically) {
                    val dim = MaterialTheme.colorScheme.onSurfaceVariant
                    when (m.status) {
                        STATUS_SENDING -> Text("sending…", style = MaterialTheme.typography.labelSmall, color = dim)
                        STATUS_FAILED -> Text(
                            "failed to send · tap to retry",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.error,
                        )
                        else -> {
                            if (m.edited && m.kind != "deleted") Text("edited · ", style = MaterialTheme.typography.labelSmall, color = dim)
                            Text(formatTime(m.timestamp), style = MaterialTheme.typography.labelSmall, color = dim)
                            if (m.fromMe && m.kind != "deleted") {
                                val ticks = if (m.status == STATUS_SENT) " ✓" else " ✓✓"
                                Text(
                                    ticks,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = if (m.status == STATUS_READ) ReadBlue else dim,
                                )
                            }
                        }
                    }
                }
            }
        }
        if (hasReactions) {
            ReactionPill(
                m.reactions,
                Modifier.align(if (m.fromMe) Alignment.BottomStart else Alignment.BottomEnd)
                    .offset(x = if (m.fromMe) 8.dp else (-8).dp, y = 12.dp),
            )
        }
        }
    }
}

@Composable
private fun AudioBubble(m: MessageEntity, downloading: Boolean, ps: PlayerState, onPlay: () -> Unit) {
    val active = ps.messageId == m.messageId
    val totalMs = if (active && ps.durationMs > 0) ps.durationMs else m.durationSecs * 1000
    val fraction = if (active && totalMs > 0) (ps.positionMs.toFloat() / totalMs).coerceIn(0f, 1f) else 0f
    val shownSecs = if (active) (ps.positionMs / 1000).toLong() else m.durationSecs.toLong()
    Row(verticalAlignment = Alignment.CenterVertically) {
        if (downloading) {
            Box(Modifier.size(48.dp), contentAlignment = Alignment.Center) { CircularProgressIndicator(Modifier.size(24.dp)) }
        } else {
            IconButton(onClick = onPlay) {
                Icon(
                    painterResource(if (active && ps.playing) R.drawable.ic_pause else R.drawable.ic_play),
                    contentDescription = "Play",
                )
            }
        }
        Column(Modifier.width(150.dp)) {
            LinearProgressIndicator(progress = { fraction }, modifier = Modifier.fillMaxWidth())
            Text(
                (if (m.voice) "Voice message" else m.fileName.ifBlank { "Audio" }) + " · " + mmss(shownSecs),
                style = MaterialTheme.typography.labelSmall,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
        }
    }
}

@Composable
private fun MediaPreview(m: MessageEntity, downloading: Boolean) {
    val path = if (m.kind == "image" && m.mediaPath.isNotBlank()) m.mediaPath else m.thumbPath
    val bmp = rememberBitmap(path, 800)
    Box(
        Modifier.width(220.dp).height(160.dp).background(MaterialTheme.colorScheme.surface),
        contentAlignment = Alignment.Center,
    ) {
        if (bmp != null) {
            Image(bmp, contentDescription = null, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
        }
        val label = when {
            downloading -> null
            m.mediaPath.isNotBlank() && m.kind == "video" -> "▶ Play"
            m.mediaPath.isBlank() && !m.fromMe -> "Tap to download ${MediaFiles.formatSize(m.fileLength)}".trim()
            else -> null
        }
        if (downloading) CircularProgressIndicator()
        else if (label != null) {
            Surface(color = MaterialTheme.colorScheme.scrim.copy(alpha = 0.55f), shape = RoundedCornerShape(4.dp)) {
                Text(label, color = MaterialTheme.colorScheme.surface, modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp), style = MaterialTheme.typography.labelMedium)
            }
        }
    }
}

/** WhatsApp-style marker above the first message that was unread when the chat was opened. */
@Composable
private fun UnreadDivider(count: Int) {
    Box(Modifier.fillMaxWidth().padding(vertical = 6.dp), contentAlignment = Alignment.Center) {
        Text(
            if (count == 1) "1 unread message" else "$count unread messages",
            style = MaterialTheme.typography.labelMedium,
            color = MaterialTheme.colorScheme.onSecondaryContainer,
            modifier = Modifier
                .background(MaterialTheme.colorScheme.secondaryContainer, RoundedCornerShape(12.dp))
                .padding(horizontal = 12.dp, vertical = 4.dp),
        )
    }
}


/** WhatsApp lets you edit your own plain text messages for 15 minutes after sending them. */
private fun canEditMessage(m: MessageEntity): Boolean =
    m.fromMe && m.kind == "text" && m.replyToId.isBlank() && !m.forwarded &&
        m.status != STATUS_SENDING && m.status != STATUS_FAILED &&
        System.currentTimeMillis() - m.timestamp < 15 * 60_000L
