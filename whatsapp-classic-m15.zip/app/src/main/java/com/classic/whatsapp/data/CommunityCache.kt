package com.classic.whatsapp.data

import com.classic.whatsapp.messaging.Community
import com.classic.whatsapp.messaging.CommunityGroup
import java.io.File
import org.json.JSONArray
import org.json.JSONObject

/**
 * Last known communities and their groups, kept in one small JSON file so the tab can be shown offline and refreshed when a
 * connection is available. Failures to read or write are ignored: the cache is only a convenience. (Channels are not here:
 * their posts are ordinary stored messages.)
 */
class CommunityCache(private val file: File) {
    class Data(
        val communities: List<Community>?,
        val groups: Map<String, List<CommunityGroup>>,
    )

    private val lock = Any()

    fun load(): Data = synchronized(lock) {
        val root = read()
        Data(
            communities = root.optJSONArray("communities")?.objects()?.map { Community(it.getString("id"), it.getString("name")) },
            groups = root.optJSONObject("groups")?.let { g ->
                g.keys().asSequence().associateWith { id ->
                    g.getJSONArray(id).objects().map {
                        CommunityGroup(it.getString("id"), it.getString("name"), it.getBoolean("announcement"), it.getBoolean("general"), it.getInt("members"))
                    }
                }
            } ?: emptyMap(),
        )
    }

    /** Stores the community list; groups of communities that are no longer in it are dropped. */
    fun saveCommunities(list: List<Community>) = update { root ->
        root.put("communities", JSONArray(list.map { JSONObject().put("id", it.id).put("name", it.name) }))
        val keep = list.map { it.id }.toSet()
        root.optJSONObject("groups")?.let { g -> g.keys().asSequence().toList().filter { it !in keep }.forEach { g.remove(it) } }
    }

    fun saveGroups(communityId: String, list: List<CommunityGroup>) = update { root ->
        val g = root.optJSONObject("groups") ?: JSONObject().also { root.put("groups", it) }
        g.put(
            communityId,
            JSONArray(
                list.map {
                    JSONObject().put("id", it.id).put("name", it.name).put("announcement", it.announcement)
                        .put("general", it.general).put("members", it.members)
                },
            ),
        )
    }

    fun clear() = synchronized(lock) { file.delete(); Unit }

    private fun read(): JSONObject =
        runCatching { if (file.exists()) JSONObject(file.readText()) else JSONObject() }.getOrDefault(JSONObject())

    private fun update(change: (JSONObject) -> Unit) {
        synchronized(lock) {
            runCatching {
                val root = read()
                change(root)
                val tmp = File(file.path + ".tmp")
                tmp.writeText(root.toString())
                if (!tmp.renameTo(file)) { file.delete(); tmp.renameTo(file) }
            }
        }
    }

    private fun JSONArray.objects(): List<JSONObject> = (0 until length()).map { getJSONObject(it) }
}
