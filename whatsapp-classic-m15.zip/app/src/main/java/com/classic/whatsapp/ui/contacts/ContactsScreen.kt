package com.classic.whatsapp.ui.contacts

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material3.*
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.Person
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.classic.whatsapp.ClassicApp
import com.classic.whatsapp.data.SavedContactEntity
import com.classic.whatsapp.ui.Avatar
import kotlinx.coroutines.launch

/** The app's own address book (name + number, stored only on this device). Tap a contact to open a chat with it. */
@Composable
fun ContactsScreen(onBack: () -> Unit, onOpenChat: (String) -> Unit, onOpenInfo: (String) -> Unit = {}) {
    val repo = (LocalContext.current.applicationContext as ClassicApp).repo
    val scope = rememberCoroutineScope()
    val contacts by repo.savedContacts.collectAsState(initial = emptyList())
    var adding by remember { mutableStateOf(false) }
    var editing by remember { mutableStateOf<SavedContactEntity?>(null) }

    var newChat by remember { mutableStateOf(false) }

    Column(Modifier.fillMaxSize().statusBarsPadding()) {
        Row(Modifier.fillMaxWidth().padding(end = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back") }
            Text("Contacts", style = MaterialTheme.typography.titleLarge, modifier = Modifier.weight(1f))
        }
        LazyColumn(Modifier.fillMaxSize()) {
            item {
                ActionRow(Icons.Default.Add, "New chat") { newChat = true }
                ActionRow(Icons.Default.Person, "New contact") { adding = true }
                HorizontalDivider()
                if (contacts.isEmpty()) {
                    Text(
                        "No contacts yet.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(16.dp),
                    )
                }
            }
            items(contacts, key = { it.jid }) { c ->
                Row(
                    Modifier.fillMaxWidth()
                        .clickable { scope.launch { onOpenChat(repo.createChat(c.number)) } }
                        .padding(start = 16.dp, top = 8.dp, bottom = 8.dp, end = 4.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Avatar(c.jid, c.name, Modifier.padding(end = 12.dp).size(44.dp).clickable { onOpenInfo(c.jid) })
                    Column(Modifier.weight(1f)) {
                        Text(c.name, style = MaterialTheme.typography.titleMedium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text("+${c.number}", style = MaterialTheme.typography.bodySmall)
                    }
                    TextButton(onClick = { editing = c }) { Text("Edit") }
                }
                HorizontalDivider()
            }
        }
    }

    if (newChat) {
        var digits by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { newChat = false },
            title = { Text("New chat") },
            text = {
                OutlinedTextField(
                    value = digits,
                    onValueChange = { digits = it.filter(Char::isDigit) },
                    label = { Text("Number with country code") },
                    prefix = { Text("+") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                )
            },
            confirmButton = {
                TextButton(
                    enabled = digits.length in 8..15,
                    onClick = {
                        newChat = false
                        scope.launch { onOpenChat(repo.createChat(digits)) }
                    },
                ) { Text("Open") }
            },
            dismissButton = { TextButton(onClick = { newChat = false }) { Text("Cancel") } },
        )
    }

    if (adding || editing != null) {
        val initial = editing
        ContactDialog(
            initial = initial,
            onDismiss = { adding = false; editing = null },
            onSave = { name, digits ->
                adding = false
                editing = null
                scope.launch { repo.saveContact(name, digits, oldJid = initial?.jid) }
            },
            onDelete = initial?.let { c ->
                val delete: () -> Unit = {
                    editing = null
                    scope.launch { repo.deleteContact(c.jid) }
                }
                delete
            },
        )
    }
}

/**
 * Full-screen contact editor in the style of WhatsApp's "New contact": first and last name, phone with country code.
 * (The address book entry only exists in this app; it is never written to the phone's contacts.)
 */
@OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)
@Composable
internal fun ContactDialog(
    initial: SavedContactEntity?,
    onDismiss: () -> Unit,
    onSave: (name: String, digits: String) -> Unit,
    onDelete: (() -> Unit)?,
    prefillName: String = "",
    prefillDigits: String = "",
) {
    val startName = initial?.name ?: prefillName
    var first by remember { mutableStateOf(startName.substringBefore(' ')) }
    var last by remember { mutableStateOf(if (startName.contains(' ')) startName.substringAfter(' ') else "") }
    var digits by remember { mutableStateOf(initial?.number ?: prefillDigits) }
    var confirmDelete by remember { mutableStateOf(false) }
    val fullName = listOf(first.trim(), last.trim()).filter { it.isNotEmpty() }.joinToString(" ")
    val valid = fullName.isNotBlank() && digits.length in 8..15

    androidx.compose.ui.window.Dialog(
        onDismissRequest = onDismiss,
        properties = androidx.compose.ui.window.DialogProperties(usePlatformDefaultWidth = false),
    ) {
        Surface(Modifier.fillMaxSize()) {
            Column(Modifier.fillMaxSize().statusBarsPadding().imePadding()) {
                Row(Modifier.fillMaxWidth().padding(end = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = onDismiss) { Icon(Icons.Default.Close, contentDescription = "Cancel") }
                    Text(
                        if (initial == null) "New contact" else "Edit contact",
                        style = MaterialTheme.typography.titleLarge,
                        modifier = Modifier.weight(1f),
                    )
                    TextButton(enabled = valid, onClick = { onSave(fullName, digits) }) { Text("Save") }
                }
                HorizontalDivider()
                Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Person, contentDescription = null, modifier = Modifier.padding(end = 16.dp))
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedTextField(
                                value = first,
                                onValueChange = { first = it },
                                label = { Text("First name") },
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth(),
                            )
                            OutlinedTextField(
                                value = last,
                                onValueChange = { last = it },
                                label = { Text("Last name") },
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth(),
                            )
                        }
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Phone, contentDescription = null, modifier = Modifier.padding(end = 16.dp))
                        OutlinedTextField(
                            value = digits,
                            onValueChange = { digits = it.filter(Char::isDigit) },
                            label = { Text("Phone (with country code)") },
                            prefix = { Text("+") },
                            singleLine = true,
                            isError = digits.isNotEmpty() && digits.length !in 8..15,
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                            modifier = Modifier.fillMaxWidth(),
                        )
                    }
                    if (onDelete != null) {
                        TextButton(onClick = { confirmDelete = true }) { Text("Delete contact", color = MaterialTheme.colorScheme.error) }
                    }
                }
            }
        }
    }
    if (confirmDelete && onDelete != null) {
        AlertDialog(
            onDismissRequest = { confirmDelete = false },
            title = { Text("Delete contact?") },
            text = { Text("Removes this name from the address book of this app. The chat stays.") },
            confirmButton = { TextButton(onClick = { confirmDelete = false; onDelete() }) { Text("Delete") } },
            dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text("Cancel") } },
        )
    }
}

@Composable
private fun ActionRow(icon: androidx.compose.ui.graphics.vector.ImageVector, label: String, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 16.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(icon, contentDescription = null, modifier = Modifier.padding(end = 28.dp))
        Text(label, style = MaterialTheme.typography.titleMedium)
    }
}
