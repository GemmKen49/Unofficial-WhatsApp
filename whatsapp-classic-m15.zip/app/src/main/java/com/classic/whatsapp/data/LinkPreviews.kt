package com.classic.whatsapp.data

import android.text.Html
import java.net.HttpURLConnection
import java.net.URL
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/** Title and description of a web page, read from its Open Graph (or plain HTML) tags. */
data class LinkPreviewData(val url: String, val title: String, val description: String)

/** Fetches link previews for messages we send. Only https pages, short timeouts, first 256 KB only. */
object LinkPreviews {
    private val urlRegex = Regex("https://[^\\s<>\"]+", RegexOption.IGNORE_CASE)
    private val metaRegex = Regex("<meta\\s[^>]*>", RegexOption.IGNORE_CASE)
    private val titleRegex = Regex("<title[^>]*>(.*?)</title>", setOf(RegexOption.IGNORE_CASE, RegexOption.DOT_MATCHES_ALL))

    fun firstUrl(text: String): String? = urlRegex.find(text)?.value?.trimEnd('.', ',', ')', ']', '!', '?', ';')

    suspend fun fetch(url: String): LinkPreviewData? =
        withContext(Dispatchers.IO) {
            try {
                val conn = URL(url).openConnection() as HttpURLConnection
                try {
                    conn.connectTimeout = 5_000
                    conn.readTimeout = 5_000
                    conn.setRequestProperty("User-Agent", "Mozilla/5.0 (compatible; LinkPreview)")
                    conn.setRequestProperty("Accept", "text/html")
                    if (conn.responseCode != 200) return@withContext null
                    if (conn.contentType?.contains("html", ignoreCase = true) == false) return@withContext null
                    val html = conn.inputStream.use { input ->
                        val buf = ByteArray(256 * 1024)
                        var n = 0
                        while (n < buf.size) {
                            val r = input.read(buf, n, buf.size - n)
                            if (r < 0) break
                            n += r
                        }
                        String(buf, 0, n, Charsets.UTF_8)
                    }
                    parse(url, html)
                } finally {
                    conn.disconnect()
                }
            } catch (e: Exception) {
                null
            }
        }

    internal fun parse(url: String, html: String): LinkPreviewData? {
        val props = HashMap<String, String>()
        for (m in metaRegex.findAll(html)) {
            val tag = m.value
            val key = attr(tag, "property") ?: attr(tag, "name") ?: continue
            val value = attr(tag, "content") ?: continue
            props.putIfAbsent(key.lowercase(), value)
        }
        val title = props["og:title"] ?: titleRegex.find(html)?.groupValues?.get(1) ?: ""
        val desc = props["og:description"] ?: props["description"] ?: ""
        val cleanTitle = decode(title).trim().take(200)
        val cleanDesc = decode(desc).trim().take(300)
        if (cleanTitle.isEmpty() && cleanDesc.isEmpty()) return null
        return LinkPreviewData(url, cleanTitle, cleanDesc)
    }

    private fun attr(tag: String, name: String): String? =
        Regex("\\b$name\\s*=\\s*(\"([^\"]*)\"|'([^']*)')", RegexOption.IGNORE_CASE).find(tag)
            ?.let { it.groups[2]?.value ?: it.groups[3]?.value }

    @Suppress("DEPRECATION")
    private fun decode(s: String): String = Html.fromHtml(s, Html.FROM_HTML_MODE_LEGACY).toString().replace('\n', ' ')
}

/** Reactions are stored one "senderId<TAB>emoji" per line; "me" is our own. */
object Reactions {
    const val ME = "me"

    fun parse(s: String): List<Pair<String, String>> =
        s.lineSequence().filter { it.isNotBlank() }.mapNotNull { l ->
            val i = l.indexOf('\t')
            if (i <= 0) null else l.substring(0, i) to l.substring(i + 1)
        }.toList()

    fun encode(list: List<Pair<String, String>>): String = list.joinToString("\n") { "${it.first}\t${it.second}" }

    /** Sets (or with an empty [emoji], removes) the reaction of [who]. */
    fun with(s: String, who: String, emoji: String): String {
        val rest = parse(s).filter { it.first != who }
        return encode(if (emoji.isBlank()) rest else rest + (who to emoji))
    }

    fun mine(s: String): String = parse(s).firstOrNull { it.first == ME }?.second.orEmpty()

    /** emoji -> count, most used first. A sender written "*N" stands for N people (channel posts only report counts). */
    fun summary(s: String): List<Pair<String, Int>> {
        val counts = LinkedHashMap<String, Int>()
        val entries = parse(s)
        for ((who, emoji) in entries) {
            if (who.startsWith("*")) counts[emoji] = (counts[emoji] ?: 0) + (who.drop(1).toIntOrNull() ?: 1)
        }
        val counted = counts.keys.toSet()
        for ((who, emoji) in entries) {
            if (who.startsWith("*")) continue
            // Channel counts already include our own reaction.
            if (who == ME && emoji in counted) continue
            counts[emoji] = (counts[emoji] ?: 0) + 1
        }
        return counts.toList().sortedByDescending { it.second }
    }

    /** Count-only form used for channel posts. */
    fun encodeCounts(list: List<Pair<String, Long>>): String =
        list.filter { it.second > 0 }.joinToString("\n") { "*${it.second.coerceAtMost(Int.MAX_VALUE.toLong())}\t${it.first}" }
}
