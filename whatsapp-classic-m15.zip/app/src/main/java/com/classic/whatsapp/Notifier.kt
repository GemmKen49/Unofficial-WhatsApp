package com.classic.whatsapp

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent

object Notifier {
    const val EXTRA_CHAT_ID = "chat_id"
    private const val CH_SERVICE = "service"
    private const val CH_MESSAGES = "messages"
    private const val CH_CHANNELS = "channels"
    const val FGS_ID = 1

    fun ensureChannels(ctx: Context) {
        val nm = ctx.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CH_SERVICE, "Background connection", NotificationManager.IMPORTANCE_MIN),
        )
        nm.createNotificationChannel(
            NotificationChannel(CH_MESSAGES, "Messages", NotificationManager.IMPORTANCE_HIGH),
        )
        nm.createNotificationChannel(
            NotificationChannel(CH_CHANNELS, "Channels", NotificationManager.IMPORTANCE_LOW),
        )
    }

    private fun openApp(ctx: Context, chatId: String?): PendingIntent {
        val i = Intent(ctx, MainActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        if (chatId != null) i.putExtra(EXTRA_CHAT_ID, chatId)
        return PendingIntent.getActivity(
            ctx,
            chatId?.hashCode() ?: 0,
            i,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )
    }

    fun foreground(ctx: Context): Notification =
        Notification.Builder(ctx, CH_SERVICE)
            .setSmallIcon(R.drawable.ic_notif)
            .setContentTitle("WhatsApp Classic")
            .setContentText("Connected in the background")
            .setOngoing(true)
            .setContentIntent(openApp(ctx, null))
            .build()

    fun message(ctx: Context, chatId: String, title: String, text: String, timestampMs: Long) {
        // Channel posts use their own low-importance channel (no sound or heads-up).
        val ch = if (chatId.endsWith("@newsletter")) CH_CHANNELS else CH_MESSAGES
        val public = Notification.Builder(ctx, ch)
            .setSmallIcon(R.drawable.ic_notif)
            .setContentTitle("New message")
            .build()
        val n = Notification.Builder(ctx, ch)
            .setSmallIcon(R.drawable.ic_notif)
            .setContentTitle(title)
            .setContentText(text)
            .setStyle(Notification.BigTextStyle().bigText(text))
            .setWhen(timestampMs)
            .setShowWhen(true)
            .setAutoCancel(true)
            .setCategory(Notification.CATEGORY_MESSAGE)
            .setVisibility(Notification.VISIBILITY_PRIVATE)
            .setPublicVersion(public)
            .setContentIntent(openApp(ctx, chatId))
            .build()
        // No-op (not a crash) if the notification permission is denied.
        ctx.getSystemService(NotificationManager::class.java).notify(chatId.hashCode(), n)
    }

    fun cancel(ctx: Context, chatId: String) {
        ctx.getSystemService(NotificationManager::class.java).cancel(chatId.hashCode())
    }
}
