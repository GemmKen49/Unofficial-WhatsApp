package com.classic.whatsapp.ui

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.waitForUpOrCancellation
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextLayoutResult
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.style.TextDecoration
import kotlinx.coroutines.withTimeoutOrNull

private val urlRegex = Regex("https?://[^\\s<>\"]+", RegexOption.IGNORE_CASE)
private val HttpsBlue = Color(0xFF4FA3FF)
private val HttpRed = Color(0xFFFF5252)
private const val TRAILING = ".,;:!?)]}'\""

/**
 * Text whose web links are tappable: https:// links are blue, http:// links red. A tap never opens anything directly:
 * it first asks for confirmation and shows the exact address. Links are never previewed or fetched. Taps outside a
 * link are not consumed, so the surrounding message still reacts to them.
 */
@Composable
fun LinkText(
    text: String,
    style: TextStyle,
    modifier: Modifier = Modifier,
) {
    val ctx = LocalContext.current
    var pending by remember { mutableStateOf<String?>(null) }
    var layout by remember { mutableStateOf<TextLayoutResult?>(null) }
    val annotated = remember(text) {
        buildAnnotatedString {
            var last = 0
            for (m in urlRegex.findAll(text)) {
                var end = m.range.last + 1
                while (end > m.range.first && text[end - 1] in TRAILING) end--
                if (end <= m.range.first) continue
                append(text.substring(last, m.range.first))
                val url = text.substring(m.range.first, end)
                val color = if (url.startsWith("https://", ignoreCase = true)) HttpsBlue else HttpRed
                val start = length
                append(url)
                addStyle(SpanStyle(color = color, textDecoration = TextDecoration.Underline), start, length)
                addStringAnnotation("URL", url, start, length)
                last = end
            }
            append(text.substring(last))
        }
    }

    Text(
        annotated,
        style = style,
        onTextLayout = { layout = it },
        modifier = modifier.pointerInput(annotated) {
            awaitEachGesture {
                val down = awaitFirstDown(requireUnconsumed = false)
                val offset = layout?.getOffsetForPosition(down.position)
                val url = offset?.let { o -> annotated.getStringAnnotations("URL", o, o).firstOrNull()?.item }
                if (url != null) {
                    // A long press belongs to the message (menu), only a short tap opens the link dialog.
                    val up = withTimeoutOrNull(viewConfiguration.longPressTimeoutMillis) { waitForUpOrCancellation() }
                    if (up != null) {
                        up.consume()
                        pending = url
                    }
                }
            }
        },
    )

    pending?.let { url ->
        AlertDialog(
            onDismissRequest = { pending = null },
            text = { Text("You're going to open this link:\n$url\nAre you sure to proceed?") },
            dismissButton = { TextButton(onClick = { pending = null }) { Text("Back") } },
            confirmButton = {
                TextButton(onClick = {
                    pending = null
                    try {
                        ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                    } catch (e: Exception) {
                        // nothing can open it
                    }
                }) { Text("Proceed") }
            },
        )
    }
}
