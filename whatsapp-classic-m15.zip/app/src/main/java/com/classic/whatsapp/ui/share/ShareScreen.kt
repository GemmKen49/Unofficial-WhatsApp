package com.classic.whatsapp.ui.share

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.classic.whatsapp.ClassicApp

/** "Share to..." chooser shown when another app shares files or text into this app. */
@Composable
fun ShareScreen(onChosen: (String) -> Unit, onCancel: () -> Unit) {
    val app = LocalContext.current.applicationContext as ClassicApp
    val share by app.pendingShare.collectAsState()
    val chats by app.repo.chats.collectAsState(initial = emptyList())
    var query by remember { mutableStateOf("") }

    Column(Modifier.fillMaxSize().statusBarsPadding()) {
        Row(Modifier.fillMaxWidth().padding(start = 16.dp, end = 8.dp, top = 8.dp)) {
            Column(Modifier.weight(1f)) {
                Text("Share to…", style = MaterialTheme.typography.titleLarge)
                val n = share?.files?.size ?: 0
                val f = share?.forward?.size ?: 0
                Text(
                    if (f > 0) "Forward $f message(s)" else if (n > 0) "$n file(s)" else "Text",
                    style = MaterialTheme.typography.bodySmall,
                )
            }
            TextButton(onClick = onCancel) { Text("Cancel") }
        }
        OutlinedTextField(
            value = query,
            onValueChange = { query = it },
            placeholder = { Text("Search") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
        )
        val list = chats.filter { query.isBlank() || it.displayTitle.contains(query, ignoreCase = true) }
        if (list.isEmpty()) {
            Box(Modifier.fillMaxSize().padding(32.dp)) {
                Text("No chats yet. Start one with + in Chats first.")
            }
        } else {
            LazyColumn(Modifier.fillMaxSize()) {
                items(list, key = { it.chatId }) { c ->
                    Text(
                        c.displayTitle,
                        style = MaterialTheme.typography.titleMedium,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.fillMaxWidth().clickable { onChosen(c.chatId) }.padding(16.dp),
                    )
                }
            }
        }
    }
}
