package com.classic.whatsapp.ui.media

import android.net.Uri
import android.widget.Toast
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.calculatePan
import androidx.compose.foundation.gestures.calculateZoom
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.positionChange
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import com.classic.whatsapp.ClassicApp
import com.classic.whatsapp.data.MediaFiles
import com.classic.whatsapp.data.MessageEntity
import com.classic.whatsapp.ui.conversation.rememberBitmap
import com.classic.whatsapp.ui.formatTime
import java.io.File
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private fun isViewable(m: MessageEntity) =
    (m.kind == "image" || m.kind == "video") && m.mediaPath.isNotBlank() && File(m.mediaPath).exists()

/** Full-screen viewer for the downloaded photos and videos of one chat: swipe between them, pinch to zoom. */
@Composable
fun MediaViewerScreen(chatId: String, messageId: String, onBack: () -> Unit) {
    val app = LocalContext.current.applicationContext as ClassicApp
    val all by app.repo.messages(chatId).collectAsState(initial = null as List<MessageEntity>?)
    val list = all
    if (list == null) {
        Box(Modifier.fillMaxSize().background(Color.Black))
        return
    }
    val items = list.filter(::isViewable)
    if (items.isEmpty()) {
        LaunchedEffect(Unit) { onBack() }
        Box(Modifier.fillMaxSize().background(Color.Black))
        return
    }
    Viewer(items, messageId, onBack)
}

@Composable
private fun Viewer(items: List<MessageEntity>, startId: String, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val app = ctx.applicationContext as ClassicApp
    val scope = rememberCoroutineScope()
    val foreground by app.repo.foreground.collectAsState()
    val pager = rememberPagerState(initialPage = items.indexOfFirst { it.messageId == startId }.coerceAtLeast(0)) { items.size }
    var chrome by remember { mutableStateOf(true) }

    val current = items[pager.currentPage.coerceIn(0, items.lastIndex)]
    val showChrome = chrome || current.kind == "video"

    Box(Modifier.fillMaxSize().background(Color.Black)) {
        HorizontalPager(state = pager, key = { items[it].messageId }, modifier = Modifier.fillMaxSize()) { page ->
            val m = items[page]
            if (m.kind == "video") {
                VideoPage(m, active = pager.settledPage == page, foreground = foreground)
            } else {
                ZoomableImage(m.mediaPath, onTap = { chrome = !chrome })
            }
        }

        if (showChrome) {
            Column(
                Modifier.align(Alignment.TopCenter).fillMaxWidth()
                    .background(Color.Black.copy(alpha = 0.55f)).statusBarsPadding().padding(bottom = 6.dp),
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = Color.White)
                    }
                    Column(Modifier.weight(1f)) {
                        Text(
                            (if (current.fromMe) "You" else current.senderName.ifBlank { current.senderId.substringBefore('@') }) +
                                " · " + formatTime(current.timestamp),
                            color = Color.White,
                            style = MaterialTheme.typography.titleSmall,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                        )
                        Text(
                            "${pager.currentPage + 1} / ${items.size}",
                            color = Color.White.copy(alpha = 0.7f),
                            style = MaterialTheme.typography.labelSmall,
                        )
                    }
                    TextButton(onClick = {
                        scope.launch {
                            val folder = withContext(Dispatchers.IO) {
                                MediaFiles.saveToGallery(ctx, current.mediaPath, current.kind, current.mimeType, current.fileName)
                            }
                            Toast.makeText(
                                ctx,
                                if (folder != null) "Saved to $folder" else "Could not save",
                                Toast.LENGTH_SHORT,
                            ).show()
                        }
                    }) { Text("Save", color = Color.White) }
                    TextButton(onClick = {
                        if (!MediaFiles.openWith(ctx, current.mediaPath, current.mimeType)) {
                            Toast.makeText(ctx, "No app can open this file", Toast.LENGTH_SHORT).show()
                        }
                    }) { Text("Open with", color = Color.White) }
                }
                if (current.text.isNotBlank()) {
                    Text(
                        current.text,
                        color = Color.White,
                        style = MaterialTheme.typography.bodyMedium,
                        maxLines = 3,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.padding(horizontal = 16.dp),
                    )
                }
            }
        }
    }
}

/** Pinch / double-tap to zoom, drag to pan while zoomed. At 1x, horizontal drags fall through to the pager. */
@Composable
private fun ZoomableImage(path: String, onTap: () -> Unit) {
    val bmp = rememberBitmap(path, 2560)
    var scale by remember { mutableFloatStateOf(1f) }
    var offset by remember { mutableStateOf(Offset.Zero) }
    Box(
        Modifier.fillMaxSize()
            .pointerInput(Unit) {
                detectTapGestures(
                    onTap = { onTap() },
                    onDoubleTap = {
                        if (scale > 1f) { scale = 1f; offset = Offset.Zero } else scale = 2.5f
                    },
                )
            }
            .pointerInput(Unit) {
                awaitEachGesture {
                    awaitFirstDown(requireUnconsumed = false)
                    do {
                        val event = awaitPointerEvent()
                        if (event.changes.size > 1 || scale > 1f) {
                            val newScale = (scale * event.calculateZoom()).coerceIn(1f, 6f)
                            val pan = event.calculatePan()
                            val maxX = size.width * (newScale - 1f) / 2f
                            val maxY = size.height * (newScale - 1f) / 2f
                            offset = Offset(
                                (offset.x + pan.x).coerceIn(-maxX, maxX),
                                (offset.y + pan.y).coerceIn(-maxY, maxY),
                            )
                            scale = newScale
                            event.changes.forEach { if (it.positionChange() != Offset.Zero) it.consume() }
                        }
                    } while (event.changes.any { it.pressed })
                }
            },
        contentAlignment = Alignment.Center,
    ) {
        if (bmp != null) {
            Image(
                bmp,
                contentDescription = null,
                contentScale = ContentScale.Fit,
                modifier = Modifier.fillMaxSize().graphicsLayer(
                    scaleX = scale, scaleY = scale, translationX = offset.x, translationY = offset.y,
                ),
            )
        } else {
            CircularProgressIndicator()
        }
    }
}

/** Plays with Media3 only while this page is the settled one; otherwise shows the thumbnail. */
@Composable
private fun VideoPage(m: MessageEntity, active: Boolean, foreground: Boolean) {
    if (!active) {
        val thumb = rememberBitmap(m.thumbPath, 800)
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            if (thumb != null) Image(thumb, contentDescription = null, contentScale = ContentScale.Fit, modifier = Modifier.fillMaxSize())
        }
        return
    }
    val ctx = LocalContext.current
    val exo = remember(m.mediaPath) {
        ExoPlayer.Builder(ctx).build().apply {
            setAudioAttributes(
                AudioAttributes.Builder().setUsage(C.USAGE_MEDIA).setContentType(C.AUDIO_CONTENT_TYPE_MOVIE).build(),
                true,
            )
            setMediaItem(MediaItem.fromUri(Uri.fromFile(File(m.mediaPath))))
            prepare()
            playWhenReady = true
        }
    }
    DisposableEffect(exo) { onDispose { exo.release() } }
    LaunchedEffect(foreground) { if (!foreground) exo.pause() }
    AndroidView(
        factory = { c -> PlayerView(c).apply { player = exo; setBackgroundColor(android.graphics.Color.BLACK) } },
        update = { it.player = exo },
        modifier = Modifier.fillMaxSize(),
    )
}
