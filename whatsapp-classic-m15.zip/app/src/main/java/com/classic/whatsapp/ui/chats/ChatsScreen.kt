package com.classic.whatsapp.ui.chats

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material3.*
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Person
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.classic.whatsapp.ClassicApp
import com.classic.whatsapp.data.ChatEntity
import com.classic.whatsapp.data.MessageEntity
import com.classic.whatsapp.ui.Avatar
import com.classic.whatsapp.ui.formatTime
import kotlinx.coroutines.launch

@Composable
fun ChatsScreen(
    onOpen: (String) -> Unit,
    onStatus: (String) -> Unit,
    onContacts: () -> Unit = {},
    onSettings: () -> Unit = {},
    onOpenInfo: (String) -> Unit = {},
    onOpenGroup: (String) -> Unit = {},
    /** Shows the chats the user hid instead of the normal list (opened from Settings). */
    hiddenOnly: Boolean = false,
    onBack: () -> Unit = {},
) {
    val app = LocalContext.current.applicationContext as ClassicApp
    val chats by app.repo.chats.collectAsState(initial = null)
    val status by app.status.collectAsState()
    val statuses by app.repo.statuses().collectAsState(initial = emptyList())
    val scope = rememberCoroutineScope()
    var query by remember { mutableStateOf("") }
    val hiddenChats by app.repo.hiddenChats.collectAsState(initial = emptyList())
    var actionsFor by remember { mutableStateOf<ChatEntity?>(null) }

    Column(Modifier.fillMaxSize().statusBarsPadding()) {
        Row(
            Modifier.fillMaxWidth().padding(start = 16.dp, end = 8.dp, top = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            if (hiddenOnly) IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back") }
            Column(Modifier.weight(1f)) {
                Text(if (hiddenOnly) "Hidden chats" else "Chats", style = MaterialTheme.typography.titleLarge)
                if (!hiddenOnly) Text(status, style = MaterialTheme.typography.bodySmall)
            }
            if (!hiddenOnly) {
                IconButton(onClick = onContacts) { Icon(Icons.Default.Person, contentDescription = "Contacts") }
                IconButton(onClick = onSettings) { Icon(Icons.Default.Settings, contentDescription = "Settings") }
            }
        }
        if (statuses.isNotEmpty() && !hiddenOnly) StatusStrip(statuses, onStatus)
        OutlinedTextField(
            value = query,
            onValueChange = { query = it },
            placeholder = { Text("Search") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
        )

        val list = if (hiddenOnly) hiddenChats else chats
        when {
            list == null -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                CircularProgressIndicator()
            }
            list.isEmpty() -> EmptyState(
                if (hiddenOnly) "No hidden chats." else "No conversations yet.\nIncoming messages appear here, or open Contacts to start one.",
            )
            else -> {
                val filtered = if (query.isBlank()) list else list.filter {
                    it.displayTitle.contains(query, ignoreCase = true) || it.lastText.contains(query, ignoreCase = true)
                }
                if (filtered.isEmpty()) EmptyState("No matches.")
                else LazyColumn(Modifier.fillMaxSize()) {
                    items(filtered, key = { it.chatId }) { c ->
                        ChatRow(
                            c,
                            onClick = { onOpen(c.chatId) },
                            onLongClick = { actionsFor = c },
                            onAvatar = {
                                when {
                                    c.chatId.endsWith("@newsletter") -> onOpen(c.chatId)
                                    c.isGroup -> onOpenGroup(c.chatId)
                                    else -> onOpenInfo(c.chatId)
                                }
                            },
                        )
                    }
                }
            }
        }
    }

    actionsFor?.let { ChatActionsDialog(it, onDismiss = { actionsFor = null }) }

}

/** Horizontal strip of contacts with a status in the last 24 hours; unseen ones first, then newest. */
@Composable
private fun StatusStrip(statuses: List<MessageEntity>, onOpen: (String) -> Unit) {
    val primary = MaterialTheme.colorScheme.primary
    val groups = statuses.groupBy { it.senderId }.entries
        .sortedWith(
            compareByDescending<Map.Entry<String, List<MessageEntity>>> { e -> e.value.any { !it.fromMe && !it.incomingRead } }
                .thenByDescending { e -> e.value.maxOf { it.timestamp } },
        )
    LazyRow(
        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        items(groups, key = { it.key }) { e ->
            val unseen = e.value.any { !it.fromMe && !it.incomingRead }
            val newest = e.value.last()
            val name = if (newest.fromMe) "You" else newest.senderName.ifBlank { e.key.substringBefore('@') }
            Column(
                Modifier.width(64.dp).clickable { onOpen(e.key) },
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                Box(
                    Modifier.size(52.dp)
                        .border(if (unseen) 3.dp else 1.dp, if (unseen) primary else MaterialTheme.colorScheme.outlineVariant, CircleShape)
                        .padding(5.dp),
                ) {
                    Avatar(e.key, name, Modifier.fillMaxSize())
                }
                Text(
                    name,
                    style = MaterialTheme.typography.labelSmall,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.padding(top = 4.dp),
                )
            }
        }
    }
}

@Composable
private fun EmptyState(text: String) {
    Box(Modifier.fillMaxSize().padding(32.dp), contentAlignment = Alignment.Center) {
        Text(text, style = MaterialTheme.typography.bodyMedium)
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun ChatRow(c: ChatEntity, onClick: () -> Unit, onLongClick: () -> Unit, onAvatar: () -> Unit) {
    val unread = c.unread > 0
    Row(
        Modifier.fillMaxWidth().combinedClickable(onClick = onClick, onLongClick = onLongClick).padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Avatar(
            c.chatId,
            c.displayTitle,
            Modifier.padding(end = 12.dp).size(48.dp).combinedClickable(onClick = onAvatar, onLongClick = onLongClick),
        )
        Column(Modifier.weight(1f)) {
            Text(
                c.displayTitle,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = if (unread) FontWeight.Bold else null,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
            Text(
                c.lastText,
                style = MaterialTheme.typography.bodyMedium,
                color = if (unread) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.onSurfaceVariant,
                fontWeight = if (unread) FontWeight.Medium else null,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
        }
        Column(horizontalAlignment = Alignment.End, modifier = Modifier.padding(start = 12.dp)) {
            Text(
                formatTime(c.lastTimestamp),
                style = MaterialTheme.typography.labelSmall,
                color = if (unread) UnreadGreen else MaterialTheme.colorScheme.onSurfaceVariant,
            )
            if (unread) {
                Box(
                    Modifier.padding(top = 4.dp).defaultMinSize(minWidth = 20.dp, minHeight = 20.dp)
                        .background(UnreadGreen, CircleShape).padding(horizontal = 6.dp),
                    contentAlignment = Alignment.Center,
                ) {
                    Text(
                        if (c.unread > 99) "99+" else c.unread.toString(),
                        style = MaterialTheme.typography.labelSmall,
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                    )
                }
            }
        }
    }
}

private val UnreadGreen = Color(0xFF25D366)
