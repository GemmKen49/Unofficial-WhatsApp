package com.classic.whatsapp.ui.conversation

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.classic.whatsapp.data.Reactions

/** Small round-cornered pill with the (up to three) most used reactions and their total, like WhatsApp's. */
@Composable
internal fun ReactionPill(reactions: String, modifier: Modifier = Modifier) {
    val summary = Reactions.summary(reactions)
    if (summary.isEmpty()) return
    val total = summary.sumOf { it.second }
    val emojis = summary.take(3).joinToString("") { it.first }
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(12.dp),
        color = MaterialTheme.colorScheme.surface,
        tonalElevation = 3.dp,
        shadowElevation = 2.dp,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
    ) {
        Text(
            if (total > 1) "$emojis $total" else emojis,
            style = MaterialTheme.typography.labelMedium,
            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
        )
    }
}
