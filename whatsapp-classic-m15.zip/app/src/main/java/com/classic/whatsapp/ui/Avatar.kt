package com.classic.whatsapp.ui

import android.graphics.BitmapFactory
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import com.classic.whatsapp.ClassicApp

/**
 * Round profile picture of [jid] (cached, refreshed in the background), or the initial of [name] while there is none.
 * The caller sets the size through [modifier].
 */
@Composable
fun Avatar(
    jid: String,
    name: String,
    modifier: Modifier = Modifier,
    textStyle: TextStyle = MaterialTheme.typography.titleMedium,
    full: Boolean = false,
) {
    val store = (LocalContext.current.applicationContext as ClassicApp).avatars
    val rev by store.rev.collectAsState()
    LaunchedEffect(jid) { store.request(jid) }
    val file = remember(jid, rev, full) { if (full) store.fullFile(jid) ?: store.file(jid) else store.file(jid) }
    val bitmap = remember(file?.path, file?.lastModified()) {
        file?.let { BitmapFactory.decodeFile(it.path)?.asImageBitmap() }
    }
    Box(modifier.clip(CircleShape).background(MaterialTheme.colorScheme.secondaryContainer), contentAlignment = Alignment.Center) {
        if (bitmap != null) {
            Image(bitmap, contentDescription = null, contentScale = ContentScale.Crop, modifier = Modifier.matchParentSize())
        } else {
            Text(name.trim().take(1).uppercase().ifBlank { "?" }, style = textStyle)
        }
    }
}
