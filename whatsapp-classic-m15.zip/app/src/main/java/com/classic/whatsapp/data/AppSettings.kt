package com.classic.whatsapp.data

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class AppSettings(context: Context) {
    private val prefs = context.getSharedPreferences("settings", Context.MODE_PRIVATE)
    private val _readReceipts = MutableStateFlow(prefs.getBoolean("read_receipts", true))
    val sendReadReceipts: StateFlow<Boolean> = _readReceipts.asStateFlow()

    private val _autoImages = MutableStateFlow(prefs.getBoolean("auto_images", true))
    val autoDownloadImages: StateFlow<Boolean> = _autoImages.asStateFlow()

    /** Last display name / About text set from this app (the current server values are not read back). */
    private val _profileName = MutableStateFlow(prefs.getString("profile_name", "") ?: "")
    val profileName: StateFlow<String> = _profileName.asStateFlow()
    private val _profileAbout = MutableStateFlow(prefs.getString("profile_about", "") ?: "")
    val profileAbout: StateFlow<String> = _profileAbout.asStateFlow()

    fun setProfileName(v: String) {
        prefs.edit().putString("profile_name", v).apply()
        _profileName.value = v
    }

    fun setProfileAbout(v: String) {
        prefs.edit().putString("profile_about", v).apply()
        _profileAbout.value = v
    }

    fun clearProfile() {
        prefs.edit().remove("profile_name").remove("profile_about").apply()
        _profileName.value = ""
        _profileAbout.value = ""
    }

    fun setAutoDownloadImages(value: Boolean) {
        prefs.edit().putBoolean("auto_images", value).apply()
        _autoImages.value = value
    }

    fun setSendReadReceipts(value: Boolean) {
        prefs.edit().putBoolean("read_receipts", value).apply()
        _readReceipts.value = value
    }
}
