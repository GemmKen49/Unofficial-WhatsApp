package com.classic.whatsapp.data

import android.media.MediaPlayer
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

data class PlayerState(
    val messageId: String? = null,
    val positionMs: Int = 0,
    val durationMs: Int = 0,
    val playing: Boolean = false,
)

/** One message plays at a time. Call from the main thread. */
class AudioPlayer(private val scope: CoroutineScope) {
    private var player: MediaPlayer? = null
    private var ticker: Job? = null
    private val _state = MutableStateFlow(PlayerState())
    val state: StateFlow<PlayerState> = _state.asStateFlow()

    fun toggle(messageId: String, path: String) {
        val cur = _state.value
        if (cur.messageId == messageId && player != null) {
            if (cur.playing) pause() else resume()
            return
        }
        stop()
        val p = MediaPlayer()
        try {
            p.setDataSource(path)
            p.setOnCompletionListener { stop() }
            p.prepare()
            p.start()
        } catch (e: Exception) {
            runCatching { p.release() }
            return
        }
        player = p
        _state.value = PlayerState(messageId, 0, p.duration, true)
        startTicker()
    }

    private fun pause() {
        player?.pause()
        ticker?.cancel()
        _state.value = _state.value.copy(playing = false)
    }

    private fun resume() {
        player?.start()
        _state.value = _state.value.copy(playing = true)
        startTicker()
    }

    fun stop() {
        ticker?.cancel()
        runCatching { player?.release() }
        player = null
        _state.value = PlayerState()
    }

    private fun startTicker() {
        ticker?.cancel()
        ticker = scope.launch {
            while (isActive) {
                player?.let { _state.value = _state.value.copy(positionMs = it.currentPosition, playing = it.isPlaying) }
                delay(200)
            }
        }
    }
}
