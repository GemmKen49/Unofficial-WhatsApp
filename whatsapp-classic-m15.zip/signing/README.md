# Signing key

`classic.p12` is the fixed signing key (password `classicpass`, alias `classic`) used for every build,
so new APKs install over old ones. Keep your GitHub repo **private**. Anyone with this file can sign
APKs that update this app.
