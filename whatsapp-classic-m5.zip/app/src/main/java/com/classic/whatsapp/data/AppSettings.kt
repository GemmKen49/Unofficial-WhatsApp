package com.classic.whatsapp.data

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class AppSettings(context: Context) {
    private val prefs = context.getSharedPreferences("settings", Context.MODE_PRIVATE)
    private val _readReceipts = MutableStateFlow(prefs.getBoolean("read_receipts", true))
    val sendReadReceipts: StateFlow<Boolean> = _readReceipts.asStateFlow()

    private val _autoImages = MutableStateFlow(prefs.getBoolean("auto_images", true))
    val autoDownloadImages: StateFlow<Boolean> = _autoImages.asStateFlow()

    fun setAutoDownloadImages(value: Boolean) {
        prefs.edit().putBoolean("auto_images", value).apply()
        _autoImages.value = value
    }

    fun setSendReadReceipts(value: Boolean) {
        prefs.edit().putBoolean("read_receipts", value).apply()
        _readReceipts.value = value
    }
}
