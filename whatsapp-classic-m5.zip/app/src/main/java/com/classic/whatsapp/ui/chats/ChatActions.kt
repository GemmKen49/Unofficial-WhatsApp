package com.classic.whatsapp.ui.chats

import androidx.compose.foundation.layout.Column
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.platform.LocalContext
import com.classic.whatsapp.ClassicApp
import com.classic.whatsapp.data.ChatEntity
import kotlinx.coroutines.launch

/** Local-only contact editing: rename, hide, delete. [onGone] runs after hide/delete. */
@Composable
fun ChatActionsDialog(chat: ChatEntity, onDismiss: () -> Unit, onGone: () -> Unit = {}) {
    val app = LocalContext.current.applicationContext as ClassicApp
    val scope = rememberCoroutineScope()
    var mode by remember { mutableStateOf("menu") }
    var name by remember { mutableStateOf(chat.customName.ifBlank { chat.title }) }

    when (mode) {
        "rename" -> AlertDialog(
            onDismissRequest = onDismiss,
            title = { Text("Rename") },
            text = {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    singleLine = true,
                    label = { Text("Name (empty = original)") },
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    scope.launch { app.repo.rename(chat.chatId, name) }
                    onDismiss()
                }) { Text("Save") }
            },
            dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
        )
        "delete" -> AlertDialog(
            onDismissRequest = onDismiss,
            title = { Text("Delete chat?") },
            text = { Text("Deletes the messages and downloaded media on this device only.") },
            confirmButton = {
                TextButton(onClick = {
                    scope.launch { app.repo.delete(chat.chatId) }
                    onDismiss()
                    onGone()
                }) { Text("Delete") }
            },
            dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
        )
        else -> AlertDialog(
            onDismissRequest = onDismiss,
            title = { Text(chat.displayTitle) },
            text = {
                Column {
                    TextButton(onClick = { mode = "rename" }) { Text("Rename") }
                    TextButton(onClick = {
                        scope.launch { app.repo.hide(chat.chatId) }
                        onDismiss()
                        onGone()
                    }) { Text("Hide chat (returns on a new message)") }
                    TextButton(onClick = { mode = "delete" }) { Text("Delete chat") }
                }
            },
            confirmButton = {},
            dismissButton = { TextButton(onClick = onDismiss) { Text("Close") } },
        )
    }
}
