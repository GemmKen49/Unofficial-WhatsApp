package com.classic.whatsapp.messaging

import kotlinx.coroutines.flow.SharedFlow

class PairingException(message: String) : Exception(message)

/** App-level messaging surface. Media/groups are added in later milestones. */
interface MessagingClient {
    val events: SharedFlow<MessagingEvent>
    val isRunning: Boolean

    /** Resume an existing linked-device session. */
    fun start()
    fun stop()

    /** Starts a fresh pairing attempt; returns when the code arrives. */
    suspend fun requestPairingCode(phoneNumber: String): MessagingEvent.PairingCode

    /** Sends a text message; returns the server-side message id. */
    suspend fun sendText(
        chatId: String,
        text: String,
        replyToId: String = "",
        replyToSender: String = "",
        replyToText: String = "",
        replyToChat: String = "",
    ): String

    /** Deletes one of our own messages for everyone. */
    suspend fun revokeMessage(chatId: String, messageId: String)

    /** Current name of a group chat. */
    suspend fun groupSubject(chatId: String): String

    /** Uploads a local file and sends it (kind: image | video | document); returns the message id. */
    suspend fun sendMedia(
        chatId: String,
        kind: String,
        path: String,
        mimeType: String,
        fileName: String,
        caption: String,
        thumbnail: ByteArray,
        durationSecs: Int,
        voice: Boolean = false,
    ): String

    /** Downloads and decrypts an attachment to [destPath]. */
    suspend fun downloadMedia(media: MediaDescriptor, destPath: String)

    /** Sends a read receipt. [senderId] is the author for groups, empty for 1:1 chats. */
    suspend fun markRead(chatId: String, senderId: String, messageIds: List<String>)

    /** Stops the engine and deletes the local session database. */
    suspend fun clearSession()
}
