package com.classic.whatsapp.ui.status

import android.widget.Toast
import android.widget.VideoView
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import com.classic.whatsapp.ClassicApp
import com.classic.whatsapp.STATUS_CHAT
import com.classic.whatsapp.data.MessageEntity
import com.classic.whatsapp.ui.conversation.rememberBitmap
import com.classic.whatsapp.ui.formatTime
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/** Status updates from the last 24 hours, grouped by who posted them. */
@Composable
fun StatusListScreen(onOpen: (String) -> Unit, onBack: () -> Unit) {
    val app = LocalContext.current.applicationContext as ClassicApp
    val list by app.repo.statuses().collectAsState(initial = emptyList())
    val groups = list.groupBy { it.senderId }.entries.sortedByDescending { it.value.last().timestamp }

    Column(Modifier.fillMaxSize().statusBarsPadding()) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back") }
            Text("Status updates", style = MaterialTheme.typography.titleMedium)
        }
        HorizontalDivider()
        if (groups.isEmpty()) {
            Box(Modifier.fillMaxSize().padding(32.dp), contentAlignment = Alignment.Center) {
                Text("No status updates in the last 24 hours.")
            }
        } else {
            LazyColumn(Modifier.fillMaxSize()) {
                items(groups, key = { it.key }) { e ->
                    val newest = e.value.last()
                    Column(Modifier.fillMaxWidth().clickable { onOpen(e.key) }.padding(16.dp)) {
                        Text(newest.senderName.ifBlank { e.key.substringBefore('@') }, style = MaterialTheme.typography.titleMedium)
                        Text(
                            "${e.value.size} update(s) · ${formatTime(newest.timestamp)}",
                            style = MaterialTheme.typography.bodySmall,
                        )
                    }
                }
            }
        }
    }
}

/** Full-screen viewer: tap right = next, tap left = previous, auto-advances; reply sends a quoted message. */
@Composable
fun StatusViewerScreen(senderId: String, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val app = ctx.applicationContext as ClassicApp
    val repo = app.repo
    val scope = rememberCoroutineScope()
    val all by repo.statuses().collectAsState(initial = null as List<MessageEntity>?)
    var index by remember { mutableIntStateOf(0) }
    var reply by remember { mutableStateOf("") }

    val list = all
    if (list == null) {
        Box(Modifier.fillMaxSize().background(Color.Black))
        return
    }
    val items = list.filter { it.senderId == senderId }
    if (items.isEmpty()) {
        LaunchedEffect(Unit) { onBack() }
        return
    }
    val i = index.coerceIn(0, items.lastIndex)
    val m = items[i]
    fun next() { if (i < items.lastIndex) index = i + 1 else onBack() }
    fun prev() { if (i > 0) index = i - 1 }

    // Fetch the media and tell the poster we viewed it (if read receipts are on).
    LaunchedEffect(m.messageId) {
        if ((m.kind == "image" || m.kind == "video") && m.mediaPath.isBlank()) repo.downloadMedia(STATUS_CHAT, m.messageId)
        repo.markStatusViewed(m)
    }
    val ready = m.kind == "text" || m.kind == "viewonce" || m.mediaPath.isNotBlank()
    if (m.kind != "video") {
        LaunchedEffect(m.messageId, ready, reply.isBlank()) {
            if (ready && reply.isBlank()) {
                delay(5000)
                next()
            }
        }
    }

    Box(Modifier.fillMaxSize().background(Color.Black).statusBarsPadding().imePadding()) {
        Box(
            Modifier.fillMaxSize().pointerInput(m.messageId) {
                detectTapGestures { offset -> if (offset.x < size.width / 3f) prev() else next() }
            },
            contentAlignment = Alignment.Center,
        ) {
            when (m.kind) {
                "image" -> {
                    val bmp = rememberBitmap(if (m.mediaPath.isNotBlank()) m.mediaPath else m.thumbPath, 1600)
                    if (bmp != null) Image(bmp, contentDescription = null, contentScale = ContentScale.Fit, modifier = Modifier.fillMaxSize())
                    if (m.mediaPath.isBlank()) CircularProgressIndicator()
                }
                "video" -> if (m.mediaPath.isNotBlank()) {
                    VideoStatus(m.mediaPath, onDone = { next() })
                } else {
                    val bmp = rememberBitmap(m.thumbPath, 800)
                    if (bmp != null) Image(bmp, contentDescription = null, contentScale = ContentScale.Fit, modifier = Modifier.fillMaxSize())
                    CircularProgressIndicator()
                }
                "viewonce" -> Text("View-once status. Open it on your phone.", color = Color.White, modifier = Modifier.padding(24.dp))
                else -> Text(
                    m.text,
                    color = Color.White,
                    style = MaterialTheme.typography.headlineSmall,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.padding(24.dp),
                )
            }
        }

        Column(Modifier.align(Alignment.TopCenter).fillMaxWidth().padding(8.dp)) {
            Row(Modifier.fillMaxWidth()) {
                items.indices.forEach { n ->
                    Box(
                        Modifier.weight(1f).padding(horizontal = 2.dp).height(3.dp)
                            .background(if (n <= i) Color.White else Color.White.copy(alpha = 0.3f)),
                    )
                }
            }
            Text(
                (if (m.fromMe) "You" else m.senderName.ifBlank { senderId.substringBefore('@') }) + " · " + formatTime(m.timestamp),
                color = Color.White,
                style = MaterialTheme.typography.labelLarge,
                modifier = Modifier.padding(top = 6.dp),
            )
        }

        Column(Modifier.align(Alignment.BottomCenter).fillMaxWidth().background(Color.Black.copy(alpha = 0.55f)).padding(8.dp)) {
            if (m.kind != "text" && m.text.isNotBlank()) {
                Text(m.text, color = Color.White, modifier = Modifier.padding(bottom = 6.dp))
            }
            if (!m.fromMe) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    OutlinedTextField(
                        value = reply,
                        onValueChange = { reply = it },
                        placeholder = { Text("Reply…") },
                        maxLines = 3,
                        modifier = Modifier.weight(1f),
                    )
                    IconButton(
                        enabled = reply.isNotBlank(),
                        onClick = {
                            val text = reply.trim()
                            reply = ""
                            scope.launch {
                                repo.sendText(m.senderId, text, replyTo = m, quotedChat = STATUS_CHAT)
                                Toast.makeText(ctx, "Reply sent", Toast.LENGTH_SHORT).show()
                            }
                        },
                    ) { Icon(Icons.AutoMirrored.Filled.Send, contentDescription = "Send reply", tint = Color.White) }
                }
            }
        }
    }
}

@Composable
private fun VideoStatus(path: String, onDone: () -> Unit) {
    val done by rememberUpdatedState(onDone)
    AndroidView(
        factory = { c ->
            VideoView(c).apply {
                setVideoPath(path)
                setOnPreparedListener { it.isLooping = false; start() }
                setOnCompletionListener { done() }
            }
        },
        modifier = Modifier.fillMaxSize(),
    )
}
