package com.classic.whatsapp.ui.profile

import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.classic.whatsapp.ClassicApp
import com.classic.whatsapp.data.MediaFiles
import com.classic.whatsapp.ui.Avatar
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private const val NAME_MAX = 25
private const val ABOUT_MAX = 139

private enum class Field { Name, About }

/**
 * The own profile, WhatsApp style: photo with an edit badge, then Name, About and Phone rows. Each field is saved on
 * its own. The photo, About and phone number are read from the account; the display name cannot be read back from
 * the server, so it shows what was last set in this app.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProfileScreen(onBack: () -> Unit) {
    val ctx = LocalContext.current
    val app = ctx.applicationContext as ClassicApp
    val repo = app.repo
    val avatars = app.avatars
    val scope = rememberCoroutineScope()
    val savedName by app.settings.profileName.collectAsState()
    val savedAbout by app.settings.profileAbout.collectAsState()
    var ownJid by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }
    var editing by remember { mutableStateOf<Field?>(null) }
    var photoSheet by remember { mutableStateOf(false) }
    val hasPhoto = ownJid?.let { avatars.file(it) != null || avatars.fullFile(it) != null } == true
    val rev by avatars.rev.collectAsState()

    LaunchedEffect(Unit) {
        val j = avatars.ownJid() ?: return@LaunchedEffect
        ownJid = j
        launch { avatars.loadFull(j) }
        launch { avatars.loadAbout(j)?.let { if (it != savedAbout) app.settings.setProfileAbout(it) } }
    }

    fun toast(text: String) = Toast.makeText(ctx, text, Toast.LENGTH_SHORT).show()

    /** Runs a profile change; shows the result and keeps the screen locked while it runs. */
    fun run(done: String, block: suspend () -> Unit) {
        if (busy) return
        busy = true
        scope.launch {
            try {
                block()
                toast(done)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                toast(e.message ?: "Could not update the profile")
            } finally {
                busy = false
            }
        }
    }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) run("Profile picture updated") {
            val jpeg = withContext(Dispatchers.IO) { MediaFiles.profileJpeg(ctx, uri) } ?: throw IllegalStateException("Could not read that image")
            repo.setProfilePicture(jpeg)
            ownJid?.let { avatars.storeOwn(it, jpeg) }
        }
    }

    Column(Modifier.fillMaxSize().statusBarsPadding().verticalScroll(rememberScrollState())) {
        Row(Modifier.fillMaxWidth().padding(end = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back") }
            Text("Profile", style = MaterialTheme.typography.titleLarge)
        }
        Box(Modifier.fillMaxWidth().padding(vertical = 16.dp), contentAlignment = Alignment.Center) {
            Box(Modifier.size(160.dp).clickable(enabled = !busy) { photoSheet = true }) {
                key(rev) {
                    val j = ownJid
                    if (j != null) {
                        Avatar(j, savedName, Modifier.fillMaxSize(), MaterialTheme.typography.displayLarge, full = true)
                    } else {
                        Box(
                            Modifier.fillMaxSize().clip(CircleShape).background(MaterialTheme.colorScheme.secondaryContainer),
                            contentAlignment = Alignment.Center,
                        ) { Text(savedName.take(1).uppercase().ifBlank { "?" }, style = MaterialTheme.typography.displayLarge) }
                    }
                }
                Box(
                    Modifier.align(Alignment.BottomEnd).size(44.dp).background(MaterialTheme.colorScheme.primary, CircleShape),
                    contentAlignment = Alignment.Center,
                ) { Icon(Icons.Default.Edit, contentDescription = "Change photo", tint = MaterialTheme.colorScheme.onPrimary) }
            }
        }
        ProfileRow(
            icon = { Icon(Icons.Default.Person, contentDescription = null) },
            label = "Name",
            value = savedName.ifBlank { "Not set here" },
            note = "This is not your username or PIN. This name will be visible to your WhatsApp contacts.",
            onEdit = { editing = Field.Name },
        )
        ProfileRow(
            icon = { Icon(Icons.Default.Info, contentDescription = null) },
            label = "About",
            value = savedAbout.ifBlank { "Not set" },
            onEdit = { editing = Field.About },
        )
        ProfileRow(
            icon = { Icon(Icons.Default.Phone, contentDescription = null) },
            label = "Phone",
            value = ownJid?.substringBefore('@')?.let { "+$it" } ?: "…",
            onEdit = null,
        )
        Text(
            "Changes need a connection and apply to your whole WhatsApp account.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 16.dp),
        )
    }

    if (photoSheet) {
        ModalBottomSheet(onDismissRequest = { photoSheet = false }, sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)) {
            Column(Modifier.fillMaxWidth().navigationBarsPadding().padding(bottom = 16.dp)) {
                Text("Profile photo", style = MaterialTheme.typography.titleMedium, modifier = Modifier.padding(horizontal = 24.dp, vertical = 8.dp))
                SheetAction("Choose from gallery") { photoSheet = false; picker.launch("image/*") }
                if (hasPhoto) SheetAction("Remove photo") {
                    photoSheet = false
                    run("Profile picture removed") {
                        repo.removeProfilePicture()
                        ownJid?.let { avatars.storeOwn(it, null) }
                    }
                }
            }
        }
    }

    editing?.let { field ->
        val isName = field == Field.Name
        EditSheet(
            title = if (isName) "Your name" else "About",
            initial = if (isName) savedName else savedAbout,
            max = if (isName) NAME_MAX else ABOUT_MAX,
            singleLine = isName,
            allowBlank = !isName,
            onDismiss = { editing = null },
            onSave = { value ->
                editing = null
                if (isName) run("Name saved") { repo.setDisplayName(value) } else run("About saved") { repo.setAbout(value) }
            },
        )
    }
}

@Composable
private fun ProfileRow(icon: @Composable () -> Unit, label: String, value: String, note: String? = null, onEdit: (() -> Unit)?) {
    Row(
        Modifier.fillMaxWidth().clickable(enabled = onEdit != null) { onEdit?.invoke() }.padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.Top,
    ) {
        Box(Modifier.width(40.dp).padding(top = 2.dp)) { icon() }
        Column(Modifier.weight(1f)) {
            Text(label, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text(value, style = MaterialTheme.typography.bodyLarge)
            if (note != null) Text(note, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(top = 4.dp))
        }
        if (onEdit != null) Icon(Icons.Default.Edit, contentDescription = "Edit $label", tint = MaterialTheme.colorScheme.primary, modifier = Modifier.padding(start = 8.dp, top = 2.dp))
    }
}

@Composable
private fun SheetAction(text: String, onClick: () -> Unit) {
    Text(text, style = MaterialTheme.typography.bodyLarge, modifier = Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 24.dp, vertical = 14.dp))
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun EditSheet(
    title: String,
    initial: String,
    max: Int,
    singleLine: Boolean,
    allowBlank: Boolean,
    onDismiss: () -> Unit,
    onSave: (String) -> Unit,
) {
    var text by remember { mutableStateOf(initial) }
    val focus = remember { FocusRequester() }
    ModalBottomSheet(onDismissRequest = onDismiss, sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)) {
        Column(Modifier.fillMaxWidth().navigationBarsPadding().imePadding().padding(horizontal = 24.dp).padding(bottom = 16.dp)) {
            Text(title, style = MaterialTheme.typography.titleMedium)
            OutlinedTextField(
                value = text,
                onValueChange = { text = it.take(max) },
                singleLine = singleLine,
                supportingText = { Text("${text.length}/$max") },
                modifier = Modifier.fillMaxWidth().padding(top = 12.dp).focusRequester(focus),
            )
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                TextButton(onClick = onDismiss) { Text("Cancel") }
                TextButton(
                    enabled = (allowBlank || text.isNotBlank()) && text.trim() != initial.trim(),
                    onClick = { onSave(text.trim()) },
                ) { Text("Save") }
            }
        }
    }
    LaunchedEffect(Unit) { focus.requestFocus() }
}
