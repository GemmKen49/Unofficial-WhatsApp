package com.classic.whatsapp.ui.chats

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.classic.whatsapp.ClassicApp
import com.classic.whatsapp.data.ChatEntity
import com.classic.whatsapp.ui.formatTime
import kotlinx.coroutines.launch

@Composable
fun ChatsScreen(onOpen: (String) -> Unit) {
    val app = LocalContext.current.applicationContext as ClassicApp
    val chats by app.repo.chats.collectAsState(initial = null)
    val status by app.status.collectAsState()
    val scope = rememberCoroutineScope()
    var query by remember { mutableStateOf("") }
    var showNew by remember { mutableStateOf(false) }
    var actionsFor by remember { mutableStateOf<ChatEntity?>(null) }

    Column(Modifier.fillMaxSize().statusBarsPadding()) {
        Row(
            Modifier.fillMaxWidth().padding(start = 16.dp, end = 8.dp, top = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Column(Modifier.weight(1f)) {
                Text("Chats", style = MaterialTheme.typography.titleLarge)
                Text(status, style = MaterialTheme.typography.bodySmall)
            }
            IconButton(onClick = { showNew = true }) { Icon(Icons.Default.Add, contentDescription = "New chat") }
        }
        OutlinedTextField(
            value = query,
            onValueChange = { query = it },
            placeholder = { Text("Search") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
        )

        val list = chats
        when {
            list == null -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                CircularProgressIndicator()
            }
            list.isEmpty() -> EmptyState(
                "No conversations yet.\nIncoming messages appear here, or tap + to start one.",
            )
            else -> {
                val filtered = if (query.isBlank()) list else list.filter {
                    it.displayTitle.contains(query, ignoreCase = true) || it.lastText.contains(query, ignoreCase = true)
                }
                if (filtered.isEmpty()) EmptyState("No matches.")
                else LazyColumn(Modifier.fillMaxSize()) {
                    items(filtered, key = { it.chatId }) { c ->
                        ChatRow(c, onClick = { onOpen(c.chatId) }, onLongClick = { actionsFor = c })
                    }
                }
            }
        }
    }

    actionsFor?.let { ChatActionsDialog(it, onDismiss = { actionsFor = null }) }

    if (showNew) {
        var digits by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { showNew = false },
            title = { Text("New chat") },
            text = {
                OutlinedTextField(
                    value = digits,
                    onValueChange = { digits = it.filter(Char::isDigit) },
                    label = { Text("Number with country code") },
                    prefix = { Text("+") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                )
            },
            confirmButton = {
                TextButton(
                    enabled = digits.length in 8..15,
                    onClick = {
                        showNew = false
                        scope.launch { onOpen(app.repo.createChat(digits)) }
                    },
                ) { Text("Open") }
            },
            dismissButton = { TextButton(onClick = { showNew = false }) { Text("Cancel") } },
        )
    }
}

@Composable
private fun EmptyState(text: String) {
    Box(Modifier.fillMaxSize().padding(32.dp), contentAlignment = Alignment.Center) {
        Text(text, style = MaterialTheme.typography.bodyMedium)
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun ChatRow(c: ChatEntity, onClick: () -> Unit, onLongClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().combinedClickable(onClick = onClick, onLongClick = onLongClick).padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.weight(1f)) {
            Text(c.displayTitle, style = MaterialTheme.typography.titleMedium, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(
                c.lastText,
                style = MaterialTheme.typography.bodyMedium,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
        }
        Column(horizontalAlignment = Alignment.End, modifier = Modifier.padding(start = 12.dp)) {
            Text(formatTime(c.lastTimestamp), style = MaterialTheme.typography.labelSmall)
            if (c.unread > 0) {
                Badge(Modifier.padding(top = 4.dp)) { Text(c.unread.toString()) }
            }
        }
    }
}
