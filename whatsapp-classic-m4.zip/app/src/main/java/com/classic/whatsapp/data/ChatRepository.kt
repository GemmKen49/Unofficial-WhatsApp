package com.classic.whatsapp.data

import android.content.Context
import android.database.sqlite.SQLiteConstraintException
import androidx.room.withTransaction
import com.classic.whatsapp.messaging.MediaDescriptor
import com.classic.whatsapp.messaging.MessagingClient
import com.classic.whatsapp.messaging.MessagingEvent
import java.io.File
import java.util.UUID
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow

class ChatRepository(
    private val ctx: Context,
    private val db: AppDatabase,
    private val client: MessagingClient,
    private val settings: AppSettings,
) {
    private val dao = db.dao()

    val chats: Flow<List<ChatEntity>> = dao.observeChats()
    fun chat(chatId: String): Flow<ChatEntity?> = dao.observeChat(chatId)
    fun messages(chatId: String): Flow<List<MessageEntity>> = dao.observeMessages(chatId)

    /** Chat whose screen is currently composed. */
    val openChatId = MutableStateFlow<String?>(null)

    /** True while the activity is visible (read receipts/notifications depend on it). */
    val foreground = MutableStateFlow(false)

    /** Message ids being downloaded right now. */
    val downloading = MutableStateFlow<Set<String>>(emptySet())
    val lastError = MutableStateFlow<String?>(null)

    fun viewing(chatId: String) = foreground.value && openChatId.value == chatId

    suspend fun openChat(chatId: String) {
        openChatId.value = chatId
    }

    fun closeChat() {
        openChatId.value = null
    }

    suspend fun title(chatId: String): String = dao.getChat(chatId)?.displayTitle ?: chatId.substringBefore('@')

    /** Creates (or un-hides) a 1:1 chat for a phone number given as digits with country code. */
    suspend fun createChat(digits: String): String {
        val chatId = "$digits@s.whatsapp.net"
        val existing = dao.getChat(chatId)
        if (existing == null) {
            dao.upsertChat(ChatEntity(chatId, digits, false, "", System.currentTimeMillis(), 0))
        } else if (existing.hidden) {
            dao.setHidden(chatId, false)
        }
        return chatId
    }

    // ---- local contact editing ----

    suspend fun rename(chatId: String, name: String) = dao.setCustomName(chatId, name.trim())

    suspend fun hide(chatId: String) = dao.setHidden(chatId, true)

    suspend fun delete(chatId: String) {
        for (m in dao.getMessages(chatId)) {
            if (m.mediaPath.isNotBlank()) File(m.mediaPath).delete()
            if (m.thumbPath.isNotBlank()) File(m.thumbPath).delete()
        }
        db.withTransaction {
            dao.deleteMessagesOf(chatId)
            dao.deleteChat(chatId)
        }
    }

    // ---- incoming ----

    /** Returns true if the message was new. */
    suspend fun onIncoming(m: MessagingEvent.MessageReceived): Boolean {
        val media = m.media
        val thumbPath = if (media != null && media.thumbnail.isNotEmpty()) {
            MediaFiles.saveThumb(ctx, m.messageId, media.thumbnail)
        } else ""
        return db.withTransaction {
            val msg = MessageEntity(
                chatId = m.chatId,
                messageId = m.messageId,
                senderId = m.senderId,
                senderName = if (m.fromMe) "" else m.pushName.ifBlank { m.senderId.substringBefore('@') },
                text = m.text.ifBlank { media?.caption.orEmpty() },
                timestamp = m.timestampMs,
                fromMe = m.fromMe,
                status = STATUS_SENT,
                kind = media?.kind ?: "text",
                thumbPath = thumbPath,
                mimeType = media?.mimeType.orEmpty(),
                fileName = media?.fileName.orEmpty(),
                fileLength = media?.fileLength ?: 0,
                mediaRef = if (media != null && media.kind != "viewonce") media.toJson() else "",
                incomingRead = m.fromMe, // sent from our other devices => already read
                replyToId = m.replyToId,
                replyToSender = m.replyToSender,
                replyToText = m.replyToText,
            )
            if (dao.insertMessage(msg) == -1L) {
                if (thumbPath.isNotEmpty()) File(thumbPath).delete()
                return@withTransaction false
            }
            val base = dao.getChat(m.chatId) ?: ChatEntity(
                chatId = m.chatId,
                title = if (m.isGroup) "Group" else m.chatId.substringBefore('@'),
                isGroup = m.isGroup,
                lastText = "",
                lastTimestamp = 0,
                unread = 0,
            )
            val title = if (!m.isGroup && !m.fromMe && m.pushName.isNotBlank()) m.pushName else base.title
            val unread = base.unread + if (!m.fromMe && !viewing(m.chatId)) 1 else 0
            val isNewest = m.timestampMs >= base.lastTimestamp
            dao.upsertChat(
                base.copy(
                    title = title,
                    isGroup = m.isGroup,
                    lastText = if (isNewest) preview(msg) else base.lastText,
                    lastTimestamp = if (isNewest) m.timestampMs else base.lastTimestamp,
                    unread = unread,
                    hidden = false, // a new message brings a hidden chat back
                ),
            )
            true
        }
    }

    suspend fun onReceipt(e: MessagingEvent.ReceiptReceived) {
        if (e.messageIds.isEmpty()) return
        if (e.kind == "read") dao.markReadByPeer(e.messageIds) else dao.markDelivered(e.messageIds)
    }

    /**
     * Marks the chat read: sends read receipts (if enabled) for incoming messages not yet
     * acknowledged and clears the unread counter. Only call while the chat is on screen.
     */
    suspend fun markConversationRead(chatId: String) {
        val pending = dao.unreadIncoming(chatId)
        if (pending.isNotEmpty()) {
            val done = mutableListOf<String>()
            if (settings.sendReadReceipts.value) {
                pending.groupBy { it.senderId }.forEach { (sender, msgs) ->
                    val ids = msgs.map { it.messageId }
                    try {
                        client.markRead(chatId, if (chatId.endsWith("@g.us")) sender else "", ids)
                        done += ids
                    } catch (e: CancellationException) {
                        throw e
                    } catch (e: Exception) {
                        // not connected right now; retried the next time the chat is viewed
                    }
                }
            } else {
                done += pending.map { it.messageId }
            }
            if (done.isNotEmpty()) dao.markIncomingRead(chatId, done)
        }
        dao.markRead(chatId)
    }

    // ---- outgoing ----

    suspend fun sendText(chatId: String, text: String, replyTo: MessageEntity? = null) {
        val tempId = "local-" + UUID.randomUUID()
        val now = System.currentTimeMillis()
        val msg = MessageEntity(
            chatId, tempId, "", "", text, now, true, STATUS_SENDING,
            replyToId = replyTo?.messageId.orEmpty(),
            replyToSender = if (replyTo == null || replyTo.fromMe) "" else replyTo.senderId,
            replyToText = replyTo?.let { quoteText(it) }.orEmpty(),
        )
        db.withTransaction {
            dao.insertMessage(msg)
            touchChat(chatId, "You: $text", now)
        }
        deliver(msg)
    }

    suspend fun sendMedia(chatId: String, f: PendingFile, caption: String) {
        val src = File(f.path)
        val kind = MediaFiles.kindOf(f.mime)
        val tempId = "local-" + UUID.randomUUID()
        val now = System.currentTimeMillis()
        val dest = File(MediaFiles.dir(ctx, "out"), MediaFiles.safe(tempId) + "." + MediaFiles.extension(f.mime, f.name))
        val file = try {
            src.copyTo(dest, overwrite = true)
            src.delete()
            dest
        } catch (e: Exception) {
            lastError.value = "Cannot read the file"
            return
        }
        val thumb = MediaFiles.thumbnail(file, kind)
        val thumbPath = if (thumb.isNotEmpty()) MediaFiles.saveThumb(ctx, tempId, thumb) else ""
        val msg = MessageEntity(
            chatId = chatId, messageId = tempId, senderId = "", senderName = "",
            text = caption, timestamp = now, fromMe = true, status = STATUS_SENDING,
            kind = kind, mediaPath = file.path, thumbPath = thumbPath, mimeType = f.mime,
            fileName = f.name, fileLength = file.length(),
        )
        db.withTransaction {
            dao.insertMessage(msg)
            touchChat(chatId, "You: " + preview(msg), now)
        }
        deliver(msg)
    }

    /** Tap on a "failed to send" message. */
    suspend fun retry(chatId: String, messageId: String) {
        val m = dao.getMessage(chatId, messageId) ?: return
        if (m.status != STATUS_FAILED) return
        lastError.value = null
        dao.setStatus(chatId, messageId, STATUS_SENDING)
        deliver(m.copy(status = STATUS_SENDING))
    }

    private suspend fun deliver(m: MessageEntity) {
        try {
            val realId = if (m.kind == "text") {
                client.sendText(m.chatId, m.text, m.replyToId, m.replyToSender, m.replyToText)
            } else {
                val file = File(m.mediaPath)
                if (!file.exists()) throw IllegalStateException("File is gone")
                if (file.length() > MediaFiles.MAX_UPLOAD_BYTES) throw IllegalStateException("File too large (limit 64 MB)")
                val thumb = if (m.thumbPath.isNotBlank() && File(m.thumbPath).exists()) File(m.thumbPath).readBytes() else ByteArray(0)
                client.sendMedia(
                    m.chatId, m.kind, m.mediaPath, m.mimeType, m.fileName, m.text, thumb,
                    if (m.kind == "video") MediaFiles.videoDurationSecs(file) else 0,
                )
            }
            rekey(m.chatId, m.messageId, realId)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            lastError.value = e.message ?: "Sending failed"
            dao.setStatus(m.chatId, m.messageId, STATUS_FAILED)
        }
    }

    // ---- delete / group names ----

    /** Removes the message on this device only. */
    suspend fun deleteForMe(chatId: String, messageId: String) {
        dao.getMessage(chatId, messageId)?.let {
            if (it.mediaPath.isNotBlank()) File(it.mediaPath).delete()
            if (it.thumbPath.isNotBlank()) File(it.thumbPath).delete()
        }
        dao.deleteMessage(chatId, messageId)
        refreshPreview(chatId)
    }

    /** Deletes one of our own sent messages for everyone, then marks it deleted locally. */
    suspend fun deleteForEveryone(chatId: String, messageId: String) {
        try {
            client.revokeMessage(chatId, messageId)
            dao.getMessage(chatId, messageId)?.let {
                if (it.mediaPath.isNotBlank()) File(it.mediaPath).delete()
                if (it.thumbPath.isNotBlank()) File(it.thumbPath).delete()
            }
            dao.markDeleted(chatId, messageId)
            refreshPreview(chatId)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            lastError.value = "Delete failed: ${e.message ?: "unknown error"}"
        }
    }

    /** Looks up the real name of a group whose title is still the placeholder. */
    suspend fun ensureGroupTitle(chatId: String) {
        val chat = dao.getChat(chatId) ?: return
        if (!chat.isGroup || chat.title != "Group") return
        try {
            val subject = client.groupSubject(chatId)
            if (subject.isNotBlank()) dao.setTitle(chatId, subject)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            // not connected / not available; tried again on the next incoming group message
        }
    }

    private suspend fun refreshPreview(chatId: String) {
        val last = dao.lastMessage(chatId)
        if (last == null) dao.setLast(chatId, "", dao.getChat(chatId)?.lastTimestamp ?: 0)
        else dao.setLast(chatId, (if (last.fromMe) "You: " else "") + preview(last), last.timestamp)
    }

    fun quoteText(m: MessageEntity): String = when {
        m.text.isNotBlank() -> m.text
        m.kind == "image" -> "[Photo]"
        m.kind == "video" -> "[Video]"
        m.kind == "document" -> m.fileName.ifBlank { "[File]" }
        else -> ""
    }

    // ---- received media ----

    suspend fun downloadMedia(chatId: String, messageId: String) {
        if (messageId in downloading.value) return
        val m = dao.getMessage(chatId, messageId) ?: return
        val ref = MediaDescriptor.fromJson(m.mediaRef) ?: return
        val dest = File(MediaFiles.dir(ctx, "in"), MediaFiles.safe(messageId) + "." + MediaFiles.extension(m.mimeType, m.fileName))
        downloading.value = downloading.value + messageId
        lastError.value = null
        try {
            client.downloadMedia(ref, dest.path)
            dao.setMediaPath(chatId, messageId, dest.path)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            lastError.value = "Download failed: ${e.message ?: "unknown error"}"
        } finally {
            downloading.value = downloading.value - messageId
        }
    }

    // ---- helpers ----

    private suspend fun rekey(chatId: String, tempId: String, realId: String) {
        try {
            dao.rekeyMessage(chatId, tempId, realId, STATUS_SENT)
        } catch (e: SQLiteConstraintException) {
            dao.deleteMessage(chatId, tempId) // the echo of our own message was stored first
        }
    }

    private suspend fun touchChat(chatId: String, lastText: String, ts: Long) {
        val existing = dao.getChat(chatId)
            ?: ChatEntity(chatId, chatId.substringBefore('@'), chatId.endsWith("@g.us"), "", 0, 0)
        dao.upsertChat(existing.copy(lastText = lastText, lastTimestamp = ts, hidden = false))
    }

    private fun preview(m: MessageEntity): String = when (m.kind) {
        "image" -> "[Photo]" + if (m.text.isNotBlank()) " ${m.text}" else ""
        "video" -> "[Video]" + if (m.text.isNotBlank()) " ${m.text}" else ""
        "document" -> "[File] " + m.fileName.ifBlank { m.text }
        "viewonce" -> "[View once message]"
        "deleted" -> "This message was deleted"
        else -> m.text
    }
}
