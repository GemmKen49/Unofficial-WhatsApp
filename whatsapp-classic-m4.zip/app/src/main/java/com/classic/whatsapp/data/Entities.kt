package com.classic.whatsapp.data

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

const val STATUS_SENDING = 0
const val STATUS_SENT = 1
const val STATUS_FAILED = 2
const val STATUS_DELIVERED = 3
const val STATUS_READ = 4

@Entity(tableName = "chats")
data class ChatEntity(
    @PrimaryKey val chatId: String,
    val title: String,
    val isGroup: Boolean,
    val lastText: String,
    val lastTimestamp: Long,
    val unread: Int,
    /** User-chosen local name; empty = use [title]. */
    val customName: String = "",
    val hidden: Boolean = false,
) {
    val displayTitle: String get() = customName.ifBlank { title }
}

@Entity(
    tableName = "messages",
    primaryKeys = ["chatId", "messageId"],
    indices = [Index("chatId", "timestamp")],
)
data class MessageEntity(
    val chatId: String,
    val messageId: String,
    val senderId: String,
    val senderName: String,
    /** Message text, or the caption for media. */
    val text: String,
    val timestamp: Long,
    val fromMe: Boolean,
    val status: Int,
    /** text | image | video | document | viewonce | deleted */
    val kind: String = "text",
    val mediaPath: String = "",
    val thumbPath: String = "",
    val mimeType: String = "",
    val fileName: String = "",
    val fileLength: Long = 0,
    /** JSON from MediaDescriptor, used to download later. */
    val mediaRef: String = "",
    /** Incoming only: false until a read receipt was handled for it. */
    val incomingRead: Boolean = true,
    /** Quote: id/author/text of the message this one replies to (empty = not a reply). */
    val replyToId: String = "",
    val replyToSender: String = "",
    val replyToText: String = "",
)
