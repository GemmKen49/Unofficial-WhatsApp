package com.classic.whatsapp.ui.conversation

import android.content.ActivityNotFoundException
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.core.content.FileProvider
import com.classic.whatsapp.ClassicApp
import com.classic.whatsapp.Notifier
import com.classic.whatsapp.data.*
import com.classic.whatsapp.ui.chats.ChatActionsDialog
import com.classic.whatsapp.ui.formatTime
import java.io.File
import java.util.UUID
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** WhatsApp's read-receipt blue, fixed on purpose (independent of the dynamic theme colours). */
private val ReadBlue = Color(0xFF34B7F1)

@Composable
fun ConversationScreen(chatId: String, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val app = ctx.applicationContext as ClassicApp
    val repo = app.repo
    val messages by repo.messages(chatId).collectAsState(initial = emptyList())
    val chat by repo.chat(chatId).collectAsState(initial = null as ChatEntity?)
    val foreground by repo.foreground.collectAsState()
    val downloading by repo.downloading.collectAsState()
    val error by repo.lastError.collectAsState()
    val share by app.pendingShare.collectAsState()
    val scope = rememberCoroutineScope()

    var draft by remember { mutableStateOf("") }
    var attach by remember { mutableStateOf<List<PendingFile>>(emptyList()) }
    var captionSeed by remember { mutableStateOf("") }
    var attachMenu by remember { mutableStateOf(false) }
    var showActions by remember { mutableStateOf(false) }
    var selected by remember { mutableStateOf<MessageEntity?>(null) }
    var replyTo by remember { mutableStateOf<MessageEntity?>(null) }

    // Take over files/text shared or forwarded here once this chat was chosen as the target.
    LaunchedEffect(share, chatId) {
        val s = share
        if (s != null && s.target == chatId) {
            if (s.files.isNotEmpty()) {
                attach = s.files
                captionSeed = s.text
            } else if (s.text.isNotBlank()) {
                draft = s.text
            }
            app.pendingShare.value = null
        }
    }

    // While this chat is visible: acknowledge incoming messages (read receipts) and clear unread.
    LaunchedEffect(chatId, foreground) {
        if (foreground) repo.openChat(chatId) else repo.closeChat()
    }
    LaunchedEffect(chatId, foreground, messages.size) {
        if (foreground) {
            repo.markConversationRead(chatId)
            Notifier.cancel(ctx, chatId)
        }
    }
    DisposableEffect(chatId) { onDispose { repo.closeChat() } }

    val pickMedia = rememberLauncherForActivityResult(ActivityResultContracts.PickMultipleVisualMedia(10)) { uris ->
        if (uris.isNotEmpty()) scope.launch {
            captionSeed = ""
            attach = withContext(Dispatchers.IO) { uris.mapNotNull { MediaFiles.importUri(ctx, it) } }
        }
    }
    val pickFiles = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        if (uris.isNotEmpty()) scope.launch {
            captionSeed = ""
            attach = withContext(Dispatchers.IO) { uris.mapNotNull { MediaFiles.importUri(ctx, it) } }
        }
    }

    fun onTap(m: MessageEntity) {
        when {
            m.status == STATUS_FAILED -> scope.launch { repo.retry(chatId, m.messageId) }
            m.kind == "image" || m.kind == "video" || m.kind == "document" -> {
                if (m.mediaPath.isNotBlank() && File(m.mediaPath).exists()) {
                    openFile(ctx, m.mediaPath, m.mimeType)
                } else if (!m.fromMe) {
                    scope.launch { repo.downloadMedia(chatId, m.messageId) }
                }
            }
        }
    }

    Column(Modifier.fillMaxSize().statusBarsPadding().imePadding()) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back") }
            Text(
                chat?.displayTitle ?: chatId.substringBefore('@'),
                style = MaterialTheme.typography.titleMedium,
                modifier = Modifier.weight(1f),
            )
            IconButton(onClick = { showActions = true }) { Icon(Icons.Default.MoreVert, contentDescription = "Chat options") }
        }
        HorizontalDivider()

        LazyColumn(
            modifier = Modifier.weight(1f).fillMaxWidth(),
            reverseLayout = true,
            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp),
        ) {
            items(messages.asReversed(), key = { it.messageId }) { m ->
                Bubble(
                    m,
                    isGroup = chat?.isGroup == true,
                    downloading = m.messageId in downloading,
                    onTap = { onTap(m) },
                    onLong = { selected = m },
                )
            }
        }

        error?.let {
            Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(horizontal = 12.dp))
        }

        replyTo?.let { r ->
            Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.width(3.dp).height(32.dp).background(MaterialTheme.colorScheme.primary))
                Column(Modifier.weight(1f).padding(start = 8.dp)) {
                    Text(
                        if (r.fromMe) "Replying to yourself" else "Replying to ${r.senderName.ifBlank { chat?.displayTitle.orEmpty() }}",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.primary,
                    )
                    Text(repo.quoteText(r), maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodySmall)
                }
                IconButton(onClick = { replyTo = null }) { Icon(Icons.Default.Close, contentDescription = "Cancel reply") }
            }
        }

        Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.Bottom) {
            Box {
                IconButton(onClick = { attachMenu = true }) { Icon(Icons.Default.Add, contentDescription = "Attach") }
                DropdownMenu(expanded = attachMenu, onDismissRequest = { attachMenu = false }) {
                    DropdownMenuItem(text = { Text("Photo or video") }, onClick = {
                        attachMenu = false
                        pickMedia.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageAndVideo))
                    })
                    DropdownMenuItem(text = { Text("File") }, onClick = {
                        attachMenu = false
                        pickFiles.launch(arrayOf("*/*"))
                    })
                }
            }
            OutlinedTextField(
                value = draft,
                onValueChange = { draft = it },
                placeholder = { Text("Message") },
                maxLines = 5,
                modifier = Modifier.weight(1f),
            )
            IconButton(
                enabled = draft.isNotBlank(),
                onClick = {
                    val text = draft.trim()
                    val quoted = replyTo
                    draft = ""
                    replyTo = null
                    scope.launch { repo.sendText(chatId, text, quoted) }
                },
            ) { Icon(Icons.AutoMirrored.Filled.Send, contentDescription = "Send") }
        }
    }

    // ---- attachment confirmation ----
    if (attach.isNotEmpty()) {
        var caption by remember(attach) { mutableStateOf(captionSeed) }
        AlertDialog(
            onDismissRequest = { attach.forEach { File(it.path).delete() }; attach = emptyList() },
            title = { Text("Send ${attach.size} file(s)?") },
            text = {
                Column {
                    attach.take(5).forEach {
                        Text("${it.name}  ${MediaFiles.formatSize(it.size)}", style = MaterialTheme.typography.bodySmall)
                    }
                    if (attach.size > 5) Text("+ ${attach.size - 5} more", style = MaterialTheme.typography.bodySmall)
                    OutlinedTextField(
                        value = caption,
                        onValueChange = { caption = it },
                        label = { Text("Caption (optional)") },
                        modifier = Modifier.padding(top = 12.dp),
                    )
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    val files = attach
                    attach = emptyList()
                    scope.launch {
                        files.forEachIndexed { i, f -> repo.sendMedia(chatId, f, if (i == 0) caption.trim() else "") }
                    }
                }) { Text("Send") }
            },
            dismissButton = {
                TextButton(onClick = { attach.forEach { File(it.path).delete() }; attach = emptyList() }) { Text("Cancel") }
            },
        )
    }

    // ---- message actions ----
    selected?.let { m ->
        val canReply = m.kind != "deleted" && m.status != STATUS_SENDING && m.status != STATUS_FAILED
        val hasFile = m.mediaPath.isNotBlank() && File(m.mediaPath).exists()
        val canForward = (m.kind == "text" && m.text.isNotBlank()) ||
            ((m.kind == "image" || m.kind == "video" || m.kind == "document") && hasFile)
        val canDeleteForAll = m.fromMe && m.kind != "deleted" &&
            (m.status == STATUS_SENT || m.status == STATUS_DELIVERED || m.status == STATUS_READ)
        AlertDialog(
            onDismissRequest = { selected = null },
            title = { Text("Message") },
            text = {
                Column {
                    if (canReply) TextButton(onClick = { replyTo = m; selected = null }) { Text("Reply") }
                    if (canForward) TextButton(onClick = {
                        selected = null
                        scope.launch { startForward(ctx, app, m) }
                    }) { Text("Forward") }
                    if (m.text.isNotBlank() && m.kind != "deleted") TextButton(onClick = {
                        ctx.getSystemService(ClipboardManager::class.java)
                            .setPrimaryClip(ClipData.newPlainText("message", m.text))
                        selected = null
                    }) { Text("Copy text") }
                    TextButton(onClick = {
                        selected = null
                        scope.launch { repo.deleteForMe(chatId, m.messageId) }
                    }) { Text("Delete for me") }
                    if (canDeleteForAll) TextButton(onClick = {
                        selected = null
                        scope.launch { repo.deleteForEveryone(chatId, m.messageId) }
                    }) { Text("Delete for everyone") }
                }
            },
            confirmButton = {},
            dismissButton = { TextButton(onClick = { selected = null }) { Text("Close") } },
        )
    }

    chat?.let { if (showActions) ChatActionsDialog(it, onDismiss = { showActions = false }, onGone = onBack) }
}

/** Forward = open the "Share to…" chooser with this message's content. */
private suspend fun startForward(ctx: Context, app: ClassicApp, m: MessageEntity) {
    val request = if (m.kind == "text") {
        ShareRequest(emptyList(), m.text)
    } else {
        val file = withContext(Dispatchers.IO) {
            val src = File(m.mediaPath)
            val dir = File(ctx.cacheDir, "outgoing").apply { mkdirs() }
            val copy = File(dir, UUID.randomUUID().toString() + "-" + MediaFiles.safe(m.fileName.ifBlank { src.name }))
            src.copyTo(copy, overwrite = true)
            PendingFile(copy.path, m.fileName.ifBlank { src.name }, m.mimeType.ifBlank { "application/octet-stream" }, copy.length())
        }
        ShareRequest(listOf(file), m.text)
    }
    app.pendingShare.value = request
}

private fun openFile(ctx: Context, path: String, mime: String) {
    try {
        val uri = FileProvider.getUriForFile(ctx, "${ctx.packageName}.files", File(path))
        val i = Intent(Intent.ACTION_VIEW)
            .setDataAndType(uri, mime.ifBlank { "*/*" })
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        ctx.startActivity(i)
    } catch (e: ActivityNotFoundException) {
        Toast.makeText(ctx, "No app can open this file", Toast.LENGTH_SHORT).show()
    } catch (e: Exception) {
        Toast.makeText(ctx, "Cannot open file", Toast.LENGTH_SHORT).show()
    }
}

@Composable
private fun rememberBitmap(path: String, maxSide: Int): ImageBitmap? {
    val state = produceState<ImageBitmap?>(null, path) {
        value = if (path.isBlank()) null
        else withContext(Dispatchers.IO) { MediaFiles.decodeSampled(path, maxSide)?.asImageBitmap() }
    }
    return state.value
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun Bubble(m: MessageEntity, isGroup: Boolean, downloading: Boolean, onTap: () -> Unit, onLong: () -> Unit) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = if (m.fromMe) Arrangement.End else Arrangement.Start) {
        Surface(
            shape = RoundedCornerShape(6.dp),
            color = if (m.fromMe) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant,
            modifier = Modifier.widthIn(max = 300.dp).combinedClickable(onClick = onTap, onLongClick = onLong),
        ) {
            Column(Modifier.padding(horizontal = 10.dp, vertical = 6.dp)) {
                if (isGroup && !m.fromMe && m.senderName.isNotBlank()) {
                    Text(m.senderName, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
                }
                if (m.replyToId.isNotBlank() && m.kind != "deleted") {
                    Row(Modifier.padding(bottom = 4.dp).height(IntrinsicSize.Min)) {
                        Box(Modifier.width(3.dp).fillMaxHeight().background(MaterialTheme.colorScheme.primary))
                        Text(
                            m.replyToText.ifBlank { "Message" },
                            style = MaterialTheme.typography.bodySmall,
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.padding(start = 6.dp),
                        )
                    }
                }
                when (m.kind) {
                    "image", "video" -> MediaPreview(m, downloading)
                    "document" -> Column(Modifier.padding(vertical = 4.dp)) {
                        Text(m.fileName.ifBlank { "File" }, style = MaterialTheme.typography.bodyMedium)
                        Text(
                            when {
                                downloading -> "Downloading…"
                                m.mediaPath.isNotBlank() -> "Tap to open · ${MediaFiles.formatSize(m.fileLength)}"
                                m.fromMe -> MediaFiles.formatSize(m.fileLength)
                                else -> "Tap to download · ${MediaFiles.formatSize(m.fileLength)}"
                            },
                            style = MaterialTheme.typography.labelSmall,
                        )
                    }
                    "viewonce" -> Text(
                        "View-once message. Open it on your phone.",
                        style = MaterialTheme.typography.bodyMedium,
                        fontStyle = FontStyle.Italic,
                    )
                    "deleted" -> Text(
                        if (m.fromMe) "You deleted this message" else "This message was deleted",
                        style = MaterialTheme.typography.bodyMedium,
                        fontStyle = FontStyle.Italic,
                    )
                }
                if (m.text.isNotBlank() && m.kind != "deleted") Text(m.text, style = MaterialTheme.typography.bodyMedium)

                Row(Modifier.align(Alignment.End), verticalAlignment = Alignment.CenterVertically) {
                    val dim = MaterialTheme.colorScheme.onSurfaceVariant
                    when (m.status) {
                        STATUS_SENDING -> Text("sending…", style = MaterialTheme.typography.labelSmall, color = dim)
                        STATUS_FAILED -> Text(
                            "failed to send · tap to retry",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.error,
                        )
                        else -> {
                            Text(formatTime(m.timestamp), style = MaterialTheme.typography.labelSmall, color = dim)
                            if (m.fromMe && m.kind != "deleted") {
                                val ticks = if (m.status == STATUS_SENT) " ✓" else " ✓✓"
                                Text(
                                    ticks,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = if (m.status == STATUS_READ) ReadBlue else dim,
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun MediaPreview(m: MessageEntity, downloading: Boolean) {
    val path = if (m.kind == "image" && m.mediaPath.isNotBlank()) m.mediaPath else m.thumbPath
    val bmp = rememberBitmap(path, 800)
    Box(
        Modifier.width(220.dp).height(160.dp).background(MaterialTheme.colorScheme.surface),
        contentAlignment = Alignment.Center,
    ) {
        if (bmp != null) {
            Image(bmp, contentDescription = null, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
        }
        val label = when {
            downloading -> null
            m.mediaPath.isNotBlank() && m.kind == "video" -> "▶ Play"
            m.mediaPath.isBlank() && !m.fromMe -> "Tap to download ${MediaFiles.formatSize(m.fileLength)}".trim()
            else -> null
        }
        if (downloading) CircularProgressIndicator()
        else if (label != null) {
            Surface(color = MaterialTheme.colorScheme.scrim.copy(alpha = 0.55f), shape = RoundedCornerShape(4.dp)) {
                Text(label, color = MaterialTheme.colorScheme.surface, modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp), style = MaterialTheme.typography.labelMedium)
            }
        }
    }
}
