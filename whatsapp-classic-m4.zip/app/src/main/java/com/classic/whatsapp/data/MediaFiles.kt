package com.classic.whatsapp.data

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaMetadataRetriever
import android.media.ThumbnailUtils
import android.net.Uri
import android.provider.OpenableColumns
import android.util.Size
import android.webkit.MimeTypeMap
import java.io.ByteArrayOutputStream
import java.io.File
import java.util.UUID

/** A local file waiting to be sent (picked or shared). */
data class PendingFile(val path: String, val name: String, val mime: String, val size: Long)

/** Files handed to the app from another app's share sheet. */
data class ShareRequest(val files: List<PendingFile>, val text: String, val target: String? = null)

object MediaFiles {
    const val MAX_UPLOAD_BYTES = 64L * 1024 * 1024

    fun dir(ctx: Context, sub: String): File = File(ctx.filesDir, "media/$sub").apply { mkdirs() }

    fun safe(s: String) = s.replace(Regex("[^A-Za-z0-9._-]"), "_")

    fun kindOf(mime: String) = when {
        mime.startsWith("image/") -> "image"
        mime.startsWith("video/") -> "video"
        else -> "document"
    }

    fun extension(mime: String, name: String): String {
        val fromName = name.substringAfterLast('.', "")
        if (fromName.isNotBlank() && fromName.length <= 5) return fromName
        return MimeTypeMap.getSingleton().getExtensionFromMimeType(mime) ?: "bin"
    }

    fun saveThumb(ctx: Context, id: String, bytes: ByteArray): String {
        val f = File(dir(ctx, "thumbs"), safe(id) + ".jpg")
        f.writeBytes(bytes)
        return f.path
    }

    /** Small JPEG preview for outgoing images/videos (empty if it cannot be made). */
    fun thumbnail(file: File, kind: String): ByteArray = try {
        val size = Size(160, 160)
        val bmp: Bitmap? = when (kind) {
            "image" -> ThumbnailUtils.createImageThumbnail(file, size, null)
            "video" -> ThumbnailUtils.createVideoThumbnail(file, size, null)
            else -> null
        }
        if (bmp == null) ByteArray(0)
        else ByteArrayOutputStream().also { bmp.compress(Bitmap.CompressFormat.JPEG, 60, it) }.toByteArray()
    } catch (e: Exception) {
        ByteArray(0)
    }

    fun videoDurationSecs(file: File): Int = try {
        val r = MediaMetadataRetriever()
        try {
            r.setDataSource(file.path)
            ((r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L) / 1000).toInt()
        } finally {
            r.release()
        }
    } catch (e: Exception) {
        0
    }

    /** Copies a content URI into the app cache so it can be uploaded later. */
    fun importUri(ctx: Context, uri: Uri): PendingFile? = try {
        val cr = ctx.contentResolver
        val mime = cr.getType(uri) ?: "application/octet-stream"
        var name = "file"
        cr.query(uri, null, null, null, null)?.use { c ->
            if (c.moveToFirst()) {
                val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (i >= 0) name = c.getString(i) ?: name
            }
        }
        val dir = File(ctx.cacheDir, "outgoing").apply { mkdirs() }
        val out = File(dir, UUID.randomUUID().toString() + "-" + safe(name))
        cr.openInputStream(uri)?.use { input -> out.outputStream().use { input.copyTo(it) } }
            ?: throw IllegalStateException("cannot open $uri")
        PendingFile(out.path, name, mime, out.length())
    } catch (e: Exception) {
        null
    }

    fun decodeSampled(path: String, maxSide: Int): Bitmap? = try {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(path, bounds)
        var sample = 1
        while (bounds.outWidth / sample > maxSide * 2 || bounds.outHeight / sample > maxSide * 2) sample *= 2
        BitmapFactory.decodeFile(path, BitmapFactory.Options().apply { inSampleSize = sample })
    } catch (e: Exception) {
        null
    }

    fun formatSize(bytes: Long): String = when {
        bytes <= 0 -> ""
        bytes < 1024 * 1024 -> "${(bytes / 1024).coerceAtLeast(1)} KB"
        else -> String.format("%.1f MB", bytes / 1024.0 / 1024.0)
    }
}
