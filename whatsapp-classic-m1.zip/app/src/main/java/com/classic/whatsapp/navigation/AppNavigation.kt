package com.classic.whatsapp.navigation

import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.MailOutline
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.classic.whatsapp.ClassicApp
import com.classic.whatsapp.ui.chats.ChatsScreen
import com.classic.whatsapp.ui.pairing.PairingScreen
import com.classic.whatsapp.ui.settings.SettingsScreen

private enum class Dest(val route: String, val label: String, val icon: ImageVector) {
    Chats("chats", "Chats", Icons.Default.MailOutline),
    Settings("settings", "Settings", Icons.Default.Settings),
}

@Composable
fun AppRoot() {
    val app = LocalContext.current.applicationContext as ClassicApp
    val linked by app.session.linked.collectAsState()
    if (linked) MainScaffold() else PairingScreen()
}

@Composable
private fun MainScaffold() {
    val nav = rememberNavController()
    val route = nav.currentBackStackEntryAsState().value?.destination?.route
    Scaffold(
        bottomBar = {
            NavigationBar {
                Dest.entries.forEach { d ->
                    NavigationBarItem(
                        selected = route == d.route,
                        onClick = {
                            nav.navigate(d.route) {
                                popUpTo(nav.graph.startDestinationId) { saveState = true }
                                launchSingleTop = true
                                restoreState = true
                            }
                        },
                        icon = { Icon(d.icon, contentDescription = null) },
                        label = { Text(d.label) },
                    )
                }
            }
        },
    ) { pad ->
        NavHost(nav, startDestination = Dest.Chats.route, modifier = Modifier.padding(pad)) {
            composable(Dest.Chats.route) { ChatsScreen() }
            composable(Dest.Settings.route) { SettingsScreen() }
        }
    }
}
