package com.classic.whatsapp.messaging

import kotlinx.coroutines.flow.SharedFlow

class PairingException(message: String) : Exception(message)

/** Milestone 1 surface. Chat/message methods are added in Milestone 2. */
interface MessagingClient {
    val events: SharedFlow<MessagingEvent>

    /** Resume an existing linked-device session. */
    fun start()
    fun stop()

    /** Starts a fresh pairing attempt; returns when the code arrives. */
    suspend fun requestPairingCode(phoneNumber: String): MessagingEvent.PairingCode

    /** Stops the engine and deletes the local session database. */
    suspend fun clearSession()
}
