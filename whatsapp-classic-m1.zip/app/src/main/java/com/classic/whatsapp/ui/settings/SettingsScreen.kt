package com.classic.whatsapp.ui.settings

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.classic.whatsapp.ClassicApp
import kotlinx.coroutines.launch

@Composable
fun SettingsScreen() {
    val app = LocalContext.current.applicationContext as ClassicApp
    val status by app.status.collectAsState()
    val scope = rememberCoroutineScope()
    var confirm by remember { mutableStateOf(false) }

    Column(Modifier.fillMaxSize().padding(24.dp)) {
        Text("Connection", style = MaterialTheme.typography.titleMedium)
        Text(status, modifier = Modifier.padding(top = 4.dp, bottom = 24.dp))
        Text("This device is linked as an Electron companion (unofficial client).", style = MaterialTheme.typography.bodySmall)
        Button(onClick = { confirm = true }, modifier = Modifier.padding(top = 24.dp)) {
            Text("Disconnect and clear session")
        }
    }

    if (confirm) {
        AlertDialog(
            onDismissRequest = { confirm = false },
            title = { Text("Clear local session?") },
            text = { Text("You will need to link again. Also remove this device in WhatsApp > Linked devices.") },
            confirmButton = {
                TextButton(onClick = {
                    confirm = false
                    scope.launch {
                        app.messaging.clearSession()
                        app.session.setLinked(false)
                    }
                }) { Text("Clear") }
            },
            dismissButton = { TextButton(onClick = { confirm = false }) { Text("Cancel") } },
        )
    }
}
