package com.classic.whatsapp

import android.app.Application
import com.classic.whatsapp.data.SessionStore
import com.classic.whatsapp.messaging.MessagingClient
import com.classic.whatsapp.messaging.MessagingEvent
import com.classic.whatsapp.messaging.RustMessagingClient
import java.io.File
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class ClassicApp : Application() {
    lateinit var session: SessionStore
        private set
    lateinit var messaging: MessagingClient
        private set

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private val _status = MutableStateFlow("Not connected")
    val status: StateFlow<String> = _status.asStateFlow()

    override fun onCreate() {
        super.onCreate()
        session = SessionStore(this)
        messaging = RustMessagingClient(File(filesDir, "wa"))

        scope.launch {
            messaging.events.collect { e ->
                when (e) {
                    is MessagingEvent.Paired -> { session.setLinked(true); _status.value = "Linked, connecting…" }
                    is MessagingEvent.Connected -> _status.value = "Connected"
                    is MessagingEvent.Disconnected -> _status.value = "Disconnected, retrying…"
                    is MessagingEvent.LoggedOut -> { session.setLinked(false); _status.value = "Logged out from phone" }
                    is MessagingEvent.Fatal -> _status.value = "Error: ${e.reason}"
                    else -> Unit
                }
            }
        }
        // Milestone 1: connection only lives while the process does.
        // Milestone 2 moves this into a foreground service.
        if (session.linked.value) {
            _status.value = "Connecting…"
            messaging.start()
        }
    }
}
