package com.classic.whatsapp.ui.pairing

import android.app.Application
import android.os.SystemClock
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.classic.whatsapp.ClassicApp
import com.classic.whatsapp.messaging.MessagingEvent
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

sealed interface PairingUiState {
    data object Idle : PairingUiState
    data object Requesting : PairingUiState
    data class CodeReady(val code: String, val expiresAtElapsed: Long) : PairingUiState
    data class Failed(val message: String) : PairingUiState
}

class PairingViewModel(app: Application) : AndroidViewModel(app) {
    private val client = (app as ClassicApp).messaging
    private val _state = MutableStateFlow<PairingUiState>(PairingUiState.Idle)
    val state: StateFlow<PairingUiState> = _state.asStateFlow()

    init {
        // Success (Paired) is handled app-wide by ClassicApp, which flips the UI to the main screen.
        viewModelScope.launch {
            client.events.collect { e ->
                if (_state.value is PairingUiState.CodeReady) {
                    when (e) {
                        is MessagingEvent.PairFailed -> _state.value = PairingUiState.Failed(e.reason)
                        is MessagingEvent.Fatal -> _state.value = PairingUiState.Failed(e.reason)
                        else -> Unit
                    }
                }
            }
        }
    }

    fun request(countryCode: String, nationalNumber: String) {
        val national = nationalNumber.filter(Char::isDigit).trimStart('0') // drop trunk prefix
        val full = countryCode + national
        if (national.isEmpty() || full.length !in 8..15) {
            _state.value = PairingUiState.Failed("Enter a valid number (country code + number, 8-15 digits in total).")
            return
        }
        _state.value = PairingUiState.Requesting
        viewModelScope.launch {
            _state.value = try {
                val c = client.requestPairingCode(full)
                PairingUiState.CodeReady(c.code, SystemClock.elapsedRealtime() + c.expiresInSeconds * 1000)
            } catch (e: TimeoutCancellationException) {
                PairingUiState.Failed("No code received (timed out). Check your connection and retry.")
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                PairingUiState.Failed(e.message ?: "Pairing failed")
            }
        }
    }
}
