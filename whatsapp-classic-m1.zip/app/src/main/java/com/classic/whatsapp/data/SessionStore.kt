package com.classic.whatsapp.data

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/** Non-secret "is this device linked" flag. Secrets live only in the Rust session DB. */
class SessionStore(context: Context) {
    private val prefs = context.getSharedPreferences("session", Context.MODE_PRIVATE)
    private val _linked = MutableStateFlow(prefs.getBoolean("linked", false))
    val linked: StateFlow<Boolean> = _linked.asStateFlow()

    fun setLinked(value: Boolean) {
        prefs.edit().putBoolean("linked", value).apply()
        _linked.value = value
    }
}
