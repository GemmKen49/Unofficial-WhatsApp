#!/usr/bin/env bash
# Builds the Rust engine for Android ARM64 and generates Kotlin bindings.
# Needs: rustup target aarch64-linux-android, cargo-ndk, ANDROID_NDK_HOME.
set -euo pipefail
cd "$(dirname "$0")/../rust"

cargo ndk -t arm64-v8a -o ../app/src/main/jniLibs build --release -p whatsapp_classic_engine

cargo run --release -p uniffi-bindgen -- generate \
  --library target/aarch64-linux-android/release/libwhatsapp_classic_engine.so \
  --language kotlin --no-format \
  --out-dir ../app/src/main/java
