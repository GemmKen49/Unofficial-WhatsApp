//! WhatsApp Classic engine: the ONLY place that touches upstream `whatsapp-rust`.
//!
//! Kotlin sees only the stable types below (`Engine`, `EngineEvent`,
//! `EngineListener`, `EngineError`). If upstream changes its API, fix
//! `run_bot` / `forward` here and nothing else.
//!
//! NOTE: written against the whatsapp-rust 0.7.0 docs and the upstream demo
//! bot. Not compiled yet; expect to fix small signature mismatches.

uniffi::setup_scaffolding!();

use std::path::PathBuf;
use std::sync::{Arc, Mutex, OnceLock};

use whatsapp_rust::bot::Bot;
use whatsapp_rust::pair_code::{CompanionWebClientType, PairCodeOptions};
use whatsapp_rust::store::SqliteStore;
use whatsapp_rust::types::events::Event;
use whatsapp_rust::TokioRuntime;
use whatsapp_rust_tokio_transport::TokioWebSocketTransportFactory;
use whatsapp_rust_ureq_http_client::UreqHttpClient;

#[derive(Debug, thiserror::Error, uniffi::Error)]
pub enum EngineError {
    #[error("{0}")]
    Invalid(String),
    #[error("{0}")]
    Internal(String),
}

/// Stable, protocol-agnostic events for the Android side.
#[derive(Debug, Clone, uniffi::Enum)]
pub enum EngineEvent {
    PairingCode { code: String, timeout_secs: u64 },
    PairingQr { code: String },
    Paired,
    PairFailed { reason: String },
    Connected,
    Disconnected,
    LoggedOut,
    Fatal { reason: String },
}

#[uniffi::export(with_foreign)]
pub trait EngineListener: Send + Sync {
    fn on_event(&self, event: EngineEvent);
}

fn runtime() -> &'static tokio::runtime::Runtime {
    static RT: OnceLock<tokio::runtime::Runtime> = OnceLock::new();
    RT.get_or_init(|| {
        tokio::runtime::Builder::new_multi_thread()
            .worker_threads(2)
            .enable_all()
            .build()
            .expect("failed to build tokio runtime")
    })
}

#[derive(uniffi::Object)]
pub struct Engine {
    data_dir: PathBuf,
    listener: Arc<dyn EngineListener>,
    task: Mutex<Option<tokio::task::JoinHandle<()>>>,
}

#[uniffi::export]
impl Engine {
    #[uniffi::constructor]
    pub fn new(data_dir: String, listener: Arc<dyn EngineListener>) -> Arc<Self> {
        // Warn level only: upstream logs phone numbers and pair codes at info.
        android_logger::init_once(
            android_logger::Config::default()
                .with_max_level(log::LevelFilter::Warn)
                .with_tag("WAClassic"),
        );
        let _ = std::fs::create_dir_all(&data_dir);
        Arc::new(Self {
            data_dir: PathBuf::from(data_dir),
            listener,
            task: Mutex::new(None),
        })
    }

    /// Start (or resume) the connection. With `pairing_phone` set (digits,
    /// country code first, no leading zero) a pairing code is requested; it
    /// arrives as `EngineEvent::PairingCode`. With `None`, an existing
    /// session is resumed.
    pub fn start(&self, pairing_phone: Option<String>) -> Result<(), EngineError> {
        let phone = pairing_phone.map(|p| p.chars().filter(|c| c.is_ascii_digit()).collect::<String>());
        if let Some(p) = &phone {
            if p.len() < 8 || p.len() > 15 || p.starts_with('0') {
                return Err(EngineError::Invalid("Invalid phone number".into()));
            }
        }
        let mut guard = self.task.lock().map_err(|e| EngineError::Internal(e.to_string()))?;
        if guard.as_ref().is_some_and(|h| !h.is_finished()) {
            return Ok(());
        }
        let db = self.data_dir.join("whatsapp.db");
        let listener = self.listener.clone();
        *guard = Some(runtime().spawn(async move {
            if let Err(e) = run_bot(db, phone, listener.clone()).await {
                listener.on_event(EngineEvent::Fatal { reason: e.to_string() });
            }
        }));
        Ok(())
    }

    pub fn stop(&self) {
        if let Ok(mut guard) = self.task.lock() {
            if let Some(h) = guard.take() {
                h.abort();
            }
        }
    }

    pub fn is_running(&self) -> bool {
        self.task
            .lock()
            .map(|g| g.as_ref().is_some_and(|h| !h.is_finished()))
            .unwrap_or(false)
    }

    /// Stop and delete the local session database.
    pub fn clear_session(&self) -> Result<(), EngineError> {
        self.stop();
        for name in ["whatsapp.db", "whatsapp.db-wal", "whatsapp.db-shm", "whatsapp.db-journal"] {
            match std::fs::remove_file(self.data_dir.join(name)) {
                Ok(()) => {}
                Err(e) if e.kind() == std::io::ErrorKind::NotFound => {}
                Err(e) => return Err(EngineError::Internal(e.to_string())),
            }
        }
        Ok(())
    }
}

async fn run_bot(
    db: PathBuf,
    phone: Option<String>,
    listener: Arc<dyn EngineListener>,
) -> anyhow::Result<()> {
    let backend = Arc::new(
        SqliteStore::new(db.to_string_lossy().as_ref())
            .await
            .map_err(|e| anyhow::anyhow!("{e}"))?,
    );

    let mut builder = Bot::builder()
        .with_backend(backend)
        .with_transport_factory(TokioWebSocketTransportFactory::new())
        .with_http_client(UreqHttpClient::new())
        .with_runtime(TokioRuntime);

    if let Some(phone_number) = phone {
        builder = builder.with_pair_code(PairCodeOptions {
            phone_number,
            // User decision: register as an Electron companion (see docs/known-limitations.md).
            platform_id: Some(CompanionWebClientType::Electron),
            ..Default::default()
        });
    }

    let mut bot = builder
        .on_event(move |event, _client| {
            let l = listener.clone();
            async move { forward(&l, event) }
        })
        .build()
        .await
        .map_err(|e| anyhow::anyhow!("{e}"))?;

    bot.run()
        .await
        .map_err(|e| anyhow::anyhow!("{e}"))?
        .await
        .map_err(|e| anyhow::anyhow!("{e}"))?;
    Ok(())
}

fn forward(l: &Arc<dyn EngineListener>, ev: Event) {
    let out = match ev {
        Event::PairingCode { code, timeout } => EngineEvent::PairingCode {
            code,
            timeout_secs: timeout.as_secs(),
        },
        Event::PairingQrCode { code, .. } => EngineEvent::PairingQr { code },
        Event::PairSuccess(_) => EngineEvent::Paired,
        Event::PairError(e) => EngineEvent::PairFailed { reason: format!("{e:?}") },
        Event::Connected(_) => EngineEvent::Connected,
        Event::Disconnected(_) => EngineEvent::Disconnected,
        Event::LoggedOut(_) => EngineEvent::LoggedOut,
        Event::ConnectFailure(e) => EngineEvent::Fatal { reason: format!("{e:?}") },
        Event::TemporaryBan(e) => EngineEvent::Fatal { reason: format!("{e:?}") },
        _ => return,
    };
    l.on_event(out);
}
