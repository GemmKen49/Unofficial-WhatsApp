# Architecture

- `rust/engine`: only code that imports `whatsapp-rust`. Exposes `Engine`, `EngineEvent`, `EngineListener`,
  `EngineError` through UniFFI. Upstream API changes should only touch `run_bot` and `forward`.
- `messaging/`: Kotlin adapter (`RustMessagingClient`) maps generated types to stable `MessagingEvent`s.
  UI depends only on `MessagingClient`.
- Pairing: builder `with_pair_code` -> upstream emits `Event::PairingCode` -> `EngineEvent::PairingCode`.
- Upgrading whatsapp-rust: bump all `=0.7.0` pins in `rust/engine/Cargo.toml` together, fix `lib.rs`.
