# Known limitations

- **Companion identity: Electron.** Pairing registers as an Electron (desktop-type) companion via
  `PairCodeOptions.platform_id`. Android companion types need server-side attestation upstream and are not used.
  The official app lists this device as a desktop/web-type device.
- **Unofficial client.** Account restrictions or bans are possible.
- **Rust adapter partly verified.** Dependencies compile; adapter fixed against compiler errors (Backend by value, Arc<Event>, PairingCode struct). Kotlin side never compiled.
  signatures (`Bot::builder`, `with_runtime`, `Event` variants, `SqliteStore`) may need small fixes.
- **Cargo features unverified:** `SqliteStore` / transport re-exports assumed to be in default features.
- **Android build of the Rust tree unverified** (bundled SQLite and TLS crypto need NDK clang).
- **No background service yet.** The connection lives only while the process lives (Milestone 2: foreground service).
- **Storage:** session DB is in app-private storage (`filesDir/wa/whatsapp.db`), not Keystore-wrapped yet.
  Backups are excluded via manifest rules.
- **Linked-device rules:** the primary phone (official WhatsApp, user 1) must connect at least about every 14 days.
- **GrapheneOS profiles:** unverified whether user 0 keeps its connection alive and posts notifications while user 1 is active.
- Country list is a fixed dropdown of common codes.
- **SIMD disabled.** Upstream's `simd` feature needs nightly Rust, so it is turned off (slower binary parsing only).
  If the build still pulls `simd` through another crate, switch CI to `dtolnay/rust-toolchain@nightly`.
- Upstream requires Rust >= 1.94 (edition 2024); CI uses the latest stable.
