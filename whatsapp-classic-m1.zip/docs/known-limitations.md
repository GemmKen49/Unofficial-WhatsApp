# Known limitations

- **Companion identity: Electron.** Pairing registers as an Electron (desktop-type) companion via
  `PairCodeOptions.platform_id`. Android companion types need server-side attestation upstream and are not used.
  The official app lists this device as a desktop/web-type device.
- **Unofficial client.** Account restrictions or bans are possible.
- **Never compiled.** Rust adapter is written against 0.7.0 docs and the upstream demo bot (older snapshots);
  signatures (`Bot::builder`, `with_runtime`, `Event` variants, `SqliteStore`) may need small fixes.
- **Cargo features unverified:** `SqliteStore` / transport re-exports assumed to be in default features.
- **Android build of the Rust tree unverified** (bundled SQLite and TLS crypto need NDK clang).
- **No background service yet.** The connection lives only while the process lives (Milestone 2: foreground service).
- **Storage:** session DB is in app-private storage (`filesDir/wa/whatsapp.db`), not Keystore-wrapped yet.
  Backups are excluded via manifest rules.
- **Linked-device rules:** the primary phone (official WhatsApp, user 1) must connect at least about every 14 days.
- **GrapheneOS profiles:** unverified whether user 0 keeps its connection alive and posts notifications while user 1 is active.
- Country list is a fixed dropdown of common codes.
