# Build

CI: `.github/workflows/build.yml`. Local: install rustup target `aarch64-linux-android`,
`cargo install cargo-ndk --version 3.5.4 --locked`, NDK 27.2.12479018 (`ANDROID_NDK_HOME`), then
`./scripts/build-rust.sh && gradle :app:assembleDebug` (Gradle 8.11.1, JDK 17).
