# WhatsApp Classic (Milestone 1: pairing)

Minimal native Android WhatsApp companion client: Kotlin + Compose UI, Rust engine
(`whatsapp-rust` 0.7.0, pinned) bridged with UniFFI. No Google services, no FCM.

## Build (no local toolchain needed)

1. Create an empty GitHub repo, upload the contents of this zip (or `git push`).
2. Open the **Actions** tab, run **build-apk** (it also runs on every push to `main`).
3. Download the `whatsapp-classic-apk` artifact, unzip, install `app-debug.apk`
   (`adb install app-debug.apk`, or open the file on the phone in the user profile you want it in).
4. If the build fails, paste the failing step's log here.
5. After the first green build, download the `Cargo.lock` artifact and commit it to `rust/`
   so the Rust dependency tree is pinned.

Status: **unverified** — never compiled yet. Expect a few small compile errors on first run.
See `docs/known-limitations.md`.
