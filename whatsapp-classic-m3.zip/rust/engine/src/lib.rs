//! WhatsApp Classic engine: the ONLY place that touches upstream `whatsapp-rust`.
//!
//! Kotlin sees only the stable types below (`Engine`, `EngineEvent`,
//! `EngineListener`, `EngineError`). If upstream changes its API, fix
//! `run_bot` / `forward` here and nothing else.
//!
//! Written against whatsapp-rust 0.7.0 (verified against compiler errors and docs.rs).

uniffi::setup_scaffolding!();

use std::path::PathBuf;
use std::sync::{Arc, Mutex, OnceLock};
use std::time::Duration;

use whatsapp_rust::bot::Bot;
use whatsapp_rust::download::{DownloadParams, MediaType};
use whatsapp_rust::media::{self, DocumentOptions, ImageOptions, VideoOptions};
use whatsapp_rust::types::presence::ReceiptType;
use whatsapp_rust::prelude::{wa, Jid, MessageBuilderExt, MessageExt};
use whatsapp_rust::pair_code::{CompanionWebClientType, PairCodeOptions};
use whatsapp_rust::store::SqliteStore;
use whatsapp_rust::types::events::Event;
use whatsapp_rust::{Client, TokioRuntime};
use whatsapp_rust_tokio_transport::TokioWebSocketTransportFactory;
use whatsapp_rust_ureq_http_client::UreqHttpClient;

#[derive(Debug, thiserror::Error, uniffi::Error)]
pub enum EngineError {
    #[error("{0}")]
    Invalid(String),
    #[error("{0}")]
    Internal(String),
}

const MAX_UPLOAD_BYTES: u64 = 64 * 1024 * 1024;

/// Reference to a media attachment (incoming), also used to request its download.
/// `kind` is "image", "video", "document" or "viewonce" (never downloadable).
#[derive(Debug, Clone, uniffi::Record)]
pub struct MediaInfo {
    pub kind: String,
    pub mimetype: String,
    pub file_name: String,
    pub caption: String,
    pub file_length: u64,
    pub direct_path: String,
    pub media_key: Vec<u8>,
    pub file_sha256: Vec<u8>,
    pub file_enc_sha256: Vec<u8>,
    pub thumbnail: Vec<u8>,
}

/// A local file to upload and send. `kind` is "image", "video" or "document".
#[derive(Debug, Clone, uniffi::Record)]
pub struct OutgoingMedia {
    pub chat_id: String,
    pub kind: String,
    pub path: String,
    pub mimetype: String,
    pub file_name: String,
    pub caption: String,
    pub thumbnail: Vec<u8>,
    pub duration_secs: u32,
}

/// Stable, protocol-agnostic events for the Android side.
#[derive(Debug, Clone, uniffi::Enum)]
pub enum EngineEvent {
    PairingCode { code: String, timeout_secs: u64 },
    PairingQr { code: String },
    Paired,
    PairFailed { reason: String },
    Connected,
    Disconnected,
    LoggedOut,
    Fatal { reason: String },
    /// A text message (incoming, or sent from another device of this account).
    MessageReceived {
        chat_id: String,
        sender_id: String,
        message_id: String,
        text: String,
        timestamp_ms: i64,
        from_me: bool,
        is_group: bool,
        push_name: String,
        media: Option<MediaInfo>,
    },
    /// "delivered" or "read" receipt from a recipient for messages we sent.
    ReceiptReceived {
        chat_id: String,
        message_ids: Vec<String>,
        kind: String,
    },
}

#[uniffi::export(with_foreign)]
pub trait EngineListener: Send + Sync {
    fn on_event(&self, event: EngineEvent);
}

fn runtime() -> &'static tokio::runtime::Runtime {
    static RT: OnceLock<tokio::runtime::Runtime> = OnceLock::new();
    RT.get_or_init(|| {
        tokio::runtime::Builder::new_multi_thread()
            .worker_threads(2)
            .enable_all()
            .build()
            .expect("failed to build tokio runtime")
    })
}

type ClientSlot = Arc<Mutex<Option<Arc<Client>>>>;

#[derive(uniffi::Object)]
pub struct Engine {
    data_dir: PathBuf,
    listener: Arc<dyn EngineListener>,
    task: Mutex<Option<tokio::task::JoinHandle<()>>>,
    client: ClientSlot,
}

#[uniffi::export]
impl Engine {
    #[uniffi::constructor]
    pub fn new(data_dir: String, listener: Arc<dyn EngineListener>) -> Arc<Self> {
        // Warn level only: upstream logs phone numbers and pair codes at info.
        android_logger::init_once(
            android_logger::Config::default()
                .with_max_level(log::LevelFilter::Warn)
                .with_tag("WAClassic"),
        );
        let _ = std::fs::create_dir_all(&data_dir);
        Arc::new(Self {
            data_dir: PathBuf::from(data_dir),
            listener,
            task: Mutex::new(None),
            client: Arc::new(Mutex::new(None)),
        })
    }

    /// Start (or resume) the connection. With `pairing_phone` set (digits,
    /// country code first, no leading zero) a pairing code is requested; it
    /// arrives as `EngineEvent::PairingCode`. With `None`, an existing
    /// session is resumed.
    pub fn start(&self, pairing_phone: Option<String>) -> Result<(), EngineError> {
        let phone = pairing_phone
            .map(|p| p.chars().filter(|c| c.is_ascii_digit()).collect::<String>());
        if let Some(p) = &phone {
            if p.len() < 8 || p.len() > 15 || p.starts_with('0') {
                return Err(EngineError::Invalid("Invalid phone number".into()));
            }
        }
        let mut guard = self
            .task
            .lock()
            .map_err(|e| EngineError::Internal(e.to_string()))?;
        if guard.as_ref().is_some_and(|h| !h.is_finished()) {
            return Ok(());
        }
        let db = self.data_dir.join("whatsapp.db");
        let listener = self.listener.clone();
        let slot = self.client.clone();
        *guard = Some(runtime().spawn(async move {
            if let Err(e) = run_bot(db, phone, listener.clone(), slot).await {
                listener.on_event(EngineEvent::Fatal { reason: e.to_string() });
            }
        }));
        Ok(())
    }

    /// Graceful disconnect, then abort the task if it has not ended on its own.
    pub fn stop(&self) {
        let client = self.client.lock().ok().and_then(|mut g| g.take());
        let task = self.task.lock().ok().and_then(|mut g| g.take());
        if client.is_none() && task.is_none() {
            return;
        }
        runtime().spawn(async move {
            if let Some(c) = client {
                let _ = c.disconnect().await;
            }
            tokio::time::sleep(Duration::from_millis(300)).await;
            if let Some(t) = task {
                t.abort();
            }
        });
    }

    pub fn is_running(&self) -> bool {
        self.task
            .lock()
            .map(|g| g.as_ref().is_some_and(|h| !h.is_finished()))
            .unwrap_or(false)
    }

    /// Send a text message to `chat_jid`. Blocks until the server accepts it (30 s timeout).
    /// Call from a background thread. Returns the message id.
    pub fn send_text(&self, chat_jid: String, text: String) -> Result<String, EngineError> {
        let jid: Jid = chat_jid
            .parse()
            .map_err(|e| EngineError::Invalid(format!("Invalid chat id: {e}")))?;
        let client = self
            .client
            .lock()
            .ok()
            .and_then(|g| g.clone())
            .ok_or_else(|| EngineError::Internal("Not connected".into()))?;
        runtime().block_on(async move {
            tokio::time::timeout(
                Duration::from_secs(30),
                client.send_message(&jid, wa::Message::text(text.as_str())),
            )
            .await
            .map_err(|_| EngineError::Internal("Send timed out".into()))?
            .map(|sent| sent.message_id)
            .map_err(|e| EngineError::Internal(e.to_string()))
        })
    }

    /// Upload a local file and send it as an image / video / document message.
    /// Blocks (up to ~10 min); call from a background thread. Returns the message id.
    pub fn send_media(&self, m: OutgoingMedia) -> Result<String, EngineError> {
        let OutgoingMedia { chat_id, kind, path, mimetype, file_name, caption, thumbnail, duration_secs } = m;
        let jid: Jid = chat_id
            .parse()
            .map_err(|e| EngineError::Invalid(format!("Invalid chat id: {e}")))?;
        let client = self.connected_client()?;
        let media_type = media_type_of(&kind)?;
        let len = std::fs::metadata(&path)
            .map_err(|e| EngineError::Invalid(format!("Cannot read file: {e}")))?
            .len();
        if len > MAX_UPLOAD_BYTES {
            return Err(EngineError::Invalid("File too large (limit 64 MB)".into()));
        }
        let data = std::fs::read(&path).map_err(|e| EngineError::Invalid(format!("Cannot read file: {e}")))?;
        runtime().block_on(async move {
            let upload = tokio::time::timeout(Duration::from_secs(600), client.upload(data, media_type))
                .await
                .map_err(|_| EngineError::Internal("Upload timed out".into()))?
                .map_err(|e| EngineError::Internal(e.to_string()))?;
            let caption = non_empty(caption);
            let mimetype = non_empty(mimetype);
            let thumb = if thumbnail.is_empty() { None } else { Some(thumbnail) };
            let msg = match kind.as_str() {
                "image" => media::image_message(
                    upload,
                    ImageOptions { caption, mimetype, jpeg_thumbnail: thumb, ..Default::default() },
                ),
                "video" => media::video_message(
                    upload,
                    VideoOptions {
                        caption,
                        mimetype,
                        jpeg_thumbnail: thumb,
                        duration_seconds: if duration_secs > 0 { Some(duration_secs) } else { None },
                        ..Default::default()
                    },
                ),
                _ => media::document_message(
                    upload,
                    DocumentOptions {
                        caption,
                        mimetype,
                        file_name: non_empty(file_name),
                        jpeg_thumbnail: thumb,
                        ..Default::default()
                    },
                ),
            };
            tokio::time::timeout(Duration::from_secs(60), client.send_message(&jid, msg))
                .await
                .map_err(|_| EngineError::Internal("Send timed out".into()))?
                .map(|sent| sent.message_id)
                .map_err(|e| EngineError::Internal(e.to_string()))
        })
    }

    /// Download + decrypt an incoming attachment to `dest_path` (streamed to disk, written
    /// to `<dest>.part` first). Blocks; call from a background thread.
    pub fn download_media(&self, media: MediaInfo, dest_path: String) -> Result<(), EngineError> {
        let client = self.connected_client()?;
        let media_type = media_type_of(&media.kind)?;
        let params = DownloadParams::encrypted(
            media.direct_path.clone(),
            &media.media_key,
            &media.file_sha256,
            &media.file_enc_sha256,
            media.file_length,
            media_type,
        );
        let tmp = format!("{dest_path}.part");
        let file = std::fs::OpenOptions::new()
            .create(true)
            .write(true)
            .truncate(true)
            .open(&tmp)
            .map_err(|e| EngineError::Internal(format!("Cannot write file: {e}")))?;
        let result = runtime().block_on(async {
            tokio::time::timeout(
                Duration::from_secs(900),
                client.download_from_params_to_writer(&params, file),
            )
            .await
        });
        match result {
            Ok(Ok(_)) => std::fs::rename(&tmp, &dest_path)
                .map_err(|e| EngineError::Internal(format!("Cannot save file: {e}"))),
            Ok(Err(e)) => {
                let _ = std::fs::remove_file(&tmp);
                Err(EngineError::Internal(e.to_string()))
            }
            Err(_) => {
                let _ = std::fs::remove_file(&tmp);
                Err(EngineError::Internal("Download timed out".into()))
            }
        }
    }

    /// Send a read receipt. `sender_jid` is the message author for groups, empty for 1:1 chats.
    pub fn mark_read(
        &self,
        chat_jid: String,
        sender_jid: String,
        message_ids: Vec<String>,
    ) -> Result<(), EngineError> {
        let chat: Jid = chat_jid
            .parse()
            .map_err(|e| EngineError::Invalid(format!("Invalid chat id: {e}")))?;
        let sender: Option<Jid> = if sender_jid.is_empty() {
            None
        } else {
            Some(
                sender_jid
                    .parse()
                    .map_err(|e| EngineError::Invalid(format!("Invalid sender id: {e}")))?,
            )
        };
        let client = self.connected_client()?;
        runtime().block_on(async move {
            tokio::time::timeout(
                Duration::from_secs(20),
                client.mark_as_read(&chat, sender.as_ref(), message_ids),
            )
            .await
            .map_err(|_| EngineError::Internal("Read receipt timed out".into()))?
            .map_err(|e| EngineError::Internal(e.to_string()))
        })
    }

    /// Stop and delete the local session database.
    pub fn clear_session(&self) -> Result<(), EngineError> {
        self.stop();
        for name in ["whatsapp.db", "whatsapp.db-wal", "whatsapp.db-shm", "whatsapp.db-journal"] {
            match std::fs::remove_file(self.data_dir.join(name)) {
                Ok(()) => {}
                Err(e) if e.kind() == std::io::ErrorKind::NotFound => {}
                Err(e) => return Err(EngineError::Internal(e.to_string())),
            }
        }
        Ok(())
    }
}

async fn run_bot(
    db: PathBuf,
    phone: Option<String>,
    listener: Arc<dyn EngineListener>,
    slot: ClientSlot,
) -> anyhow::Result<()> {
    // NOTE: pass the store by value; `Arc<SqliteStore>` does not implement `Backend` in 0.7.0.
    let store = SqliteStore::new(db.to_string_lossy().as_ref())
        .await
        .map_err(|e| anyhow::anyhow!("{e}"))?;

    let mut builder = Bot::builder()
        .with_backend(store)
        .with_transport_factory(TokioWebSocketTransportFactory::new())
        .with_http_client(UreqHttpClient::new())
        .with_runtime(TokioRuntime);

    if let Some(phone_number) = phone {
        builder = builder.with_pair_code(PairCodeOptions {
            phone_number,
            // User decision: register as an Electron companion (see docs/known-limitations.md).
            platform_id: Some(CompanionWebClientType::Electron),
            ..Default::default()
        });
    }

    let msg_listener = listener.clone();
    let bot = builder
        .on_message(move |ctx| {
            let l = msg_listener.clone();
            async move {
                let msg = &ctx.message;
                let text = msg.text_content().map(str::to_string);
                let media = extract_media(msg);
                if text.is_none() && media.is_none() {
                    return;
                }
                let info = &ctx.info;
                l.on_event(EngineEvent::MessageReceived {
                    chat_id: info.source.chat.to_string(),
                    sender_id: info.source.sender.to_string(),
                    message_id: info.id.clone(),
                    text: text.unwrap_or_default(),
                    timestamp_ms: info.timestamp.timestamp_millis(),
                    from_me: info.source.is_from_me,
                    is_group: info.source.is_group,
                    push_name: info.push_name.clone(),
                    media,
                });
            }
        })
        .on_event(move |event, _client| {
            let l = listener.clone();
            async move { forward(&l, &event) }
        })
        .build()
        .await
        .map_err(|e| anyhow::anyhow!("{e}"))?;

    if let Ok(mut g) = slot.lock() {
        *g = Some(bot.client());
    }
    // Runs until logout or `Client::disconnect`.
    bot.run().await;
    if let Ok(mut g) = slot.lock() {
        *g = None;
    }
    Ok(())
}

fn forward(l: &Arc<dyn EngineListener>, ev: &Event) {
    let out = match ev {
        Event::PairingCode(pc) => EngineEvent::PairingCode {
            code: pc.code.clone(),
            timeout_secs: pc.timeout.as_secs(),
        },
        Event::Receipt(r) => {
            let kind = match r.r#type {
                ReceiptType::Delivered => "delivered",
                ReceiptType::Read | ReceiptType::Played => "read",
                _ => return,
            };
            EngineEvent::ReceiptReceived {
                chat_id: r.source.chat.to_string(),
                message_ids: r.message_ids.clone(),
                kind: kind.into(),
            }
        }
        Event::PairSuccess(_) => EngineEvent::Paired,
        Event::PairError(e) => EngineEvent::PairFailed { reason: format!("{e:?}") },
        Event::Connected(_) => EngineEvent::Connected,
        Event::Disconnected(_) => EngineEvent::Disconnected,
        Event::LoggedOut(_) => EngineEvent::LoggedOut,
        Event::ConnectFailure(e) => EngineEvent::Fatal { reason: format!("{e:?}") },
        Event::TemporaryBan(e) => EngineEvent::Fatal { reason: format!("{e:?}") },
        _ => return,
    };
    l.on_event(out);
}

impl Engine {
    fn connected_client(&self) -> Result<Arc<Client>, EngineError> {
        self.client
            .lock()
            .ok()
            .and_then(|g| g.clone())
            .ok_or_else(|| EngineError::Internal("Not connected".into()))
    }
}

fn non_empty(s: String) -> Option<String> {
    if s.is_empty() { None } else { Some(s) }
}

fn media_type_of(kind: &str) -> Result<MediaType, EngineError> {
    match kind {
        "image" => Ok(MediaType::Image),
        "video" => Ok(MediaType::Video),
        "document" => Ok(MediaType::Document),
        other => Err(EngineError::Invalid(format!("Unsupported media kind: {other}"))),
    }
}

fn view_once_marker() -> MediaInfo {
    MediaInfo {
        kind: "viewonce".into(),
        mimetype: String::new(),
        file_name: String::new(),
        caption: String::new(),
        file_length: 0,
        direct_path: String::new(),
        media_key: Vec::new(),
        file_sha256: Vec::new(),
        file_enc_sha256: Vec::new(),
        thumbnail: Vec::new(),
    }
}

/// Image / video / document attachments. View-once media is reported as a distinct kind
/// with no keys: it is never downloaded (WhatsApp's access restriction is respected).
fn extract_media(msg: &wa::Message) -> Option<MediaInfo> {
    if msg.view_once_message.is_set() || msg.view_once_message_v2.is_set() {
        return Some(view_once_marker());
    }
    if msg.image_message.is_set() {
        let m = msg.image_message.clone().unwrap();
        if m.view_once.unwrap_or(false) {
            return Some(view_once_marker());
        }
        return Some(MediaInfo {
            kind: "image".into(),
            mimetype: m.mimetype.unwrap_or_default(),
            file_name: String::new(),
            caption: m.caption.unwrap_or_default(),
            file_length: m.file_length.unwrap_or(0),
            direct_path: m.direct_path.unwrap_or_default(),
            media_key: m.media_key.unwrap_or_default(),
            file_sha256: m.file_sha256.unwrap_or_default(),
            file_enc_sha256: m.file_enc_sha256.unwrap_or_default(),
            thumbnail: m.jpeg_thumbnail.unwrap_or_default(),
        });
    }
    if msg.video_message.is_set() {
        let m = msg.video_message.clone().unwrap();
        if m.view_once.unwrap_or(false) {
            return Some(view_once_marker());
        }
        return Some(MediaInfo {
            kind: "video".into(),
            mimetype: m.mimetype.unwrap_or_default(),
            file_name: String::new(),
            caption: m.caption.unwrap_or_default(),
            file_length: m.file_length.unwrap_or(0),
            direct_path: m.direct_path.unwrap_or_default(),
            media_key: m.media_key.unwrap_or_default(),
            file_sha256: m.file_sha256.unwrap_or_default(),
            file_enc_sha256: m.file_enc_sha256.unwrap_or_default(),
            thumbnail: m.jpeg_thumbnail.unwrap_or_default(),
        });
    }
    if msg.document_message.is_set() {
        let m = msg.document_message.clone().unwrap();
        return Some(MediaInfo {
            kind: "document".into(),
            mimetype: m.mimetype.unwrap_or_default(),
            file_name: m.file_name.or(m.title).unwrap_or_default(),
            caption: m.caption.unwrap_or_default(),
            file_length: m.file_length.unwrap_or(0),
            direct_path: m.direct_path.unwrap_or_default(),
            media_key: m.media_key.unwrap_or_default(),
            file_sha256: m.file_sha256.unwrap_or_default(),
            file_enc_sha256: m.file_enc_sha256.unwrap_or_default(),
            thumbnail: m.jpeg_thumbnail.unwrap_or_default(),
        });
    }
    None
}
