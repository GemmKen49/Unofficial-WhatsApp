package com.classic.whatsapp.ui.conversation

import android.content.ActivityNotFoundException
import android.content.Intent
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.unit.dp
import androidx.core.content.FileProvider
import com.classic.whatsapp.ClassicApp
import com.classic.whatsapp.Notifier
import com.classic.whatsapp.data.*
import com.classic.whatsapp.ui.chats.ChatActionsDialog
import com.classic.whatsapp.ui.formatTime
import java.io.File
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
fun ConversationScreen(chatId: String, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val app = ctx.applicationContext as ClassicApp
    val repo = app.repo
    val messages by repo.messages(chatId).collectAsState(initial = emptyList())
    val chat by repo.chat(chatId).collectAsState(initial = null as ChatEntity?)
    val foreground by repo.foreground.collectAsState()
    val downloading by repo.downloading.collectAsState()
    val error by repo.lastError.collectAsState()
    val share by app.pendingShare.collectAsState()
    val scope = rememberCoroutineScope()

    var draft by remember { mutableStateOf("") }
    var attach by remember { mutableStateOf<List<PendingFile>>(emptyList()) }
    var attachMenu by remember { mutableStateOf(false) }
    var showActions by remember { mutableStateOf(false) }

    // Take over files shared from another app once this chat was chosen as the target.
    LaunchedEffect(share, chatId) {
        val s = share
        if (s != null && s.target == chatId) {
            attach = s.files
            if (s.text.isNotBlank()) draft = s.text
            app.pendingShare.value = null
        }
    }

    // While this chat is visible: acknowledge incoming messages (read receipts) and clear unread.
    LaunchedEffect(chatId, foreground) {
        if (foreground) repo.openChat(chatId) else repo.closeChat()
    }
    LaunchedEffect(chatId, foreground, messages.size) {
        if (foreground) {
            repo.markConversationRead(chatId)
            Notifier.cancel(ctx, chatId)
        }
    }
    DisposableEffect(chatId) { onDispose { repo.closeChat() } }

    val pickMedia = rememberLauncherForActivityResult(ActivityResultContracts.PickMultipleVisualMedia(10)) { uris ->
        if (uris.isNotEmpty()) scope.launch {
            attach = withContext(Dispatchers.IO) { uris.mapNotNull { MediaFiles.importUri(ctx, it) } }
        }
    }
    val pickFiles = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        if (uris.isNotEmpty()) scope.launch {
            attach = withContext(Dispatchers.IO) { uris.mapNotNull { MediaFiles.importUri(ctx, it) } }
        }
    }

    fun onMedia(m: MessageEntity) {
        if (m.mediaPath.isNotBlank() && File(m.mediaPath).exists()) {
            openFile(ctx, m.mediaPath, m.mimeType)
        } else if (!m.fromMe && m.kind != "viewonce") {
            scope.launch { repo.downloadMedia(chatId, m.messageId) }
        }
    }

    Column(Modifier.fillMaxSize().statusBarsPadding().imePadding()) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back") }
            Text(
                chat?.displayTitle ?: chatId.substringBefore('@'),
                style = MaterialTheme.typography.titleMedium,
                modifier = Modifier.weight(1f),
            )
            IconButton(onClick = { showActions = true }) { Icon(Icons.Default.MoreVert, contentDescription = "Chat options") }
        }
        HorizontalDivider()

        LazyColumn(
            modifier = Modifier.weight(1f).fillMaxWidth(),
            reverseLayout = true,
            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp),
        ) {
            items(messages.asReversed(), key = { it.messageId }) { m ->
                Bubble(m, chat?.isGroup == true, downloading = m.messageId in downloading, onMedia = { onMedia(m) })
            }
        }

        error?.let {
            Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(horizontal = 12.dp))
        }

        Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.Bottom) {
            Box {
                IconButton(onClick = { attachMenu = true }) { Icon(Icons.Default.Add, contentDescription = "Attach") }
                DropdownMenu(expanded = attachMenu, onDismissRequest = { attachMenu = false }) {
                    DropdownMenuItem(text = { Text("Photo or video") }, onClick = {
                        attachMenu = false
                        pickMedia.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageAndVideo))
                    })
                    DropdownMenuItem(text = { Text("File") }, onClick = {
                        attachMenu = false
                        pickFiles.launch(arrayOf("*/*"))
                    })
                }
            }
            OutlinedTextField(
                value = draft,
                onValueChange = { draft = it },
                placeholder = { Text("Message") },
                maxLines = 5,
                modifier = Modifier.weight(1f),
            )
            IconButton(
                enabled = draft.isNotBlank(),
                onClick = {
                    val text = draft.trim()
                    draft = ""
                    scope.launch { repo.sendText(chatId, text) }
                },
            ) { Icon(Icons.AutoMirrored.Filled.Send, contentDescription = "Send") }
        }
    }

    if (attach.isNotEmpty()) {
        var caption by remember(attach) { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { attach.forEach { File(it.path).delete() }; attach = emptyList() },
            title = { Text("Send ${attach.size} file(s)?") },
            text = {
                Column {
                    attach.take(5).forEach {
                        Text("${it.name}  ${MediaFiles.formatSize(it.size)}", style = MaterialTheme.typography.bodySmall)
                    }
                    if (attach.size > 5) Text("+ ${attach.size - 5} more", style = MaterialTheme.typography.bodySmall)
                    OutlinedTextField(
                        value = caption,
                        onValueChange = { caption = it },
                        label = { Text("Caption (optional)") },
                        modifier = Modifier.padding(top = 12.dp),
                    )
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    val files = attach
                    attach = emptyList()
                    scope.launch {
                        files.forEachIndexed { i, f -> repo.sendMedia(chatId, f, if (i == 0) caption.trim() else "") }
                    }
                }) { Text("Send") }
            },
            dismissButton = {
                TextButton(onClick = { attach.forEach { File(it.path).delete() }; attach = emptyList() }) { Text("Cancel") }
            },
        )
    }

    chat?.let { if (showActions) ChatActionsDialog(it, onDismiss = { showActions = false }, onGone = onBack) }
}

private fun openFile(ctx: android.content.Context, path: String, mime: String) {
    try {
        val uri = FileProvider.getUriForFile(ctx, "${ctx.packageName}.files", File(path))
        val i = Intent(Intent.ACTION_VIEW)
            .setDataAndType(uri, mime.ifBlank { "*/*" })
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        ctx.startActivity(i)
    } catch (e: ActivityNotFoundException) {
        Toast.makeText(ctx, "No app can open this file", Toast.LENGTH_SHORT).show()
    } catch (e: Exception) {
        Toast.makeText(ctx, "Cannot open file", Toast.LENGTH_SHORT).show()
    }
}

@Composable
private fun rememberBitmap(path: String, maxSide: Int): ImageBitmap? {
    val state = produceState<ImageBitmap?>(null, path) {
        value = if (path.isBlank()) null
        else withContext(Dispatchers.IO) { MediaFiles.decodeSampled(path, maxSide)?.asImageBitmap() }
    }
    return state.value
}

@Composable
private fun Bubble(m: MessageEntity, isGroup: Boolean, downloading: Boolean, onMedia: () -> Unit) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = if (m.fromMe) Arrangement.End else Arrangement.Start) {
        Surface(
            shape = RoundedCornerShape(6.dp),
            color = if (m.fromMe) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant,
            modifier = Modifier.widthIn(max = 300.dp),
        ) {
            Column(Modifier.padding(horizontal = 10.dp, vertical = 6.dp)) {
                if (isGroup && !m.fromMe && m.senderName.isNotBlank()) {
                    Text(m.senderName, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
                }
                when (m.kind) {
                    "image", "video" -> MediaPreview(m, downloading, onMedia)
                    "document" -> Column(Modifier.clickable(onClick = onMedia).padding(vertical = 4.dp)) {
                        Text(m.fileName.ifBlank { "File" }, style = MaterialTheme.typography.bodyMedium)
                        Text(
                            when {
                                downloading -> "Downloading…"
                                m.mediaPath.isNotBlank() -> "Tap to open · ${MediaFiles.formatSize(m.fileLength)}"
                                m.fromMe -> MediaFiles.formatSize(m.fileLength)
                                else -> "Tap to download · ${MediaFiles.formatSize(m.fileLength)}"
                            },
                            style = MaterialTheme.typography.labelSmall,
                        )
                    }
                    "viewonce" -> Text(
                        "View-once message. Open it on your phone.",
                        style = MaterialTheme.typography.bodyMedium,
                        fontStyle = FontStyle.Italic,
                    )
                }
                if (m.text.isNotBlank()) Text(m.text, style = MaterialTheme.typography.bodyMedium)

                val meta = when (m.status) {
                    STATUS_SENDING -> "sending…"
                    STATUS_FAILED -> "failed to send"
                    STATUS_DELIVERED -> formatTime(m.timestamp) + " ✓✓"
                    STATUS_READ -> formatTime(m.timestamp) + " ✓✓"
                    else -> formatTime(m.timestamp) + if (m.fromMe) " ✓" else ""
                }
                Text(
                    meta,
                    style = MaterialTheme.typography.labelSmall,
                    color = when (m.status) {
                        STATUS_FAILED -> MaterialTheme.colorScheme.error
                        STATUS_READ -> MaterialTheme.colorScheme.primary
                        else -> MaterialTheme.colorScheme.onSurfaceVariant
                    },
                    modifier = Modifier.align(Alignment.End),
                )
            }
        }
    }
}

@Composable
private fun MediaPreview(m: MessageEntity, downloading: Boolean, onClick: () -> Unit) {
    val path = if (m.kind == "image" && m.mediaPath.isNotBlank()) m.mediaPath else m.thumbPath
    val bmp = rememberBitmap(path, 800)
    Box(
        Modifier.width(220.dp).height(160.dp).background(MaterialTheme.colorScheme.surface).clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        if (bmp != null) {
            Image(bmp, contentDescription = null, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
        }
        val label = when {
            downloading -> null
            m.mediaPath.isNotBlank() && m.kind == "video" -> "▶ Play"
            m.mediaPath.isBlank() && !m.fromMe -> "Tap to download ${MediaFiles.formatSize(m.fileLength)}".trim()
            else -> null
        }
        if (downloading) CircularProgressIndicator()
        else if (label != null) {
            Surface(color = MaterialTheme.colorScheme.scrim.copy(alpha = 0.55f), shape = RoundedCornerShape(4.dp)) {
                Text(label, color = MaterialTheme.colorScheme.surface, modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp), style = MaterialTheme.typography.labelMedium)
            }
        }
    }
}
