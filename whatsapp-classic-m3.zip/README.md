# WhatsApp Classic (Milestone 3: media, receipts, contacts)

Minimal native Android WhatsApp companion client: Kotlin + Compose UI, Rust engine
(`whatsapp-rust` 0.7.0, pinned) bridged with UniFFI. No Google services, no FCM.

## Build (no local toolchain needed)

1. Create an empty GitHub repo, upload the contents of this zip (or `git push`).
2. Open the **Actions** tab, run **build-apk** (it also runs on every push to `main`).
3. Download the `whatsapp-classic-apk` artifact, unzip, install `app-debug.apk`
   (`adb install app-debug.apk`, or open the file on the phone in the user profile you want it in).
4. If the build fails, paste the failing step's log here.
5. After the first green build, download the `Cargo.lock` artifact and commit it to `rust/`
   so the Rust dependency tree is pinned.

Status: pairing verified on a real account (M1). Milestone 2 (service, notifications, chats, text) is unverified until built.
See `docs/known-limitations.md`.
