package com.classic.whatsapp.ui.chats

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.platform.LocalContext
import com.classic.whatsapp.ClassicApp
import com.classic.whatsapp.data.ChatEntity
import kotlinx.coroutines.launch

/** Local-only contact editing: rename, hide, delete. [onGone] runs after hide/delete. */
@Composable
fun ChatActionsDialog(chat: ChatEntity, onDismiss: () -> Unit, onGone: () -> Unit = {}) {
    val app = LocalContext.current.applicationContext as ClassicApp
    // The dialog leaves the screen right after a choice, which would cancel a coroutine of its own scope.
    val scope = app.appScope
    var mode by remember { mutableStateOf("menu") }
    var name by remember { mutableStateOf(chat.customName.ifBlank { chat.title }) }

    when (mode) {
        "rename" -> AlertDialog(
            onDismissRequest = onDismiss,
            title = { Text("Rename") },
            text = {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    singleLine = true,
                    label = { Text("Name (empty = original)") },
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    scope.launch { app.repo.rename(chat.chatId, name) }
                    onDismiss()
                }) { Text("Save") }
            },
            dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
        )
        "mute" -> AlertDialog(
            onDismissRequest = onDismiss,
            title = { Text("Mute notifications") },
            text = {
                Column {
                    val hour = 60L * 60 * 1000
                    listOf("8 hours" to 8 * hour, "1 week" to 7 * 24 * hour, "Always" to Long.MAX_VALUE).forEach { (label, span) ->
                        TextButton(onClick = {
                            val until = if (span == Long.MAX_VALUE) span else System.currentTimeMillis() + span
                            scope.launch { app.repo.setMuted(chat.chatId, until) }
                            onDismiss()
                        }) { Text(label) }
                    }
                    Text(
                        "Only on this device; it is not synced with your phone.",
                        style = MaterialTheme.typography.bodySmall,
                        modifier = Modifier.padding(top = 8.dp),
                    )
                }
            },
            confirmButton = {},
            dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
        )
        "delete" -> AlertDialog(
            onDismissRequest = onDismiss,
            title = { Text("Delete chat?") },
            text = { Text("Deletes the messages and downloaded media on this device only.") },
            confirmButton = {
                TextButton(onClick = {
                    scope.launch { app.repo.delete(chat.chatId) }
                    onDismiss()
                    onGone()
                }) { Text("Delete") }
            },
            dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
        )
        else -> AlertDialog(
            onDismissRequest = onDismiss,
            title = { Text(chat.displayTitle) },
            text = {
                Column {
                    if (chat.mutedUntil > System.currentTimeMillis()) {
                        TextButton(onClick = {
                            scope.launch { app.repo.setMuted(chat.chatId, 0L) }
                            onDismiss()
                        }) { Text("Unmute notifications") }
                    } else {
                        TextButton(onClick = { mode = "mute" }) { Text("Mute notifications") }
                    }
                    TextButton(onClick = { mode = "rename" }) { Text("Rename") }
                    if (chat.hidden) {
                        TextButton(onClick = {
                            scope.launch { app.repo.unhide(chat.chatId) }
                            onDismiss()
                        }) { Text("Unhide chat") }
                    } else {
                        TextButton(onClick = {
                            scope.launch { app.repo.hide(chat.chatId) }
                            onDismiss()
                            onGone()
                        }) { Text("Hide chat (returns on a new message)") }
                    }
                    TextButton(onClick = { mode = "delete" }) { Text("Delete chat") }
                }
            },
            confirmButton = {},
            dismissButton = { TextButton(onClick = onDismiss) { Text("Close") } },
        )
    }
}
