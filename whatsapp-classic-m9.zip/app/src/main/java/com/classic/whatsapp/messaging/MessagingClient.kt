package com.classic.whatsapp.messaging

import kotlinx.coroutines.flow.SharedFlow

class PairingException(message: String) : Exception(message)

/** A channel (newsletter) the account follows. */
data class Channel(
    val id: String,
    val name: String,
    val description: String,
    val subscribers: Long,
    val verified: Boolean,
    val pictureUrl: String = "",
)

data class GroupMemberInfo(val jid: String, val phone: String, val username: String, val isAdmin: Boolean, val isSuperAdmin: Boolean)

data class GroupDetailsInfo(
    val id: String,
    val subject: String,
    val description: String,
    val creationSecs: Long,
    val announce: Boolean,
    val locked: Boolean,
    val members: List<GroupMemberInfo>,
)

/** Where a profile picture can be downloaded; [id] changes when the picture changes. */
data class ProfilePictureRef(val id: String, val url: String)

/** A community the account belongs to (the parent group, not a chat). */
data class Community(val id: String, val name: String)

/** A group linked to a community. [members] is 0 when unknown. */
data class CommunityGroup(val id: String, val name: String, val announcement: Boolean, val general: Boolean, val members: Int)

/** App-level messaging surface. Media/groups are added in later milestones. */
interface MessagingClient {
    val events: SharedFlow<MessagingEvent>
    val isRunning: Boolean

    /** Resume an existing linked-device session. */
    fun start()
    fun stop()

    /** Starts a fresh pairing attempt; returns when the code arrives. */
    suspend fun requestPairingCode(phoneNumber: String): MessagingEvent.PairingCode

    /** Sends a text message; returns the server-side message id. */
    suspend fun sendText(
        chatId: String,
        text: String,
        replyToId: String = "",
        replyToSender: String = "",
        replyToText: String = "",
        replyToChat: String = "",
        forwarded: Boolean = false,
    ): String

    /** Deletes one of our own messages for everyone. */
    suspend fun revokeMessage(chatId: String, messageId: String)

    /** Current name of a group chat. */
    suspend fun groupSubject(chatId: String): String

    suspend fun editMessage(chatId: String, messageId: String, newText: String)

    /** Empty [emoji] removes our reaction. [targetSender] is the author of the target message in groups. */
    suspend fun sendReaction(chatId: String, messageId: String, targetSender: String, targetFromMe: Boolean, emoji: String)

    /** [state]: "composing", "recording" or "paused". */
    suspend fun sendTyping(chatId: String, state: String)

    suspend fun sendTextWithPreview(chatId: String, text: String, url: String, title: String, description: String): String

    suspend fun groupDetails(groupId: String): GroupDetailsInfo
    suspend fun groupSetSubject(groupId: String, subject: String)
    suspend fun groupSetDescription(groupId: String, description: String)

    /** [action]: add, remove, promote or demote. Returns the ids the server refused. */
    suspend fun groupChangeMembers(groupId: String, action: String, members: List<String>): List<String>
    suspend fun groupLeave(groupId: String)
    suspend fun groupInviteLink(groupId: String, reset: Boolean): String
    suspend fun groupSetRestrictions(groupId: String, announce: Boolean, locked: Boolean)

    /** Own phone-number id as reported by the engine (may carry a device suffix). */
    suspend fun ownJid(): String

    /** CDN reference of a profile picture, or null when none / hidden. */
    suspend fun profilePicture(jid: String, preview: Boolean): ProfilePictureRef?

    /** About text of a user, or null when hidden / not set. */
    suspend fun userAbout(jid: String): String?

    suspend fun setDisplayName(name: String)

    suspend fun setAbout(text: String)

    /** JPEG bytes (square) to set, or null to remove the profile picture. */
    suspend fun setProfilePicture(jpeg: ByteArray?)

    /** Channels this account follows. */
    suspend fun channels(): List<Channel>

    /** Communities this account participates in. */
    suspend fun communities(): List<Community>

    /** Groups linked to a community (announcement group first). */
    suspend fun communityGroups(communityId: String): List<CommunityGroup>

    /** Uploads a local file and sends it (kind: image | video | document); returns the message id. */
    suspend fun sendMedia(
        chatId: String,
        kind: String,
        path: String,
        mimeType: String,
        fileName: String,
        caption: String,
        thumbnail: ByteArray,
        durationSecs: Int,
        voice: Boolean = false,
        forwarded: Boolean = false,
        waveform: ByteArray = ByteArray(0),
    ): String

    /** Downloads and decrypts an attachment to [destPath]. */
    suspend fun downloadMedia(media: MediaDescriptor, destPath: String)

    /** Sends a read receipt. [senderId] is the author for groups, empty for 1:1 chats. */
    suspend fun markRead(chatId: String, senderId: String, messageIds: List<String>)

    /** Stops the engine and deletes the local session database. */
    suspend fun clearSession()
}
