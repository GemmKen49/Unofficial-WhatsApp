package com.classic.whatsapp.messaging

import java.io.File
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.CoroutineStart
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeout
import uniffi.whatsapp_classic_engine.Engine
import uniffi.whatsapp_classic_engine.EngineEvent
import uniffi.whatsapp_classic_engine.EngineListener
import uniffi.whatsapp_classic_engine.MediaInfo
import uniffi.whatsapp_classic_engine.OutgoingMedia

/** Adapter between the UniFFI-generated Rust engine and the app's stable API. */
class RustMessagingClient(private val dataDir: File) : MessagingClient {

    private val _events = MutableSharedFlow<MessagingEvent>(extraBufferCapacity = 20000)
    override val events: SharedFlow<MessagingEvent> = _events.asSharedFlow()

    private val listener = object : EngineListener {
        override fun onEvent(event: EngineEvent) {
            _events.tryEmit(event.toDomain())
        }
    }

    private val engine: Engine by lazy {
        dataDir.mkdirs()
        Engine(dataDir.absolutePath, listener)
    }

    override val isRunning: Boolean get() = engine.isRunning()

    override fun start() = engine.start(null)

    override fun stop() = engine.stop()

    override suspend fun requestPairingCode(phoneNumber: String): MessagingEvent.PairingCode =
        withContext(Dispatchers.IO) {
            coroutineScope {
                val result = CompletableDeferred<MessagingEvent.PairingCode>()
                // UNDISPATCHED: subscribe before the engine can emit anything.
                val collector = launch(start = CoroutineStart.UNDISPATCHED) {
                    events.collect { e ->
                        when (e) {
                            is MessagingEvent.PairingCode -> result.complete(e)
                            is MessagingEvent.PairFailed -> result.completeExceptionally(PairingException(e.reason))
                            is MessagingEvent.Fatal -> result.completeExceptionally(PairingException(e.reason))
                            else -> Unit
                        }
                    }
                }
                try {
                    engine.stop()
                    engine.start(phoneNumber)
                    withTimeout(90_000) { result.await() }
                } finally {
                    collector.cancel()
                }
            }
        }

    override suspend fun sendText(
        chatId: String,
        text: String,
        replyToId: String,
        replyToSender: String,
        replyToText: String,
        replyToChat: String,
        forwarded: Boolean,
    ): String = withContext(Dispatchers.IO) {
        if (forwarded) engine.forwardText(chatId, text)
        else if (replyToId.isBlank()) engine.sendText(chatId, text)
        else engine.sendReply(chatId, text, replyToId, replyToSender, replyToText, replyToChat)
    }

    override suspend fun revokeMessage(chatId: String, messageId: String) =
        withContext(Dispatchers.IO) { engine.revokeMessage(chatId, messageId) }

    override suspend fun groupSubject(chatId: String): String =
        withContext(Dispatchers.IO) { engine.groupSubject(chatId) }

    override suspend fun editMessage(chatId: String, messageId: String, newText: String) =
        withContext(Dispatchers.IO) { engine.editMessage(chatId, messageId, newText) }

    override suspend fun sendReaction(chatId: String, messageId: String, targetSender: String, targetFromMe: Boolean, emoji: String) =
        withContext(Dispatchers.IO) { engine.sendReaction(chatId, messageId, targetSender, targetFromMe, emoji) }

    override suspend fun sendTyping(chatId: String, state: String) =
        withContext(Dispatchers.IO) { engine.sendTyping(chatId, state) }

    override suspend fun sendTextWithPreview(chatId: String, text: String, url: String, title: String, description: String): String =
        withContext(Dispatchers.IO) { engine.sendTextWithPreview(chatId, text, url, title, description) }

    override suspend fun groupDetails(groupId: String): GroupDetailsInfo =
        withContext(Dispatchers.IO) {
            val d = engine.groupDetails(groupId)
            GroupDetailsInfo(
                d.id, d.subject, d.description, d.creationSecs, d.announce, d.locked,
                d.members.map { GroupMemberInfo(it.jid, it.phone, it.username, it.isAdmin, it.isSuperAdmin) },
            )
        }

    override suspend fun groupSetSubject(groupId: String, subject: String) =
        withContext(Dispatchers.IO) { engine.groupSetSubject(groupId, subject) }

    override suspend fun groupSetDescription(groupId: String, description: String) =
        withContext(Dispatchers.IO) { engine.groupSetDescription(groupId, description) }

    override suspend fun groupChangeMembers(groupId: String, action: String, members: List<String>): List<String> =
        withContext(Dispatchers.IO) { engine.groupChangeMembers(groupId, action, members) }

    override suspend fun groupLeave(groupId: String) = withContext(Dispatchers.IO) { engine.groupLeave(groupId) }

    override suspend fun groupInviteLink(groupId: String, reset: Boolean): String =
        withContext(Dispatchers.IO) { engine.groupInviteLink(groupId, reset) }

    override suspend fun groupSetRestrictions(groupId: String, announce: Boolean, locked: Boolean) =
        withContext(Dispatchers.IO) { engine.groupSetRestrictions(groupId, announce, locked) }

    override suspend fun ownJid(): String = withContext(Dispatchers.IO) { engine.ownJid() }

    override suspend fun profilePicture(jid: String, preview: Boolean): ProfilePictureRef? =
        withContext(Dispatchers.IO) { engine.profilePicture(jid, preview)?.let { ProfilePictureRef(it.id, it.url) } }

    override suspend fun userAbout(jid: String): String? = withContext(Dispatchers.IO) { engine.userAbout(jid) }

    override suspend fun setDisplayName(name: String) = withContext(Dispatchers.IO) { engine.setDisplayName(name) }

    override suspend fun setAbout(text: String) = withContext(Dispatchers.IO) { engine.setAbout(text) }

    override suspend fun setProfilePicture(jpeg: ByteArray?) = withContext(Dispatchers.IO) {
        if (jpeg == null) engine.removeProfilePicture() else engine.setProfilePicture(jpeg)
    }

    override suspend fun channels(): List<Channel> =
        withContext(Dispatchers.IO) {
            engine.listChannels().map { Channel(it.jid, it.name, it.description, it.subscribers.toLong(), it.verified, it.pictureUrl) }
        }

    override suspend fun communities(): List<Community> =
        withContext(Dispatchers.IO) { engine.listCommunities().map { Community(it.jid, it.name) } }

    override suspend fun communityGroups(communityId: String): List<CommunityGroup> =
        withContext(Dispatchers.IO) {
            engine.communityGroups(communityId).map {
                CommunityGroup(it.jid, it.name, it.announcement, it.general, it.members.toInt())
            }
        }

    override suspend fun sendMedia(
        chatId: String,
        kind: String,
        path: String,
        mimeType: String,
        fileName: String,
        caption: String,
        thumbnail: ByteArray,
        durationSecs: Int,
        voice: Boolean,
        forwarded: Boolean,
        waveform: ByteArray,
    ): String = withContext(Dispatchers.IO) {
        engine.sendMedia(
            OutgoingMedia(
                chatId = chatId,
                kind = kind,
                path = path,
                mimetype = mimeType,
                fileName = fileName,
                caption = caption,
                thumbnail = thumbnail,
                durationSecs = durationSecs.coerceAtLeast(0).toUInt(),
                voice = voice,
                forwarded = forwarded,
                waveform = waveform,
            ),
        )
    }

    override suspend fun downloadMedia(media: MediaDescriptor, destPath: String) =
        withContext(Dispatchers.IO) { engine.downloadMedia(media.toEngine(), destPath) }

    override suspend fun markRead(chatId: String, senderId: String, messageIds: List<String>) =
        withContext(Dispatchers.IO) { engine.markRead(chatId, senderId, messageIds) }

    override suspend fun clearSession() = withContext(Dispatchers.IO) {
        engine.stop()
        delay(500) // let the aborted task release the database
        engine.clearSession()
    }
}

private fun EngineEvent.toDomain(): MessagingEvent = when (this) {
    is EngineEvent.PairingCode -> MessagingEvent.PairingCode(code, timeoutSecs.toLong())
    is EngineEvent.PairingQr -> MessagingEvent.PairingQr(code)
    is EngineEvent.Paired -> MessagingEvent.Paired
    is EngineEvent.PairFailed -> MessagingEvent.PairFailed(reason)
    is EngineEvent.Connected -> MessagingEvent.Connected
    is EngineEvent.Disconnected -> MessagingEvent.Disconnected
    is EngineEvent.LoggedOut -> MessagingEvent.LoggedOut
    is EngineEvent.Fatal -> MessagingEvent.Fatal(reason)
    is EngineEvent.ReceiptReceived -> MessagingEvent.ReceiptReceived(messageIds, kind)
    is EngineEvent.MessageRevoked -> MessagingEvent.MessageRevoked(chatId, messageId)
    is EngineEvent.MessageEdited -> MessagingEvent.MessageEdited(chatId, messageId, newText)
    is EngineEvent.ReactionReceived -> MessagingEvent.ReactionReceived(chatId, messageId, senderId, emoji, fromMe)
    is EngineEvent.LinkPreview -> MessagingEvent.LinkPreview(chatId, messageId, url, title, description)
    is EngineEvent.Typing -> MessagingEvent.Typing(chatId, senderId, state)
    is EngineEvent.MessageReceived -> MessagingEvent.MessageReceived(
        chatId = chatId,
        senderId = senderId,
        messageId = messageId,
        text = text,
        timestampMs = timestampMs,
        fromMe = fromMe,
        isGroup = isGroup,
        pushName = pushName,
        media = media?.toDomain(),
        replyToId = replyToId,
        replyToSender = replyToSender,
        replyToText = replyToText,
        historical = historical,
    )
    is EngineEvent.ChatInfo -> MessagingEvent.ChatInfo(chatId, name)
    is EngineEvent.ContactNames -> MessagingEvent.ContactNames(names.map { it.jid to it.name })
}

private fun MediaInfo.toDomain() = MediaDescriptor(
    kind = kind,
    mimeType = mimetype,
    fileName = fileName,
    caption = caption,
    fileLength = fileLength.toLong(),
    directPath = directPath,
    mediaKey = mediaKey,
    fileSha256 = fileSha256,
    fileEncSha256 = fileEncSha256,
    thumbnail = thumbnail,
    durationSecs = durationSecs.toInt(),
    voice = voice,
)

private fun MediaDescriptor.toEngine() = MediaInfo(
    kind = kind,
    mimetype = mimeType,
    fileName = fileName,
    caption = caption,
    fileLength = fileLength.toULong(),
    directPath = directPath,
    mediaKey = mediaKey,
    fileSha256 = fileSha256,
    fileEncSha256 = fileEncSha256,
    thumbnail = ByteArray(0),
    durationSecs = durationSecs.toUInt(),
    voice = voice,
)
