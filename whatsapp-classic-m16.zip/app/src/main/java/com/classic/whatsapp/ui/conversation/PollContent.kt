package com.classic.whatsapp.ui.conversation

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Checkbox
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.classic.whatsapp.data.MessageEntity

/** A poll inside a message bubble: question, answer limit, options with their vote counts. Tapping an option votes. */
@Composable
internal fun PollContent(m: MessageEntity, onVote: (List<String>) -> Unit) {
    val options = m.pollOptions.split('\n').filter { it.isNotEmpty() }
    val mine = m.pollMine.split('\n').filter { it.isNotEmpty() }
    val others = m.pollResults.split('\n').map { it.toIntOrNull() ?: 0 }
    val counts = options.mapIndexed { i, o -> others.getOrElse(i) { 0 } + if (o in mine) 1 else 0 }
    val max = (counts.maxOrNull() ?: 0).coerceAtLeast(1)
    val single = m.pollSelectable <= 1

    Column(Modifier.padding(vertical = 2.dp)) {
        Text(m.text, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold)
        Text(
            if (options.isEmpty()) "Poll (options not available)" else if (single) "Select one" else "Select up to ${m.pollSelectable}",
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        options.forEachIndexed { i, option ->
            val chosen = option in mine
            val canVote = m.pollSecret.isNotBlank()
            Row(
                Modifier.fillMaxWidth().padding(top = 6.dp)
                    .clickable(enabled = canVote) {
                        val next = when {
                            single -> if (chosen) emptyList() else listOf(option)
                            chosen -> mine - option
                            mine.size < m.pollSelectable -> mine + option
                            else -> mine
                        }
                        if (next != mine) onVote(next)
                    },
                verticalAlignment = Alignment.CenterVertically,
            ) {
                if (single) RadioButton(selected = chosen, onClick = null) else Checkbox(checked = chosen, onCheckedChange = null)
                Column(Modifier.weight(1f).padding(start = 6.dp)) {
                    Text(option, style = MaterialTheme.typography.bodyMedium)
                    Box(Modifier.fillMaxWidth().padding(top = 2.dp).height(4.dp).background(MaterialTheme.colorScheme.outlineVariant)) {
                        Box(Modifier.fillMaxHeight().fillMaxWidth(counts[i].toFloat() / max).background(MaterialTheme.colorScheme.primary))
                    }
                }
                Text(counts[i].toString(), style = MaterialTheme.typography.labelMedium, modifier = Modifier.padding(start = 8.dp))
            }
        }
    }
}
