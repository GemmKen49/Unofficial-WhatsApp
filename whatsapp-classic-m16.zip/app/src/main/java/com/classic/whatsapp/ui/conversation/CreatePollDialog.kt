package com.classic.whatsapp.ui.conversation

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

private const val MAX_OPTIONS = 12

/** Creates a poll: a question, 2 to 12 different options and whether several answers may be picked. */
@Composable
internal fun CreatePollDialog(onDismiss: () -> Unit, onCreate: (String, List<String>, Int) -> Unit) {
    var question by remember { mutableStateOf("") }
    val options = remember { mutableStateListOf("", "") }
    var multiple by remember { mutableStateOf(false) }

    val cleaned = options.map { it.trim() }.filter { it.isNotEmpty() }
    val valid = question.isNotBlank() && cleaned.size >= 2 && cleaned.distinct().size == cleaned.size

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("New poll") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = question,
                    onValueChange = { question = it.take(255) },
                    label = { Text("Question") },
                    modifier = Modifier.fillMaxWidth(),
                )
                options.forEachIndexed { i, value ->
                    OutlinedTextField(
                        value = value,
                        onValueChange = { options[i] = it.take(100) },
                        label = { Text("Option ${i + 1}") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth(),
                    )
                }
                if (options.size < MAX_OPTIONS) TextButton(onClick = { options.add("") }) { Text("Add option") }
                if (cleaned.size != cleaned.distinct().size) {
                    Text("Options must be different.", color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Allow multiple answers", modifier = Modifier.weight(1f))
                    Switch(checked = multiple, onCheckedChange = { multiple = it })
                }
            }
        },
        confirmButton = {
            TextButton(enabled = valid, onClick = { onCreate(question.trim(), cleaned, if (multiple) cleaned.size else 1) }) { Text("Send") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
    )
}
