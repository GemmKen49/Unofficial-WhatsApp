package com.classic.whatsapp.data

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

const val STATUS_SENDING = 0
const val STATUS_SENT = 1
const val STATUS_FAILED = 2
const val STATUS_DELIVERED = 3
const val STATUS_READ = 4

@Entity(tableName = "chats")
data class ChatEntity(
    @PrimaryKey val chatId: String,
    val title: String,
    val isGroup: Boolean,
    val lastText: String,
    val lastTimestamp: Long,
    val unread: Int,
    /** User-chosen local name; empty = use [title]. */
    val customName: String = "",
    val hidden: Boolean = false,
    /** Local mute: notifications are suppressed until this time (epoch ms); Long.MAX_VALUE = always. */
    val mutedUntil: Long = 0,
) {
    val displayTitle: String get() = customName.ifBlank { title }
}

@Entity(
    tableName = "messages",
    primaryKeys = ["chatId", "messageId"],
    indices = [Index("chatId", "timestamp")],
)
data class MessageEntity(
    val chatId: String,
    val messageId: String,
    val senderId: String,
    val senderName: String,
    /** Message text, or the caption for media. */
    val text: String,
    val timestamp: Long,
    val fromMe: Boolean,
    val status: Int,
    /** text | image | video | document | viewonce | deleted | audio */
    val kind: String = "text",
    val mediaPath: String = "",
    val thumbPath: String = "",
    val mimeType: String = "",
    val fileName: String = "",
    val fileLength: Long = 0,
    /** JSON from MediaDescriptor, used to download later. */
    val mediaRef: String = "",
    /** Incoming only: false until a read receipt was handled for it. */
    val incomingRead: Boolean = true,
    /** Quote: id/author/text of the message this one replies to (empty = not a reply). */
    val replyToId: String = "",
    val replyToSender: String = "",
    val replyToText: String = "",
    /** Chat the quoted message lives in when it differs (status@broadcast for status replies). */
    val replyToChat: String = "",
    val durationSecs: Int = 0,
    /** Audio only: true = voice note. */
    val voice: Boolean = false,
    /** Sent with the "Forwarded" label. */
    val forwarded: Boolean = false,
    /** Text was edited after sending. */
    val edited: Boolean = false,
    /** Link preview (empty url = none). */
    val linkUrl: String = "",
    val linkTitle: String = "",
    val linkDesc: String = "",
    /** One "senderId<TAB>emoji" per line; "me" is our own reaction. */
    val reactions: String = "",
    /** Time (epoch ms) of the first delivered / read receipt for our own messages; 0 = none yet. */
    val deliveredAt: Long = 0,
    val readAt: Long = 0,
    /** Forwarded channel post: "jid\u0001name\u0001serverId" (empty = not from a channel). */
    val forwardOrigin: String = "",
    /** Channel posts: the server's own id of the post (0 = unknown). */
    val serverId: Long = 0,
    /** Polls: option names (one per line), how many answers one person may pick, secret (hex) to decrypt votes. */
    val pollOptions: String = "",
    val pollSelectable: Int = 0,
    val pollSecret: String = "",
    /** Options chosen by us on this device (one per line). */
    val pollMine: String = "",
    /** Votes per option from everybody else, one number per line (same order as the options). */
    val pollResults: String = "",
)

/** One encrypted vote on a poll; only the latest of each voter is kept. */
@Entity(tableName = "poll_votes", primaryKeys = ["chatId", "pollId", "voterId"])
class PollVoteEntity(
    val chatId: String,
    val pollId: String,
    val voterId: String,
    val payload: ByteArray,
    val iv: ByteArray,
    val timestamp: Long,
)

/** The user's own address book: a name for a phone number, kept only in this app. */
@Entity(tableName = "saved_contacts")
data class SavedContactEntity(
    @PrimaryKey val jid: String,
    val name: String,
) {
    val number: String get() = jid.substringBefore('@')
}

/** Names learned from history sync (contact push names, chat names). */
@Entity(tableName = "contacts")
data class ContactEntity(
    @PrimaryKey val jid: String,
    val name: String,
)
