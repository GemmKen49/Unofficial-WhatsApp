package com.classic.whatsapp.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface ChatDao {
    @Query("SELECT * FROM chats WHERE hidden = 0 AND chatId != 'status@broadcast' AND chatId NOT LIKE '%@newsletter' ORDER BY lastTimestamp DESC")
    fun observeChats(): Flow<List<ChatEntity>>

    /** Channels (newsletters): listed in the Communities tab instead of Chats. */
    @Query("SELECT * FROM chats WHERE hidden = 1 AND lastText != '' AND chatId != 'status@broadcast' AND chatId NOT LIKE '%@newsletter' ORDER BY lastTimestamp DESC")
    fun observeHiddenChats(): Flow<List<ChatEntity>>

    @Query("SELECT * FROM chats WHERE chatId LIKE '%@newsletter' ORDER BY lastTimestamp DESC")
    fun observeChannels(): Flow<List<ChatEntity>>

    @Query("SELECT * FROM chats WHERE chatId = :chatId")
    fun observeChat(chatId: String): Flow<ChatEntity?>

    @Query("SELECT * FROM chats WHERE chatId = :chatId")
    suspend fun getChat(chatId: String): ChatEntity?

    @Query("SELECT * FROM messages WHERE chatId = :chatId ORDER BY timestamp ASC")
    fun observeMessages(chatId: String): Flow<List<MessageEntity>>

    @Query("SELECT * FROM messages WHERE chatId = :chatId")
    suspend fun getMessages(chatId: String): List<MessageEntity>

    @Query("SELECT * FROM messages WHERE chatId = :chatId AND messageId = :id")
    suspend fun getMessage(chatId: String, id: String): MessageEntity?

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertMessage(m: MessageEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertChat(c: ChatEntity)

    @Query("UPDATE chats SET unread = 0 WHERE chatId = :chatId")
    suspend fun markRead(chatId: String)

    @Query("UPDATE chats SET customName = :name WHERE chatId = :chatId")
    suspend fun setCustomName(chatId: String, name: String)

    @Query("UPDATE chats SET hidden = :hidden WHERE chatId = :chatId")
    suspend fun setHidden(chatId: String, hidden: Boolean)

    @Query("DELETE FROM chats WHERE chatId = :chatId")
    suspend fun deleteChat(chatId: String)

    @Query("DELETE FROM messages WHERE chatId = :chatId")
    suspend fun deleteMessagesOf(chatId: String)

    @Query("UPDATE messages SET messageId = :newId, status = :status WHERE chatId = :chatId AND messageId = :oldId")
    suspend fun rekeyMessage(chatId: String, oldId: String, newId: String, status: Int)

    @Query("UPDATE messages SET status = :status WHERE chatId = :chatId AND messageId = :id")
    suspend fun setStatus(chatId: String, id: String, status: Int)

    @Query("UPDATE messages SET mediaPath = :path WHERE chatId = :chatId AND messageId = :id")
    suspend fun setMediaPath(chatId: String, id: String, path: String)

    @Query("DELETE FROM messages WHERE chatId = :chatId AND messageId = :id")
    suspend fun deleteMessage(chatId: String, id: String)

    @Query("SELECT * FROM messages WHERE chatId = :chatId AND fromMe = 0 AND incomingRead = 0")
    suspend fun unreadIncoming(chatId: String): List<MessageEntity>

    @Query("UPDATE messages SET incomingRead = 1 WHERE chatId = :chatId AND messageId IN (:ids)")
    suspend fun markIncomingRead(chatId: String, ids: List<String>)

    // Receipts are matched by message id only: the chat id a receipt carries can differ
    // (phone-number vs LID addressing) from the one we sent to.
    @Query("UPDATE messages SET status = 3, deliveredAt = :now WHERE messageId IN (:ids) AND fromMe = 1 AND status IN (0, 1)")
    suspend fun markDelivered(ids: List<String>, now: Long)

    @Query("UPDATE messages SET status = 4, readAt = :now, deliveredAt = CASE WHEN deliveredAt = 0 THEN :now ELSE deliveredAt END WHERE messageId IN (:ids) AND fromMe = 1 AND status IN (0, 1, 3)")
    suspend fun markReadByPeer(ids: List<String>, now: Long)

    @Query("SELECT * FROM messages WHERE chatId = :chatId ORDER BY timestamp DESC LIMIT 1")
    suspend fun lastMessage(chatId: String): MessageEntity?

    @Query("UPDATE messages SET kind = 'deleted', text = '', mediaPath = '', thumbPath = '', mediaRef = '' WHERE chatId = :chatId AND messageId = :id")
    suspend fun markDeleted(chatId: String, id: String)

    @Query("SELECT * FROM messages WHERE chatId = :chatId AND timestamp BETWEEN :from AND :to LIMIT 1")
    suspend fun findByTime(chatId: String, from: Long, to: Long): MessageEntity?

    @Query("SELECT messageId FROM messages WHERE chatId = :chatId ORDER BY timestamp DESC LIMIT 1")
    suspend fun lastMessageId(chatId: String): String?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertPollVote(v: PollVoteEntity)

    @Query("SELECT * FROM poll_votes WHERE chatId = :chatId AND pollId = :pollId ORDER BY timestamp ASC")
    suspend fun pollVotes(chatId: String, pollId: String): List<PollVoteEntity>

    @Query("SELECT timestamp FROM poll_votes WHERE chatId = :chatId AND pollId = :pollId AND voterId = :voterId")
    suspend fun pollVoteTime(chatId: String, pollId: String, voterId: String): Long?

    @Query("UPDATE messages SET pollOptions = :options, pollSelectable = :selectable, pollSecret = :secret WHERE chatId = :chatId AND messageId = :id")
    suspend fun setPoll(chatId: String, id: String, options: String, selectable: Int, secret: String)

    @Query("UPDATE messages SET pollMine = :mine, pollResults = :results WHERE chatId = :chatId AND messageId = :id")
    suspend fun setPollState(chatId: String, id: String, mine: String, results: String)

    @Query("UPDATE messages SET serverId = :serverId WHERE chatId = :chatId AND messageId = :id")
    suspend fun setServerId(chatId: String, id: String, serverId: Long)

    @Query("SELECT * FROM messages WHERE chatId = :chatId AND serverId = :serverId LIMIT 1")
    suspend fun findByServerId(chatId: String, serverId: Long): MessageEntity?

    @Query("UPDATE OR IGNORE messages SET chatId = :to WHERE chatId = :from")
    suspend fun moveMessages(from: String, to: String)

    @Query("UPDATE messages SET senderId = :to WHERE chatId = :to AND senderId = :from")
    suspend fun retargetSender(from: String, to: String)

    @Query("SELECT chatId FROM chats WHERE chatId LIKE '%@lid'")
    suspend fun lidChatIds(): List<String>

    @Query("UPDATE chats SET mutedUntil = :until WHERE chatId = :chatId")
    suspend fun setMutedUntil(chatId: String, until: Long)

    @Query("UPDATE messages SET text = :text, edited = 1 WHERE chatId = :chatId AND messageId = :id AND kind != 'deleted'")
    suspend fun setEdited(chatId: String, id: String, text: String)

    @Query("UPDATE messages SET reactions = :reactions WHERE chatId = :chatId AND messageId = :id")
    suspend fun setReactions(chatId: String, id: String, reactions: String)

    @Query("UPDATE messages SET linkUrl = :url, linkTitle = :title, linkDesc = :desc WHERE chatId = :chatId AND messageId = :id")
    suspend fun setLink(chatId: String, id: String, url: String, title: String, desc: String)

    @Query("SELECT * FROM messages WHERE chatId = :chatId AND kind != 'deleted' AND text LIKE '%' || :q || '%' ESCAPE '\\' ORDER BY timestamp ASC")
    suspend fun searchMessages(chatId: String, q: String): List<MessageEntity>

    @Query("UPDATE chats SET title = :title WHERE chatId = :chatId")
    suspend fun setTitle(chatId: String, title: String)

    @Query("UPDATE chats SET lastText = :text, lastTimestamp = :ts WHERE chatId = :chatId")
    suspend fun setLast(chatId: String, text: String, ts: Long)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertContacts(list: List<ContactEntity>)

    @Query("SELECT * FROM saved_contacts ORDER BY name COLLATE NOCASE")
    fun observeSavedContacts(): Flow<List<SavedContactEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertSavedContact(c: SavedContactEntity)

    @Query("DELETE FROM saved_contacts WHERE jid = :jid")
    suspend fun deleteSavedContact(jid: String)

    @Query("SELECT name FROM saved_contacts WHERE jid = :jid")
    suspend fun savedContactName(jid: String): String?

    @Query("SELECT name FROM contacts WHERE jid = :jid")
    suspend fun contactName(jid: String): String?

    @Query("UPDATE chats SET title = :name WHERE chatId = :chatId AND customName = '' AND (title = :defaultTitle OR title = 'Group')")
    suspend fun renameIfDefault(chatId: String, name: String, defaultTitle: String)

    @Query("SELECT * FROM messages WHERE chatId = 'status@broadcast' AND kind != 'deleted' AND timestamp > :since ORDER BY timestamp ASC")
    fun observeStatuses(since: Long): Flow<List<MessageEntity>>

    @Query("SELECT * FROM messages WHERE chatId = 'status@broadcast' AND timestamp <= :before")
    suspend fun expiredStatuses(before: Long): List<MessageEntity>

    @Query("DELETE FROM messages WHERE chatId = 'status@broadcast' AND timestamp <= :before")
    suspend fun deleteExpiredStatuses(before: Long)
}
