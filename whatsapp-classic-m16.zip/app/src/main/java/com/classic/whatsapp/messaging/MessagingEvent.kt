package com.classic.whatsapp.messaging

/** Stable app-level events. Never expose upstream protocol types to the UI. */
sealed interface MessagingEvent {
    data class PairingCode(val code: String, val expiresInSeconds: Long) : MessagingEvent
    data class PairingQr(val payload: String) : MessagingEvent
    data object Paired : MessagingEvent
    data class PairFailed(val reason: String) : MessagingEvent
    data object Connected : MessagingEvent
    data object Disconnected : MessagingEvent
    data object LoggedOut : MessagingEvent
    data class Fatal(val reason: String) : MessagingEvent
    data class MessageReceived(
        val chatId: String,
        val senderId: String,
        val messageId: String,
        val text: String,
        val timestampMs: Long,
        val fromMe: Boolean,
        val isGroup: Boolean,
        val pushName: String,
        val media: MediaDescriptor?,
        val replyToId: String = "",
        val replyToSender: String = "",
        val replyToText: String = "",
        val historical: Boolean = false,
    ) : MessagingEvent

    /** A message was deleted for everyone. */
    data class MessageRevoked(val chatId: String, val messageId: String) : MessagingEvent

    data class MessageEdited(val chatId: String, val messageId: String, val newText: String) : MessagingEvent

    /** Empty [emoji] = reaction removed. */
    data class ReactionReceived(val chatId: String, val messageId: String, val senderId: String, val emoji: String, val fromMe: Boolean) : MessagingEvent

    data class LinkPreview(val chatId: String, val messageId: String, val url: String, val title: String, val description: String) : MessagingEvent

    data class PollInfo(val chatId: String, val messageId: String, val options: List<String>, val selectable: Int, val secret: ByteArray) : MessagingEvent

    data class PollVote(
        val chatId: String,
        val pollId: String,
        val voterId: String,
        val payload: ByteArray,
        val iv: ByteArray,
        val timestampMs: Long,
    ) : MessagingEvent

    data class ServerId(val chatId: String, val messageId: String, val serverId: Long) : MessagingEvent

    /** Reaction counts pushed for channel posts; each pair is (server id of the post, counts). */
    data class LiveReactions(val chatId: String, val posts: List<Pair<Long, List<Pair<String, Long>>>>) : MessagingEvent

    /** [state]: composing, recording or paused. */
    data class Typing(val chatId: String, val senderId: String, val state: String) : MessagingEvent

    data class ChatInfo(val chatId: String, val name: String) : MessagingEvent

    /** (jid, name) pairs learned from history sync. */
    data class ContactNames(val names: List<Pair<String, String>>) : MessagingEvent

    /** kind: "delivered" or "read" */
    data class ReceiptReceived(val messageIds: List<String>, val kind: String) : MessagingEvent
}
