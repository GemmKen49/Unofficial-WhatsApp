package com.classic.whatsapp.ui.communities

import android.widget.Toast
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.classic.whatsapp.ClassicApp
import com.classic.whatsapp.ui.LinkText
import com.classic.whatsapp.ui.conversation.MenuEntry
import com.classic.whatsapp.ui.conversation.MessageMenuPopup
import com.classic.whatsapp.ui.conversation.ReactionPill
import com.classic.whatsapp.ui.conversation.SwipeToAct
import com.classic.whatsapp.ui.conversation.canForward
import com.classic.whatsapp.ui.conversation.startForward
import com.classic.whatsapp.data.Reactions
import android.content.ClipData
import android.content.ClipboardManager
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.combinedClickable
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.ui.layout.LayoutCoordinates
import androidx.compose.ui.layout.boundsInWindow
import androidx.compose.ui.layout.onGloballyPositioned
import com.classic.whatsapp.Notifier
import com.classic.whatsapp.data.MessageEntity
import com.classic.whatsapp.ui.conversation.rememberBitmap
import com.classic.whatsapp.ui.formatTime
import java.io.File
import kotlinx.coroutines.launch

private val BadgeGreen = Color(0xFF25D366)

/** Green count badge, same look as in the chat list. */
@Composable
internal fun CountBadge(count: Int, modifier: Modifier = Modifier) {
    Box(
        modifier.defaultMinSize(minWidth = 20.dp, minHeight = 20.dp).background(BadgeGreen, CircleShape).padding(horizontal = 6.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(if (count > 99) "99+" else count.toString(), style = MaterialTheme.typography.labelSmall, color = Color.White, fontWeight = FontWeight.Bold)
    }
}

private fun hasFile(m: MessageEntity) = m.mediaPath.isNotBlank() && File(m.mediaPath).exists()

/**
 * The posts received from one channel (stored like messages), newest first, as cards. Opening it clears the unread count
 * locally; no read receipts are sent for channel posts.
 */
@Composable
fun ChannelScreen(chatId: String, onBack: () -> Unit, onViewMedia: (String) -> Unit) {
    val ctx = LocalContext.current
    val app = ctx.applicationContext as ClassicApp
    val repo = app.repo
    val scope = rememberCoroutineScope()
    var menuFor by remember { mutableStateOf<Pair<MessageEntity, Rect?>?>(null) }
    var listBounds by remember { mutableStateOf<Rect?>(null) }
    var menuAnchorX by remember { mutableStateOf<Float?>(null) }
    val halfTap = with(androidx.compose.ui.platform.LocalDensity.current) { 24.dp.toPx() }
    val reactionStatus by repo.channelReactionStatus.collectAsState()
    val liveStatus by repo.channelLiveStatus.collectAsState()
    val chat by repo.chat(chatId).collectAsState(initial = null)
    val messages by repo.messages(chatId).collectAsState(initial = emptyList())
    val downloading by repo.downloading.collectAsState()
    val foreground by repo.foreground.collectAsState()
    LaunchedEffect(chatId, foreground, messages.size) {
        if (foreground) {
            repo.markChannelRead(chatId)
            Notifier.cancel(ctx, chatId)
        }
    }

    // Ask the server to push reaction counts while the channel is open (re-asked before the subscription ends).
    LaunchedEffect(chatId) {
        while (true) {
            val secs = repo.subscribeChannelLive(chatId)
            kotlinx.coroutines.delay(if (secs > 40) (secs - 20) * 1000 else 120_000)
        }
    }

    // Reaction counts of the latest posts, refreshed while the channel is open.
    LaunchedEffect(chatId) {
        while (true) {
            val ok = repo.refreshChannelReactions(chatId)
            // Every minute; after a failure only every five minutes, so a server that does not answer is not hammered.
            kotlinx.coroutines.delay(if (ok) 60_000 else 300_000)
        }
    }

    Column(Modifier.fillMaxSize().statusBarsPadding()) {
        Row(Modifier.fillMaxWidth().padding(end = 16.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back") }
            Text(chat?.displayTitle ?: "Channel", style = MaterialTheme.typography.titleLarge, maxLines = 1, modifier = Modifier.weight(1f))
        }
        if (liveStatus.isNotBlank()) {
            Text(
                liveStatus,
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(horizontal = 16.dp),
            )
        }
        if (reactionStatus.isNotBlank()) {
            Text(
                reactionStatus,
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(horizontal = 16.dp),
            )
        }
        if (messages.isEmpty()) {
            Box(Modifier.fillMaxSize().padding(32.dp), contentAlignment = Alignment.Center) {
                Text("No posts received yet.", style = MaterialTheme.typography.bodyMedium)
            }
        } else {
            LazyColumn(
                Modifier.fillMaxSize().onGloballyPositioned { listBounds = it.boundsInWindow() },
                contentPadding = PaddingValues(bottom = 24.dp),
            ) {
                items(messages.asReversed(), key = { it.messageId }) { m ->
                    // Swipe left to forward (there is no reply in channels).
                    SwipeToAct(
                        enabled = m.kind != "deleted",
                        onReply = {},
                        allowReply = false,
                        onForward = {
                            scope.launch {
                                val skipped = startForward(ctx, app, listOf(m))
                                if (skipped > 0) Toast.makeText(ctx, "Nothing to forward (download the media first)", Toast.LENGTH_SHORT).show()
                            }
                        },
                    ) {
                        PostCard(
                            m,
                            downloading = m.messageId in downloading,
                            highlighted = m.messageId == menuFor?.first?.messageId,
                            onLong = { p ->
                                // The docks appear at the height of the finger, not above/below the (tall) post.
                                if (m.kind != "deleted") {
                                    menuFor = m to p?.let { Rect(it.x, it.y - halfTap, it.x, it.y + halfTap) }
                                    menuAnchorX = p?.x
                                }
                            },
                        ) {
                            if (hasFile(m)) {
                                onViewMedia(m.messageId)
                            } else {
                                scope.launch {
                                    repo.downloadMedia(chatId, m.messageId)
                                    repo.lastError.value?.let { Toast.makeText(ctx, it, Toast.LENGTH_SHORT).show() }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    menuFor?.let { (m, rect) ->
        val entries = buildList {
            if (canForward(m)) {
                add(MenuEntry("Forward") {
                    scope.launch {
                        val skipped = startForward(ctx, app, listOf(m))
                        if (skipped > 0) Toast.makeText(ctx, "Nothing to forward (download the media first)", Toast.LENGTH_SHORT).show()
                    }
                })
            }
            if (m.text.isNotBlank()) {
                add(MenuEntry("Copy") {
                    ctx.getSystemService(ClipboardManager::class.java).setPrimaryClip(ClipData.newPlainText("post", m.text))
                })
            }
        }
        MessageMenuPopup(
            bounds = rect,
            area = listBounds,
            anchorX = menuAnchorX,
            fromMe = false,
            myReaction = Reactions.mine(m.reactions),
            showReactions = true,
            entries = entries,
            onReact = { e -> scope.launch { repo.reactChannel(chatId, m, e) } },
            onDismiss = { menuFor = null },
        )
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun PostCard(m: MessageEntity, downloading: Boolean, highlighted: Boolean, onLong: (Offset?) -> Unit, onOpenMedia: () -> Unit) {
    var coords by remember { mutableStateOf<LayoutCoordinates?>(null) }
    var mediaCoords by remember { mutableStateOf<LayoutCoordinates?>(null) }
    val longHandler by rememberUpdatedState(onLong)
    val openMedia by rememberUpdatedState(onOpenMedia)
    val hasReactions = m.reactions.isNotBlank() && m.kind != "deleted"
    Box(Modifier.fillMaxWidth().padding(start = 12.dp, end = 12.dp, top = 6.dp, bottom = if (hasReactions) 18.dp else 6.dp)) {
    Card(
        Modifier.fillMaxWidth()
            .onGloballyPositioned { coords = it }
            .pointerInput(Unit) {
                detectTapGestures(onLongPress = { off -> longHandler(coords?.takeIf { it.isAttached }?.localToWindow(off)) })
            },
        colors = if (highlighted) CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.tertiaryContainer) else CardDefaults.cardColors(),
    ) {
        Column(Modifier.padding(12.dp)) {
            if (m.kind == "deleted") {
                Text("This post was deleted", style = MaterialTheme.typography.bodyMedium, fontStyle = FontStyle.Italic)
            } else {
                if (m.kind == "image" || m.kind == "video") {
                    val shown = if (hasFile(m)) m.mediaPath else m.thumbPath
                    val bmp = if (shown.isNotBlank()) rememberBitmap(shown, 1200) else null
                    Box(
                        Modifier.fillMaxWidth().height(200.dp).clip(RoundedCornerShape(8.dp))
                            .background(MaterialTheme.colorScheme.surfaceVariant)
                            .onGloballyPositioned { mediaCoords = it }
                            .pointerInput(Unit) {
                                detectTapGestures(
                                    onTap = { openMedia() },
                                    onLongPress = { off -> longHandler(mediaCoords?.takeIf { it.isAttached }?.localToWindow(off)) },
                                )
                            },
                        contentAlignment = Alignment.Center,
                    ) {
                        if (bmp != null) Image(bmp, contentDescription = null, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
                        when {
                            downloading -> CircularProgressIndicator()
                            !hasFile(m) -> Text(
                                if (m.kind == "video") "Tap to download video" else "Tap to download photo",
                                style = MaterialTheme.typography.labelMedium,
                                color = Color.White,
                                modifier = Modifier.background(Color.Black.copy(alpha = 0.5f), RoundedCornerShape(8.dp)).padding(8.dp),
                            )
                            m.kind == "video" -> Text("▶", style = MaterialTheme.typography.headlineMedium, color = Color.White)
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                } else if (m.kind != "text") {
                    Text(
                        when (m.kind) {
                            "audio" -> "Audio"
                            else -> m.fileName.ifBlank { "File" }
                        },
                        style = MaterialTheme.typography.labelMedium,
                    )
                }
                if (m.text.isNotBlank()) LinkText(m.text, MaterialTheme.typography.bodyMedium)
            }
            Text(
                formatTime(m.timestamp),
                style = MaterialTheme.typography.labelSmall,
                modifier = Modifier.padding(top = 6.dp).align(Alignment.End),
            )
        }
    }
    if (hasReactions) {
        ReactionPill(m.reactions, Modifier.align(Alignment.BottomStart).offset(x = 12.dp, y = 12.dp))
    }
    }
}
