package com.classic.whatsapp.ui.contactinfo

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.classic.whatsapp.ClassicApp
import com.classic.whatsapp.ui.Avatar
import com.classic.whatsapp.ui.contacts.ContactDialog
import kotlinx.coroutines.launch

/**
 * "Contact info" for another person: large photo, name, number, About, a Message action and Edit.
 * Edit only changes the local address book entry (name + number); it cannot change the person's real profile.
 */
@Composable
fun ContactInfoScreen(jid: String, onBack: () -> Unit, onMessage: (String) -> Unit) {
    val app = LocalContext.current.applicationContext as ClassicApp
    val repo = app.repo
    val avatars = app.avatars
    val scope = rememberCoroutineScope()

    val isPn = jid.substringAfter('@', "") == "s.whatsapp.net"
    val number = if (isPn) jid.substringBefore('@').substringBefore(':') else ""
    val pnJid = if (isPn) "$number@s.whatsapp.net" else jid

    val chat by repo.chat(jid).collectAsState(initial = null)
    val saved by repo.savedContacts.collectAsState(initial = emptyList())
    val savedEntry = saved.firstOrNull { it.jid == pnJid }
    val name = savedEntry?.name
        ?: chat?.displayTitle?.takeIf { it.isNotBlank() }
        ?: if (number.isNotBlank()) "+$number" else "Unknown"

    var about by remember(jid) { mutableStateOf(avatars.cachedAbout(jid)) }
    var aboutLoaded by remember(jid) { mutableStateOf(false) }
    var editing by remember { mutableStateOf(false) }

    LaunchedEffect(jid) {
        avatars.loadFull(jid)
        about = avatars.loadAbout(jid)
        aboutLoaded = true
    }

    Column(Modifier.fillMaxSize().statusBarsPadding().verticalScroll(rememberScrollState())) {
        Row(Modifier.fillMaxWidth().padding(end = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back") }
            Text("Contact info", style = MaterialTheme.typography.titleLarge, modifier = Modifier.weight(1f))
            if (isPn) TextButton(onClick = { editing = true }) { Text("Edit") }
        }
        Column(Modifier.fillMaxWidth().padding(top = 8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Avatar(jid, name, Modifier.size(160.dp), MaterialTheme.typography.displayLarge, full = true)
            Text(name, style = MaterialTheme.typography.headlineSmall, modifier = Modifier.padding(top = 16.dp, start = 24.dp, end = 24.dp))
            if (number.isNotBlank()) Text("+$number", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            OutlinedButton(onClick = { onMessage(jid) }, modifier = Modifier.padding(top = 16.dp)) { Text("Message") }
        }
        HorizontalDivider(Modifier.padding(top = 24.dp))
        InfoRow(
            icon = { Icon(Icons.Default.Info, contentDescription = null) },
            label = "About",
            value = about?.takeIf { it.isNotBlank() } ?: if (aboutLoaded) "Not available" else "…",
        )
        if (number.isNotBlank()) {
            InfoRow(icon = { Icon(Icons.Default.Phone, contentDescription = null) }, label = "Phone", value = "+$number")
        }
    }

    if (editing) {
        ContactDialog(
            initial = savedEntry,
            prefillName = name.takeIf { !it.startsWith("+") }.orEmpty(),
            prefillDigits = number,
            onDismiss = { editing = false },
            onSave = { newName, digits ->
                editing = false
                scope.launch { repo.saveContact(newName, digits, oldJid = savedEntry?.jid) }
            },
            onDelete = savedEntry?.let { c ->
                val delete: () -> Unit = {
                    editing = false
                    scope.launch { repo.deleteContact(c.jid) }
                }
                delete
            },
        )
    }
}

@Composable
private fun InfoRow(icon: @Composable () -> Unit, label: String, value: String) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp), verticalAlignment = Alignment.Top) {
        Box(Modifier.width(40.dp).padding(top = 2.dp)) { icon() }
        Column(Modifier.weight(1f)) {
            Text(label, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text(value, style = MaterialTheme.typography.bodyLarge)
        }
    }
}
