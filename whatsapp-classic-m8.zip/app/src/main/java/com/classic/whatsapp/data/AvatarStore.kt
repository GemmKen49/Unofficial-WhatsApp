package com.classic.whatsapp.data

import android.content.Context
import com.classic.whatsapp.messaging.MessagingClient
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.ConcurrentHashMap
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext

/**
 * Profile pictures and About texts of other people, cached in `files/avatars/` and SharedPreferences `avatars`.
 * Pictures are re-checked at most once a day (the picture id tells whether the file changed); a missing or hidden
 * picture is remembered too, so the server is not asked again on every list refresh. Failures (offline, timeouts)
 * back off for five minutes. Everything is best-effort: the UI falls back to the initial letter.
 */
class AvatarStore(private val ctx: Context, private val client: MessagingClient) {
    private val dir = File(ctx.filesDir, "avatars").apply { mkdirs() }
    private val prefs = ctx.getSharedPreferences("avatars", Context.MODE_PRIVATE)
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val inFlight = ConcurrentHashMap.newKeySet<String>()
    private val limiter = Semaphore(3)

    private val _rev = MutableStateFlow(0)

    /** Bumped whenever any picture or About text changed on disk. */
    val rev: StateFlow<Int> = _rev.asStateFlow()

    /** Id without a device suffix, e.g. `4917012345:12@s.whatsapp.net` -> `4917012345@s.whatsapp.net`. */
    fun normalize(jid: String): String = jid.replace(Regex(":\\d+@"), "@")

    private fun key(jid: String) = normalize(jid).replace(Regex("[^A-Za-z0-9._-]"), "_")

    private fun thumb(jid: String) = File(dir, key(jid) + ".jpg")

    private fun full(jid: String) = File(dir, key(jid) + "_full.jpg")

    /** The cached thumbnail, or null. */
    fun file(jid: String): File? = thumb(jid).takeIf { it.exists() }

    /** The cached full-size picture, or null. */
    fun fullFile(jid: String): File? = full(jid).takeIf { it.exists() }

    /** Asks the server for a newer picture if the cached state is older than [staleMs]; returns immediately. */
    fun request(jid: String, staleMs: Long = DAY_MS) {
        if (jid.isBlank() || jid.startsWith("status@")) return
        val k = key(jid)
        if (System.currentTimeMillis() - prefs.getLong("checked_$k", 0L) < staleMs) return
        if (!inFlight.add(k)) return
        scope.launch {
            try {
                limiter.withPermit { refreshThumb(jid, k) }
            } finally {
                inFlight.remove(k)
            }
        }
    }

    private suspend fun refreshThumb(jid: String, k: String) {
        try {
            val ref = client.profilePicture(normalize(jid), preview = true)
            val file = thumb(jid)
            var changed = false
            if (ref == null) {
                if (file.delete()) changed = true
                prefs.edit().remove("id_$k").apply()
            } else if (!file.exists() || prefs.getString("id_$k", null) != ref.id) {
                download(ref.url, file)
                prefs.edit().putString("id_$k", ref.id).apply()
                full(jid).delete()
                changed = true
            }
            prefs.edit().putLong("checked_$k", System.currentTimeMillis()).apply()
            if (changed) _rev.value++
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            // Offline / not connected / channel ids without a picture query: retry in five minutes.
            prefs.edit().putLong("checked_$k", System.currentTimeMillis() - DAY_MS + RETRY_MS).apply()
        }
    }

    /** Downloads (once per picture id) and returns the full-size picture; null when there is none or on failure. */
    suspend fun loadFull(jid: String): File? =
        withContext(Dispatchers.IO) {
            try {
                val ref = client.profilePicture(normalize(jid), preview = false) ?: return@withContext null
                val k = key(jid)
                val file = full(jid)
                if (!file.exists() || prefs.getString("fullid_$k", null) != ref.id) {
                    download(ref.url, file)
                    prefs.edit().putString("fullid_$k", ref.id).apply()
                    _rev.value++
                }
                file
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                fullFile(jid)
            }
        }

    /** The account's own id without device suffix (cached once known), or null while the engine cannot tell. */
    suspend fun ownJid(): String? =
        withContext(Dispatchers.IO) {
            prefs.getString("own_jid", null) ?: try {
                normalize(client.ownJid()).also { prefs.edit().putString("own_jid", it).apply() }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                null
            }
        }

    /** Last known About text, or null. */
    fun cachedAbout(jid: String): String? = prefs.getString("about_${key(jid)}", null)

    /** Fetches the current About text; falls back to the cached one when offline. */
    suspend fun loadAbout(jid: String): String? =
        withContext(Dispatchers.IO) {
            val k = key(jid)
            try {
                val text = client.userAbout(normalize(jid))
                prefs.edit().apply { if (text == null) remove("about_$k") else putString("about_$k", text) }.apply()
                text
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                cachedAbout(jid)
            }
        }

    /** Replaces the cached copy of a picture with bytes we just uploaded ourselves. */
    fun storeOwn(jid: String, jpeg: ByteArray?) {
        val file = thumb(jid)
        if (jpeg == null) file.delete() else file.writeBytes(jpeg)
        full(jid).delete()
        prefs.edit().remove("id_${key(jid)}").remove("fullid_${key(jid)}").putLong("checked_${key(jid)}", 0L).apply()
        _rev.value++
    }

    private fun download(url: String, dest: File) {
        val conn = URL(url).openConnection() as HttpURLConnection
        try {
            conn.connectTimeout = 15_000
            conn.readTimeout = 20_000
            if (conn.responseCode != 200) throw IllegalStateException("HTTP ${conn.responseCode}")
            val tmp = File(dest.path + ".tmp")
            var total = 0L
            conn.inputStream.use { input ->
                tmp.outputStream().use { out ->
                    val buf = ByteArray(16 * 1024)
                    while (true) {
                        val n = input.read(buf)
                        if (n < 0) break
                        total += n
                        if (total > MAX_BYTES) throw IllegalStateException("Picture too large")
                        out.write(buf, 0, n)
                    }
                }
            }
            if (!tmp.renameTo(dest)) {
                tmp.copyTo(dest, overwrite = true)
                tmp.delete()
            }
        } finally {
            conn.disconnect()
        }
    }

    /** Forgets everything (used when the account is unlinked). */
    fun clear() {
        dir.listFiles()?.forEach { it.delete() }
        prefs.edit().clear().apply()
        _rev.value++
    }

    private companion object {
        const val DAY_MS = 24L * 60 * 60 * 1000
        const val RETRY_MS = 5L * 60 * 1000
        const val MAX_BYTES = 8L * 1024 * 1024
    }
}
