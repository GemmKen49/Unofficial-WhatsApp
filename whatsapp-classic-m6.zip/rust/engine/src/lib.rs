//! WhatsApp Classic engine: the ONLY place that touches upstream `whatsapp-rust`.
//!
//! Kotlin sees only the stable types below (`Engine`, `EngineEvent`,
//! `EngineListener`, `EngineError`). If upstream changes its API, fix
//! `run_bot` / `forward` here and nothing else.
//!
//! Written against whatsapp-rust 0.7.0 (verified against compiler errors and docs.rs).

uniffi::setup_scaffolding!();

use std::path::PathBuf;
use std::sync::{Arc, Mutex, OnceLock};
use std::time::Duration;

use whatsapp_rust::bot::Bot;
use whatsapp_rust::download::{DownloadParams, MediaType};
use whatsapp_rust::media::{self, AudioOptions, DocumentOptions, ImageOptions, VideoOptions};
use whatsapp_rust::send::RevokeType;
use whatsapp_rust::types::presence::ReceiptType;
use whatsapp_rust::prelude::{wa, Jid, MessageBuilderExt, MessageExt};
use whatsapp_rust::pair_code::{CompanionWebClientType, PairCodeOptions};
use whatsapp_rust::store::SqliteStore;
use whatsapp_rust::types::events::{Event, LazyHistorySync};
use whatsapp_rust::{Client, TokioRuntime};
use whatsapp_rust_tokio_transport::TokioWebSocketTransportFactory;
use whatsapp_rust_ureq_http_client::UreqHttpClient;

#[derive(Debug, thiserror::Error, uniffi::Error)]
pub enum EngineError {
    #[error("{0}")]
    Invalid(String),
    #[error("{0}")]
    Internal(String),
}

const MAX_UPLOAD_BYTES: u64 = 64 * 1024 * 1024;

/// Reference to a media attachment (incoming), also used to request its download.
/// `kind` is "image", "video", "document" or "viewonce" (never downloadable).
#[derive(Debug, Clone, uniffi::Record)]
pub struct MediaInfo {
    pub kind: String,
    pub mimetype: String,
    pub file_name: String,
    pub caption: String,
    pub file_length: u64,
    pub direct_path: String,
    pub media_key: Vec<u8>,
    pub file_sha256: Vec<u8>,
    pub file_enc_sha256: Vec<u8>,
    pub thumbnail: Vec<u8>,
    pub duration_secs: u32,
    /// Voice note (push-to-talk) rather than a plain audio file.
    pub voice: bool,
}

/// A local file to upload and send. `kind` is "image", "video", "audio" or "document".
#[derive(Debug, Clone, uniffi::Record)]
pub struct OutgoingMedia {
    pub chat_id: String,
    pub kind: String,
    pub path: String,
    pub mimetype: String,
    pub file_name: String,
    pub caption: String,
    pub thumbnail: Vec<u8>,
    pub duration_secs: u32,
    pub voice: bool,
    /// Send with the "Forwarded" label.
    pub forwarded: bool,
    /// Voice notes: loudness preview (64 values, 0..100). Empty = none.
    pub waveform: Vec<u8>,
}

#[derive(Debug, Clone, uniffi::Record)]
pub struct ContactName {
    pub jid: String,
    pub name: String,
}

/// A community the account is part of (the parent group).
#[derive(Debug, Clone, uniffi::Record)]
pub struct CommunityInfo {
    pub jid: String,
    pub name: String,
}

/// A group linked to a community. `members` is 0 when the server did not report a count.
#[derive(Debug, Clone, uniffi::Record)]
pub struct CommunityGroupInfo {
    pub jid: String,
    pub name: String,
    pub announcement: bool,
    pub general: bool,
    pub members: u32,
}

/// Stable, protocol-agnostic events for the Android side.
#[derive(Debug, Clone, uniffi::Enum)]
pub enum EngineEvent {
    PairingCode { code: String, timeout_secs: u64 },
    PairingQr { code: String },
    Paired,
    PairFailed { reason: String },
    Connected,
    Disconnected,
    LoggedOut,
    Fatal { reason: String },
    /// A text message (incoming, or sent from another device of this account).
    MessageReceived {
        chat_id: String,
        sender_id: String,
        message_id: String,
        text: String,
        timestamp_ms: i64,
        from_me: bool,
        is_group: bool,
        push_name: String,
        media: Option<MediaInfo>,
        /// Set when this message quotes another one (text replies only).
        reply_to_id: String,
        reply_to_sender: String,
        reply_to_text: String,
        /// True for messages replayed by history sync (no notification / receipts).
        historical: bool,
    },
    /// The sender (or one of our other devices) deleted a message for everyone.
    MessageRevoked { chat_id: String, message_id: String },
    /// A chat name learned from history sync.
    ChatInfo { chat_id: String, name: String },
    /// Contact push names learned from history sync.
    ContactNames { names: Vec<ContactName> },
    /// "delivered" or "read" receipt from a recipient for messages we sent.
    ReceiptReceived {
        chat_id: String,
        message_ids: Vec<String>,
        kind: String,
    },
}

#[uniffi::export(with_foreign)]
pub trait EngineListener: Send + Sync {
    fn on_event(&self, event: EngineEvent);
}

fn runtime() -> &'static tokio::runtime::Runtime {
    static RT: OnceLock<tokio::runtime::Runtime> = OnceLock::new();
    RT.get_or_init(|| {
        tokio::runtime::Builder::new_multi_thread()
            .worker_threads(2)
            .enable_all()
            .build()
            .expect("failed to build tokio runtime")
    })
}

/// ContextInfo that makes WhatsApp show the "Forwarded" label.
fn forward_context() -> wa::ContextInfo {
    wa::ContextInfo {
        is_forwarded: Some(true),
        forwarding_score: Some(1),
        ..Default::default()
    }
}

type ClientSlot = Arc<Mutex<Option<Arc<Client>>>>;

#[derive(uniffi::Object)]
pub struct Engine {
    data_dir: PathBuf,
    listener: Arc<dyn EngineListener>,
    task: Mutex<Option<tokio::task::JoinHandle<()>>>,
    client: ClientSlot,
}

#[uniffi::export]
impl Engine {
    #[uniffi::constructor]
    pub fn new(data_dir: String, listener: Arc<dyn EngineListener>) -> Arc<Self> {
        // Warn level only: upstream logs phone numbers and pair codes at info.
        android_logger::init_once(
            android_logger::Config::default()
                .with_max_level(log::LevelFilter::Warn)
                .with_tag("WAClassic"),
        );
        let _ = std::fs::create_dir_all(&data_dir);
        Arc::new(Self {
            data_dir: PathBuf::from(data_dir),
            listener,
            task: Mutex::new(None),
            client: Arc::new(Mutex::new(None)),
        })
    }

    /// Start (or resume) the connection. With `pairing_phone` set (digits,
    /// country code first, no leading zero) a pairing code is requested; it
    /// arrives as `EngineEvent::PairingCode`. With `None`, an existing
    /// session is resumed.
    pub fn start(&self, pairing_phone: Option<String>) -> Result<(), EngineError> {
        let phone = pairing_phone
            .map(|p| p.chars().filter(|c| c.is_ascii_digit()).collect::<String>());
        if let Some(p) = &phone {
            if p.len() < 8 || p.len() > 15 || p.starts_with('0') {
                return Err(EngineError::Invalid("Invalid phone number".into()));
            }
        }
        let mut guard = self
            .task
            .lock()
            .map_err(|e| EngineError::Internal(e.to_string()))?;
        if guard.as_ref().is_some_and(|h| !h.is_finished()) {
            return Ok(());
        }
        let db = self.data_dir.join("whatsapp.db");
        let listener = self.listener.clone();
        let slot = self.client.clone();
        *guard = Some(runtime().spawn(async move {
            if let Err(e) = run_bot(db, phone, listener.clone(), slot).await {
                listener.on_event(EngineEvent::Fatal { reason: e.to_string() });
            }
        }));
        Ok(())
    }

    /// Graceful disconnect, then abort the task if it has not ended on its own.
    pub fn stop(&self) {
        let client = self.client.lock().ok().and_then(|mut g| g.take());
        let task = self.task.lock().ok().and_then(|mut g| g.take());
        if client.is_none() && task.is_none() {
            return;
        }
        runtime().spawn(async move {
            if let Some(c) = client {
                let _ = c.disconnect().await;
            }
            tokio::time::sleep(Duration::from_millis(300)).await;
            if let Some(t) = task {
                t.abort();
            }
        });
    }

    pub fn is_running(&self) -> bool {
        self.task
            .lock()
            .map(|g| g.as_ref().is_some_and(|h| !h.is_finished()))
            .unwrap_or(false)
    }

    /// Send a text message to `chat_jid`. Blocks until the server accepts it (30 s timeout).
    /// Call from a background thread. Returns the message id.
    pub fn send_text(&self, chat_jid: String, text: String) -> Result<String, EngineError> {
        let jid: Jid = chat_jid
            .parse()
            .map_err(|e| EngineError::Invalid(format!("Invalid chat id: {e}")))?;
        let client = self
            .client
            .lock()
            .ok()
            .and_then(|g| g.clone())
            .ok_or_else(|| EngineError::Internal("Not connected".into()))?;
        runtime().block_on(async move {
            tokio::time::timeout(
                Duration::from_secs(30),
                client.send_message(&jid, wa::Message::text(text.as_str())),
            )
            .await
            .map_err(|_| EngineError::Internal("Send timed out".into()))?
            .map(|sent| sent.message_id)
            .map_err(|e| EngineError::Internal(e.to_string()))
        })
    }

    /// Send a text message with the "Forwarded" label.
    pub fn forward_text(&self, chat_jid: String, text: String) -> Result<String, EngineError> {
        let jid: Jid = chat_jid
            .parse()
            .map_err(|e| EngineError::Invalid(format!("Invalid chat id: {e}")))?;
        let client = self.connected_client()?;
        let msg = wa::Message {
            extended_text_message: buffa::MessageField::some(wa::message::ExtendedTextMessage {
                text: Some(text),
                context_info: buffa::MessageField::some(forward_context()),
                ..Default::default()
            }),
            ..Default::default()
        };
        runtime().block_on(async move {
            tokio::time::timeout(Duration::from_secs(30), client.send_message(&jid, msg))
                .await
                .map_err(|_| EngineError::Internal("Send timed out".into()))?
                .map(|sent| sent.message_id)
                .map_err(|e| EngineError::Internal(e.to_string()))
        })
    }

    /// Send a text message that quotes another message.
    /// `reply_to_sender` is the quoted author (empty for our own messages / 1:1 chats).
    pub fn send_reply(
        &self,
        chat_jid: String,
        text: String,
        reply_to_id: String,
        reply_to_sender: String,
        reply_to_text: String,
        reply_to_chat: String,
    ) -> Result<String, EngineError> {
        let jid: Jid = chat_jid
            .parse()
            .map_err(|e| EngineError::Invalid(format!("Invalid chat id: {e}")))?;
        let client = self.connected_client()?;
        let context = wa::ContextInfo {
            stanza_id: Some(reply_to_id),
            participant: if reply_to_sender.is_empty() { None } else { Some(reply_to_sender) },
            quoted_message: buffa::MessageField::some(wa::Message::text(reply_to_text.as_str())),
            // Set to status@broadcast when replying to a status update.
            remote_jid: non_empty(reply_to_chat),
            ..Default::default()
        };
        let msg = wa::Message {
            extended_text_message: buffa::MessageField::some(wa::message::ExtendedTextMessage {
                text: Some(text),
                context_info: buffa::MessageField::some(context),
                ..Default::default()
            }),
            ..Default::default()
        };
        runtime().block_on(async move {
            tokio::time::timeout(Duration::from_secs(30), client.send_message(&jid, msg))
                .await
                .map_err(|_| EngineError::Internal("Send timed out".into()))?
                .map(|sent| sent.message_id)
                .map_err(|e| EngineError::Internal(e.to_string()))
        })
    }

    /// Delete one of our own messages for everyone in the chat.
    pub fn revoke_message(&self, chat_jid: String, message_id: String) -> Result<(), EngineError> {
        let jid: Jid = chat_jid
            .parse()
            .map_err(|e| EngineError::Invalid(format!("Invalid chat id: {e}")))?;
        let client = self.connected_client()?;
        runtime().block_on(async move {
            tokio::time::timeout(
                Duration::from_secs(30),
                client.revoke_message(jid, message_id, RevokeType::Sender),
            )
            .await
            .map_err(|_| EngineError::Internal("Delete timed out".into()))?
            .map_err(|e| EngineError::Internal(e.to_string()))
        })
    }

    /// Current subject (name) of a group.
    pub fn group_subject(&self, group_jid: String) -> Result<String, EngineError> {
        let jid: Jid = group_jid
            .parse()
            .map_err(|e| EngineError::Invalid(format!("Invalid group id: {e}")))?;
        let client = self.connected_client()?;
        runtime().block_on(async move {
            tokio::time::timeout(Duration::from_secs(20), client.groups().get_metadata(&jid))
                .await
                .map_err(|_| EngineError::Internal("Group lookup timed out".into()))?
                .map(|m| m.subject)
                .map_err(|e| EngineError::Internal(e.to_string()))
        })
    }

    /// Communities (parent groups) this account participates in, sorted by name.
    pub fn list_communities(&self) -> Result<Vec<CommunityInfo>, EngineError> {
        let client = self.connected_client()?;
        runtime().block_on(async move {
            let map = tokio::time::timeout(Duration::from_secs(30), client.community().get_participating())
                .await
                .map_err(|_| EngineError::Internal("Community lookup timed out".into()))?
                .map_err(|e| EngineError::Internal(e.to_string()))?;
            let mut list: Vec<CommunityInfo> = map
                .into_iter()
                .map(|(jid, meta)| CommunityInfo { jid: jid.to_string(), name: meta.subject })
                .collect();
            list.sort_by(|a, b| a.name.to_lowercase().cmp(&b.name.to_lowercase()));
            Ok(list)
        })
    }

    /// Groups linked to one community: announcement group first, then the general chat, then the rest by name.
    pub fn community_groups(&self, community_jid: String) -> Result<Vec<CommunityGroupInfo>, EngineError> {
        let jid: Jid = community_jid
            .parse()
            .map_err(|e| EngineError::Invalid(format!("Invalid community id: {e}")))?;
        let client = self.connected_client()?;
        runtime().block_on(async move {
            let groups = tokio::time::timeout(Duration::from_secs(30), client.community().get_subgroups(&jid))
                .await
                .map_err(|_| EngineError::Internal("Community lookup timed out".into()))?
                .map_err(|e| EngineError::Internal(e.to_string()))?;
            let mut list: Vec<CommunityGroupInfo> = groups
                .into_iter()
                .map(|g| CommunityGroupInfo {
                    jid: g.id.to_string(),
                    name: g.subject,
                    announcement: g.is_default_sub_group,
                    general: g.is_general_chat,
                    members: g.participant_count.unwrap_or(0),
                })
                .collect();
            list.sort_by(|a, b| {
                (!a.announcement, !a.general, a.name.to_lowercase())
                    .cmp(&(!b.announcement, !b.general, b.name.to_lowercase()))
            });
            Ok(list)
        })
    }

    /// Upload a local file and send it as an image / video / document message.
    /// Blocks (up to ~10 min); call from a background thread. Returns the message id.
    pub fn send_media(&self, m: OutgoingMedia) -> Result<String, EngineError> {
        let OutgoingMedia { chat_id, kind, path, mimetype, file_name, caption, thumbnail, duration_secs, voice, forwarded, waveform } = m;
        let jid: Jid = chat_id
            .parse()
            .map_err(|e| EngineError::Invalid(format!("Invalid chat id: {e}")))?;
        let client = self.connected_client()?;
        let media_type = media_type_of(&kind)?;
        let len = std::fs::metadata(&path)
            .map_err(|e| EngineError::Invalid(format!("Cannot read file: {e}")))?
            .len();
        if len > MAX_UPLOAD_BYTES {
            return Err(EngineError::Invalid("File too large (limit 64 MB)".into()));
        }
        let data = std::fs::read(&path).map_err(|e| EngineError::Invalid(format!("Cannot read file: {e}")))?;
        runtime().block_on(async move {
            let upload = tokio::time::timeout(Duration::from_secs(600), client.upload(data, media_type, Default::default()))
                .await
                .map_err(|_| EngineError::Internal("Upload timed out".into()))?
                .map_err(|e| EngineError::Internal(e.to_string()))?;
            let caption = non_empty(caption);
            let mimetype = non_empty(mimetype);
            let thumb = if thumbnail.is_empty() { None } else { Some(thumbnail) };
            let ctx_info = || if forwarded { Some(Box::new(forward_context())) } else { None };
            let msg = match kind.as_str() {
                "image" => media::image_message(
                    upload,
                    ImageOptions { caption, mimetype, jpeg_thumbnail: thumb, context_info: ctx_info(), ..Default::default() },
                ),
                "video" => media::video_message(
                    upload,
                    VideoOptions {
                        caption,
                        mimetype,
                        jpeg_thumbnail: thumb,
                        duration_seconds: if duration_secs > 0 { Some(duration_secs) } else { None },
                        context_info: ctx_info(),
                        ..Default::default()
                    },
                ),
                "audio" => media::audio_message(
                    upload,
                    AudioOptions {
                        mimetype,
                        duration_seconds: if duration_secs > 0 { Some(duration_secs) } else { None },
                        ptt: Some(voice),
                        waveform: if voice && !waveform.is_empty() { Some(waveform) } else { None },
                        context_info: ctx_info(),
                        ..Default::default()
                    },
                ),
                _ => media::document_message(
                    upload,
                    DocumentOptions {
                        caption,
                        mimetype,
                        file_name: non_empty(file_name),
                        jpeg_thumbnail: thumb,
                        context_info: ctx_info(),
                        ..Default::default()
                    },
                ),
            };
            tokio::time::timeout(Duration::from_secs(60), client.send_message(&jid, msg))
                .await
                .map_err(|_| EngineError::Internal("Send timed out".into()))?
                .map(|sent| sent.message_id)
                .map_err(|e| EngineError::Internal(e.to_string()))
        })
    }

    /// Download + decrypt an incoming attachment to `dest_path` (streamed to disk, written
    /// to `<dest>.part` first). Blocks; call from a background thread.
    pub fn download_media(&self, media: MediaInfo, dest_path: String) -> Result<(), EngineError> {
        let client = self.connected_client()?;
        let media_type = media_type_of(&media.kind)?;
        let params = DownloadParams::encrypted(
            media.direct_path.clone(),
            &media.media_key,
            &media.file_sha256,
            &media.file_enc_sha256,
            media.file_length,
            media_type,
        );
        let tmp = format!("{dest_path}.part");
        let file = std::fs::OpenOptions::new()
            .create(true)
            .write(true)
            .truncate(true)
            .open(&tmp)
            .map_err(|e| EngineError::Internal(format!("Cannot write file: {e}")))?;
        let result = runtime().block_on(async {
            tokio::time::timeout(
                Duration::from_secs(900),
                client.download_from_params_to_writer(&params, file),
            )
            .await
        });
        match result {
            Ok(Ok(_)) => std::fs::rename(&tmp, &dest_path)
                .map_err(|e| EngineError::Internal(format!("Cannot save file: {e}"))),
            Ok(Err(e)) => {
                let _ = std::fs::remove_file(&tmp);
                Err(EngineError::Internal(e.to_string()))
            }
            Err(_) => {
                let _ = std::fs::remove_file(&tmp);
                Err(EngineError::Internal("Download timed out".into()))
            }
        }
    }

    /// Send a read receipt. `sender_jid` is the message author for groups, empty for 1:1 chats.
    pub fn mark_read(
        &self,
        chat_jid: String,
        sender_jid: String,
        message_ids: Vec<String>,
    ) -> Result<(), EngineError> {
        let chat: Jid = chat_jid
            .parse()
            .map_err(|e| EngineError::Invalid(format!("Invalid chat id: {e}")))?;
        let sender: Option<Jid> = if sender_jid.is_empty() {
            None
        } else {
            Some(
                sender_jid
                    .parse()
                    .map_err(|e| EngineError::Invalid(format!("Invalid sender id: {e}")))?,
            )
        };
        let client = self.connected_client()?;
        runtime().block_on(async move {
            let ids: Vec<&str> = message_ids.iter().map(String::as_str).collect();
            tokio::time::timeout(
                Duration::from_secs(20),
                client.mark_as_read(&chat, sender.as_ref(), &ids),
            )
            .await
            .map_err(|_| EngineError::Internal("Read receipt timed out".into()))?
            .map_err(|e| EngineError::Internal(e.to_string()))
        })
    }

    /// Stop and delete the local session database.
    pub fn clear_session(&self) -> Result<(), EngineError> {
        self.stop();
        for name in ["whatsapp.db", "whatsapp.db-wal", "whatsapp.db-shm", "whatsapp.db-journal"] {
            match std::fs::remove_file(self.data_dir.join(name)) {
                Ok(()) => {}
                Err(e) if e.kind() == std::io::ErrorKind::NotFound => {}
                Err(e) => return Err(EngineError::Internal(e.to_string())),
            }
        }
        Ok(())
    }
}

async fn run_bot(
    db: PathBuf,
    phone: Option<String>,
    listener: Arc<dyn EngineListener>,
    slot: ClientSlot,
) -> anyhow::Result<()> {
    // NOTE: pass the store by value; `Arc<SqliteStore>` does not implement `Backend` in 0.7.0.
    let store = SqliteStore::new(db.to_string_lossy().as_ref())
        .await
        .map_err(|e| anyhow::anyhow!("{e}"))?;

    let mut builder = Bot::builder()
        .with_backend(store)
        .with_transport_factory(TokioWebSocketTransportFactory::new())
        .with_http_client(UreqHttpClient::new())
        .with_runtime(TokioRuntime);

    if let Some(phone_number) = phone {
        builder = builder.with_pair_code(PairCodeOptions {
            phone_number,
            // User decision: register as an Electron companion (see docs/known-limitations.md).
            platform_id: Some(CompanionWebClientType::Electron),
            ..Default::default()
        });
    }

    let msg_listener = listener.clone();
    let bot = builder
        .on_message(move |ctx| {
            let l = msg_listener.clone();
            async move {
                let info = &ctx.info;
                if let Some(target) = revoke_target(&ctx.message) {
                    l.on_event(EngineEvent::MessageRevoked {
                        chat_id: info.source.chat.to_string(),
                        message_id: target,
                    });
                    return;
                }
                if let Some(ev) = message_event(
                    info.source.chat.to_string(),
                    info.source.sender.to_string(),
                    info.id.clone(),
                    info.timestamp.timestamp_millis(),
                    info.source.is_from_me,
                    info.source.is_group,
                    info.push_name.clone(),
                    &ctx.message,
                    false,
                ) {
                    l.on_event(ev);
                }
            }
        })
        .on_event(move |event, _client| {
            let l = listener.clone();
            async move { forward(&l, &event) }
        })
        .build()
        .await
        .map_err(|e| anyhow::anyhow!("{e}"))?;

    if let Ok(mut g) = slot.lock() {
        *g = Some(bot.client());
    }
    // Runs until logout or `Client::disconnect`.
    bot.run().await;
    if let Ok(mut g) = slot.lock() {
        *g = None;
    }
    Ok(())
}

fn forward(l: &Arc<dyn EngineListener>, ev: &Event) {
    let out = match ev {
        Event::PairingCode(pc) => EngineEvent::PairingCode {
            code: pc.code.clone(),
            timeout_secs: pc.timeout.as_secs(),
        },
        Event::Receipt(r) => {
            let kind = match r.r#type {
                ReceiptType::Delivered => "delivered",
                ReceiptType::Read | ReceiptType::Played => "read",
                _ => return,
            };
            EngineEvent::ReceiptReceived {
                chat_id: r.source.chat.to_string(),
                message_ids: r.message_ids.clone(),
                kind: kind.into(),
            }
        }
        Event::HistorySync(lazy) => {
            forward_history(l, lazy);
            return;
        }
        Event::PairSuccess(_) => EngineEvent::Paired,
        Event::PairError(e) => EngineEvent::PairFailed { reason: format!("{e:?}") },
        Event::Connected(_) => EngineEvent::Connected,
        Event::Disconnected(_) => EngineEvent::Disconnected,
        Event::LoggedOut(_) => EngineEvent::LoggedOut,
        Event::ConnectFailure(e) => EngineEvent::Fatal { reason: format!("{e:?}") },
        Event::TemporaryBan(e) => EngineEvent::Fatal { reason: format!("{e:?}") },
        _ => return,
    };
    l.on_event(out);
}

impl Engine {
    fn connected_client(&self) -> Result<Arc<Client>, EngineError> {
        self.client
            .lock()
            .ok()
            .and_then(|g| g.clone())
            .ok_or_else(|| EngineError::Internal("Not connected".into()))
    }
}

fn non_empty(s: String) -> Option<String> {
    if s.is_empty() { None } else { Some(s) }
}

fn media_type_of(kind: &str) -> Result<MediaType, EngineError> {
    match kind {
        "image" => Ok(MediaType::Image),
        "video" => Ok(MediaType::Video),
        "audio" => Ok(MediaType::Audio),
        "document" => Ok(MediaType::Document),
        other => Err(EngineError::Invalid(format!("Unsupported media kind: {other}"))),
    }
}

#[allow(clippy::too_many_arguments)]
fn media_info(
    kind: &str,
    mimetype: Option<String>,
    file_name: Option<String>,
    caption: Option<String>,
    file_length: Option<u64>,
    direct_path: Option<String>,
    media_key: Option<Vec<u8>>,
    file_sha256: Option<Vec<u8>>,
    file_enc_sha256: Option<Vec<u8>>,
    thumbnail: Option<Vec<u8>>,
    duration_secs: Option<u32>,
    voice: bool,
) -> MediaInfo {
    MediaInfo {
        kind: kind.into(),
        mimetype: mimetype.unwrap_or_default(),
        file_name: file_name.unwrap_or_default(),
        caption: caption.unwrap_or_default(),
        file_length: file_length.unwrap_or(0),
        direct_path: direct_path.unwrap_or_default(),
        media_key: media_key.unwrap_or_default(),
        file_sha256: file_sha256.unwrap_or_default(),
        file_enc_sha256: file_enc_sha256.unwrap_or_default(),
        thumbnail: thumbnail.unwrap_or_default(),
        duration_secs: duration_secs.unwrap_or(0),
        voice,
    }
}

fn view_once_marker() -> MediaInfo {
    media_info("viewonce", None, None, None, None, None, None, None, None, None, None, false)
}

/// Image / video / audio / document attachments. View-once media is reported as a distinct kind
/// with no keys: it is never downloaded (WhatsApp's access restriction is respected).
fn extract_media(msg: &wa::Message) -> Option<MediaInfo> {
    if msg.view_once_message.is_set() || msg.view_once_message_v2.is_set() {
        return Some(view_once_marker());
    }
    if msg.image_message.is_set() {
        let m = msg.image_message.clone().unwrap();
        if m.view_once.unwrap_or(false) {
            return Some(view_once_marker());
        }
        return Some(media_info(
            "image", m.mimetype, None, m.caption, m.file_length, m.direct_path, m.media_key,
            m.file_sha256, m.file_enc_sha256, m.jpeg_thumbnail, None, false,
        ));
    }
    if msg.video_message.is_set() {
        let m = msg.video_message.clone().unwrap();
        if m.view_once.unwrap_or(false) {
            return Some(view_once_marker());
        }
        return Some(media_info(
            "video", m.mimetype, None, m.caption, m.file_length, m.direct_path, m.media_key,
            m.file_sha256, m.file_enc_sha256, m.jpeg_thumbnail, m.seconds, false,
        ));
    }
    if msg.audio_message.is_set() {
        let m = msg.audio_message.clone().unwrap();
        let voice = m.ptt.unwrap_or(false);
        return Some(media_info(
            "audio", m.mimetype, None, None, m.file_length, m.direct_path, m.media_key,
            m.file_sha256, m.file_enc_sha256, None, m.seconds, voice,
        ));
    }
    if msg.document_message.is_set() {
        let m = msg.document_message.clone().unwrap();
        let name = m.file_name.or(m.title);
        return Some(media_info(
            "document", m.mimetype, name, m.caption, m.file_length, m.direct_path, m.media_key,
            m.file_sha256, m.file_enc_sha256, m.jpeg_thumbnail, None, false,
        ));
    }
    None
}

/// The id of the message a "delete for everyone" protocol message points at.
fn revoke_target(msg: &wa::Message) -> Option<String> {
    let pm = msg.protocol_message.as_option()?;
    if pm.r#type != Some(wa::message::protocol_message::Type::REVOKE) {
        return None;
    }
    pm.key.as_option()?.id.clone()
}

/// Builds the app-level event for a text/media message (live or from history sync).
#[allow(clippy::too_many_arguments)]
fn message_event(
    chat_id: String,
    sender_id: String,
    message_id: String,
    timestamp_ms: i64,
    from_me: bool,
    is_group: bool,
    push_name: String,
    msg: &wa::Message,
    historical: bool,
) -> Option<EngineEvent> {
    let text = msg.text_content().map(str::to_string);
    let media = extract_media(msg);
    if text.is_none() && media.is_none() {
        return None;
    }
    let (reply_to_id, reply_to_sender, reply_to_text) = extract_quote(msg);
    Some(EngineEvent::MessageReceived {
        chat_id,
        sender_id,
        message_id,
        text: text.unwrap_or_default(),
        timestamp_ms,
        from_me,
        is_group,
        push_name,
        media,
        reply_to_id,
        reply_to_sender,
        reply_to_text,
        historical,
    })
}

/// Replays a history sync blob as ordinary message events (flagged `historical`),
/// plus chat names and contact push names.
fn forward_history(l: &Arc<dyn EngineListener>, lazy: &LazyHistorySync) {
    let Some(hs) = lazy.get() else {
        return;
    };

    let mut names = Vec::new();
    for p in hs.pushnames.iter() {
        if let (Some(id), Some(name)) = (p.id.clone(), p.pushname.clone()) {
            if !name.is_empty() {
                names.push(ContactName { jid: id, name });
            }
        }
    }
    if !names.is_empty() {
        l.on_event(EngineEvent::ContactNames { names });
    }

    for conv in hs.conversations.iter() {
        let chat_id = conv.id.clone();
        if chat_id.is_empty() {
            continue;
        }
        if let Some(name) = conv.name.clone().filter(|n| !n.is_empty()) {
            l.on_event(EngineEvent::ChatInfo { chat_id: chat_id.clone(), name });
        }
        let is_group = chat_id.ends_with("@g.us");
        for hsm in conv.messages.iter() {
            if !hsm.message.is_set() {
                continue;
            }
            let wmi = hsm.message.clone().unwrap();
            if !wmi.key.is_set() || !wmi.message.is_set() {
                continue;
            }
            let key = wmi.key.clone().unwrap();
            let id = key.id.clone().unwrap_or_default();
            if id.is_empty() {
                continue;
            }
            let from_me = key.from_me.unwrap_or(false);
            let sender = if is_group {
                key.participant.clone().unwrap_or_default()
            } else if from_me {
                String::new()
            } else {
                chat_id.clone()
            };
            let inner = wmi.message.clone().unwrap();
            if let Some(ev) = message_event(
                chat_id.clone(),
                sender,
                id,
                (wmi.message_timestamp.unwrap_or(0) as i64) * 1000,
                from_me,
                is_group,
                wmi.push_name.clone().unwrap_or_default(),
                &inner,
                true,
            ) {
                l.on_event(ev);
            }
        }
    }
}

fn quoted_label(q: &wa::Message) -> String {
    if q.image_message.is_set() {
        "[Photo]".into()
    } else if q.video_message.is_set() {
        "[Video]".into()
    } else if q.document_message.is_set() {
        "[File]".into()
    } else {
        String::new()
    }
}

/// (quoted message id, quoted author, quoted text) when this message is a text reply.
fn extract_quote(msg: &wa::Message) -> (String, String, String) {
    if !msg.extended_text_message.is_set() {
        return Default::default();
    }
    let et = msg.extended_text_message.clone().unwrap();
    if !et.context_info.is_set() {
        return Default::default();
    }
    let ci = et.context_info.clone().unwrap();
    let id = ci.stanza_id.clone().unwrap_or_default();
    if id.is_empty() {
        return Default::default();
    }
    let sender = ci.participant.clone().unwrap_or_default();
    let text = if ci.quoted_message.is_set() {
        let q = ci.quoted_message.clone().unwrap();
        q.text_content().map(str::to_string).unwrap_or_else(|| quoted_label(&q))
    } else {
        String::new()
    };
    (id, sender, text)
}
