# Known limitations

- **Companion identity: Electron.** Pairing registers as an Electron (desktop-type) companion via
  `PairCodeOptions.platform_id`. Android companion types need server-side attestation upstream and are not used.
  The official app lists this device as a desktop/web-type device.
- **Unofficial client.** Account restrictions or bans are possible.
- **Rust adapter partly verified.** Dependencies compile; adapter fixed against compiler errors (Backend by value, Arc<Event>, PairingCode struct). Kotlin side never compiled.
  signatures (`Bot::builder`, `with_runtime`, `Event` variants, `SqliteStore`) may need small fixes.
- **Cargo features unverified:** `SqliteStore` / transport re-exports assumed to be in default features.
- **Android build of the Rust tree unverified** (bundled SQLite and TLS crypto need NDK clang).
- **No background service yet.** The connection lives only while the process lives (Milestone 2: foreground service).
- **Storage:** session DB is in app-private storage (`filesDir/wa/whatsapp.db`), not Keystore-wrapped yet.
  Backups are excluded via manifest rules.
- **Linked-device rules:** the primary phone (official WhatsApp, user 1) must connect at least about every 14 days.
- **GrapheneOS profiles:** unverified whether user 0 keeps its connection alive and posts notifications while user 1 is active.
- **SIMD disabled.** Upstream's `simd` feature needs nightly Rust, so it is turned off (slower binary parsing only).
  If the build still pulls `simd` through another crate, switch CI to `dtolnay/rust-toolchain@nightly`.
- Upstream requires Rust >= 1.94 (edition 2024); CI uses the latest stable.

## Milestone 2 notes
- **Unverified:** `.on_message(...)` and `.on_event(...)` are both registered on the bot builder; I assume they coexist
  (upstream uses an event bus with multiple handlers). If messages never arrive, this is the first suspect.
- **Text only.** Media, reactions, edits and other message kinds are ignored (no placeholder).
- **No history sync.** The chat list starts empty and fills from messages received while connected (plus messages
  sent from your phone). Use "+" to start a chat by number.
- **Names:** contact names are WhatsApp push names seen on incoming messages; groups are titled "Group".
- **No delivery/read receipts.** Sent messages show a time once the server accepted them.
- **Chats are stored unencrypted** in app-private storage (Room), like the session DB.
- **Background:** foreground service (`specialUse`), boot start, reconnect on network change. Battery-optimization
  exemption is requested from Settings. Behaviour while GrapheneOS user 1 is active is untested.
- Sending to `@lid` chats and to phone-number chats created via "+" is untested.
- Failed sends show "failed to send"; there is no retry button yet.

## Milestone 3 notes
- **Signing:** builds are now signed with the fixed key in `signing/classic.p12`, so updates install over each other.
  The first install of this version needs one uninstall of the old (randomly signed) build. Keep the repo private.
- **Unverified API details:** media builders, `download_from_params_to_writer`, `mark_as_read` and the
  `Event::Receipt` shape come from the 0.7.0 docs; `Client::upload(data, MediaType)` and the `MediaType` variant names
  (Image/Video/Document) were not confirmed. View-once detection uses proto field names that may need adjusting.
- **Media:** images, videos and documents only (no audio/voice notes, stickers, GIF special-casing).
  Uploads are read into memory: 64 MB limit. Received media is downloaded on tap, not automatically.
  Images show inline; videos/documents open in an external app via a FileProvider.
- **View-once** messages are shown as a placeholder and never downloaded.
- **Pickers:** the system photo picker and document picker are used; no storage/media permissions are requested.
- **Share target:** the app appears in the share sheet for files and text. Choose a chat, confirm, send.
- **Read receipts:** sent for incoming messages only while the chat is on screen and the app is visible
  (toggle in Settings). Ticks: one = sent, two = delivered, two (blue) = read. Receipts are matched by message id.
- **Contacts:** local names only (long-press a chat, or the chat menu): rename, hide (comes back on a new message),
  delete (local only). Nothing is written to the address book or to WhatsApp.
- Room database was migrated from version 1 to 2 (adds columns; existing chats are kept).

## Milestone 4 notes
- **Read ticks** use a fixed blue (#34B7F1), not the theme colour. Sent/delivered ticks stay grey.
- **Animation:** conversations slide in/out horizontally (170 ms). Android's swipe-back gesture is enabled via
  `enableOnBackInvokedCallback`; on Android 13+ you may need "Predictive back animations" in developer options.
- **Statuses:** status@broadcast messages are ignored for now (they used to show up as a chat called "status";
  that chat is removed on start). Viewing/replying to statuses is planned for the next milestone.
- **Groups:** the real group name is fetched once via `groups().get_metadata` when the first message of a group arrives
  (placeholder "Group" until then). Sender names come from push names. No group admin features, no participant list UI.
- **Replies:** text replies quote the original text (media quotes as "[Photo]" / "[Video]" / "[File]"). Quoting our own
  messages omits the author id (own JID is not known to the app). Incoming replies to media are not parsed.
- **Delete for everyone** works for own sent messages (revoke). Deletions by other people are not applied yet.
- **Forward** reuses the "Share to…" chooser (media must be downloaded first). Superseded in M6: forwards now carry the "Forwarded" label.
- **Retry:** tap a failed message. **Auto-download:** received photos up to 8 MB (Settings switch).
- **Unverified API details:** `RevokeType` import path, `ExtendedTextMessage` / `ContextInfo` field shapes,
  `groups().get_metadata`, and `buffa` 0.9.1 matching upstream.
- Room database migrated 2 -> 3 (reply columns).

## Milestone 5 notes
- **Gestures:** swipe a message right = reply, left = forward. Long-press starts multi-select; tap to add more.
  Selection actions: reply (one message), forward, copy, delete (for me / for everyone if all are yours).
  Forwarding several messages sends their texts as one draft and media as an attachment batch.
- **Voice notes:** recorded in the app as ogg/opus (MediaRecorder), 5 minute limit, tap mic -> Send/Cancel.
  The microphone permission is checked and requested on every recording, never remembered, so GrapheneOS
  "Ask every time" works. Recording stops if the app goes to the background (the note is kept as "Voice note ... Send/Discard").
  No waveform is sent. Received voice notes (<= 4 MB) are downloaded automatically and played with MediaPlayer.
- **Audio files** picked from the file picker are sent as plain audio messages (not voice notes).
- **Statuses:** stored for 24 h, shown from a "Status updates" row at the top of Chats. Image, video and text statuses
  are viewable (auto-advance 5 s, tap zones). Replying sends a quoted message to the poster's chat with
  `remote_jid = status@broadcast`; whether WhatsApp renders it as a status reply is UNVERIFIED. Viewing sends a "viewed"
  receipt only if read receipts are enabled. You cannot post statuses.
- **History sync:** the initial/recent history WhatsApp sends to new linked devices is imported (text and media messages,
  flagged historical: no notifications, no read receipts, no unread badges). Chat names and contact push names from it
  are stored and used for titles. What WhatsApp sends is limited and arrives in chunks right after linking or reconnecting.
- **Unverified API details:** `LazyHistorySync::get()` shape, `Conversation.name`, `HistorySync.pushnames`,
  `WebMessageInfo.push_name`, `MediaType::Audio`, `ContextInfo.remote_jid`.
- Room database migrated 3 -> 4 (voice/duration/reply-chat columns, contacts table).

## Milestone 6 notes
- **Statuses:** the "Status updates" row is replaced by a horizontal strip of contacts at the top of Chats (ring = unseen,
  unseen first, then newest). Tapping one opens the same status viewer as before; the separate status list screen was removed.
- **Communities tab (browse only):** lists the communities this account is in (`community().get_participating`);
  tapping one expands its groups (`community().get_subgroups`: announcement group, general chat, others). Tapping a group
  opens its conversation (a hidden local chat row is created if needed, it shows in Chats once a message arrives or is sent).
  Needs a connection; the list is fetched when the tab is first opened and on the refresh button, and is not stored.
  Groups you have not joined appear in the list but their conversation stays empty (no join/leave/member UI), and
  announcement groups only accept messages from admins. UNVERIFIED: the MEX query behind `get_subgroups` against the live server.
- **Media viewer:** tapping a downloaded photo/video opens a full-screen viewer that pages through all downloaded
  photos/videos of that chat. Photos: pinch / double-tap zoom, tap toggles the top bar. Videos: Media3 ExoPlayer
  (new dependencies `media3-exoplayer`, `media3-ui` 1.5.1), only the visible page plays, paused when the app goes to the background.
  **Save** copies the file to Pictures/WhatsApp Classic or Movies/WhatsApp Classic through MediaStore (no permission needed).
  **Open with** shows the system chooser. Documents still open directly in another app. The status viewer keeps its own VideoView.
- **Unverified API details:** `Community::get_participating` / `get_subgroups` field names (`subject`, `participant_count`,
  `is_default_sub_group`, `is_general_chat`), PlayerView with the DeviceDefault theme, pager vs. zoom gesture hand-off.
- **Forwarding:** pick a chat in "Share to…" and every selected message is sent right away, each as its own message with the
  "Forwarded" label (`ContextInfo.is_forwarded` + `forwarding_score = 1`); our own copy shows "↪ Forwarded". Media is
  re-uploaded (not reused); a media message keeps its caption; voice notes stay voice notes (without waveform). Items that
  cannot be forwarded (not downloaded, deleted, view-once) are skipped with a toast. Share-ins from other apps still land in a
  draft / attachment dialog. Incoming "Forwarded" labels are not parsed. UNVERIFIED: `ContextInfo` field names and types.
- **Deleted for everyone (incoming):** the engine now emits `MessageRevoked` for a protocol REVOKE message; the message becomes
  "This message was deleted", its media files are removed and the chat preview is refreshed. Status updates deleted by the
  poster disappear from the strip/viewer. UNVERIFIED: that upstream 0.7.0 delivers revoke protocol messages to `on_message`
  (and that group/ephemeral-wrapped revokes are not hidden inside another wrapper). A notification that is already showing is not withdrawn.
- **Status video:** the status viewer now plays video with Media3 (no controls, advances at the end or on error, pauses while
  you type a reply or the app is in the background). Fixes consecutive video statuses replaying the first one's player. The player view is inflated from `status_player_view.xml` with a TextureView surface, because a SurfaceView showed a blank picture (audio only) when the video finished downloading while the status was already open. UNVERIFIED on a device.
- Room database migrated 2 -> 3 (reply columns).

## Milestone 5 notes
- **Gestures:** swipe a message right = reply, left = forward. Long-press starts multi-select; tap to add more.
  Selection actions: reply (one message), forward, copy, delete (for me / for everyone if all are yours).
  Forwarding several messages sends their texts as one draft and media as an attachment batch.
- **Voice notes:** recorded in the app as ogg/opus (MediaRecorder), 5 minute limit, tap mic -> Send/Cancel.
  The microphone permission is checked and requested on every recording, never remembered, so GrapheneOS
  "Ask every time" works. Recording stops if the app goes to the background (the note is kept as "Voice note ... Send/Discard").
  No waveform is sent. Received voice notes (<= 4 MB) are downloaded automatically and played with MediaPlayer.
- **Audio files** picked from the file picker are sent as plain audio messages (not voice notes).
- **Statuses:** stored for 24 h, shown from a "Status updates" row at the top of Chats. Image, video and text statuses
  are viewable (auto-advance 5 s, tap zones). Replying sends a quoted message to the poster's chat with
  `remote_jid = status@broadcast`; whether WhatsApp renders it as a status reply is UNVERIFIED. Viewing sends a "viewed"
  receipt only if read receipts are enabled. You cannot post statuses.
- **History sync:** the initial/recent history WhatsApp sends to new linked devices is imported (text and media messages,
  flagged historical: no notifications, no read receipts, no unread badges). Chat names and contact push names from it
  are stored and used for titles. What WhatsApp sends is limited and arrives in chunks right after linking or reconnecting.
- **Unverified API details:** `LazyHistorySync::get()` shape, `Conversation.name`, `HistorySync.pushnames`,
  `WebMessageInfo.push_name`, `MediaType::Audio`, `ContextInfo.remote_jid`.
- Room database migrated 3 -> 4 (voice/duration/reply-chat columns, contacts table).

## Milestone 6 notes
- **Statuses:** the "Status updates" row is replaced by a horizontal strip of contacts at the top of Chats (ring = unseen,
  unseen first, then newest). Tapping one opens the same status viewer as before; the separate status list screen was removed.
- **Communities tab (browse only):** lists the communities this account is in (`community().get_participating`);
  tapping one expands its groups (`community().get_subgroups`: announcement group, general chat, others). Tapping a group
  opens its conversation (a hidden local chat row is created if needed, it shows in Chats once a message arrives or is sent).
  Needs a connection; the list is fetched when the tab is first opened and on the refresh button, and is not stored.
  Groups you have not joined appear in the list but their conversation stays empty (no join/leave/member UI), and
  announcement groups only accept messages from admins. UNVERIFIED: the MEX query behind `get_subgroups` against the live server.
- **Media viewer:** tapping a downloaded photo/video opens a full-screen viewer that pages through all downloaded
  photos/videos of that chat. Photos: pinch / double-tap zoom, tap toggles the top bar. Videos: Media3 ExoPlayer
  (new dependencies `media3-exoplayer`, `media3-ui` 1.5.1), only the visible page plays, paused when the app goes to the background.
  **Save** copies the file to Pictures/WhatsApp Classic or Movies/WhatsApp Classic through MediaStore (no permission needed).
  **Open with** shows the system chooser. Documents still open directly in another app. The status viewer keeps its own VideoView.
- **Unverified API details:** `Community::get_participating` / `get_subgroups` field names (`subject`, `participant_count`,
  `is_default_sub_group`, `is_general_chat`), PlayerView with the DeviceDefault theme, pager vs. zoom gesture hand-off.
- **Forward label:** forwarded text and media are sent with `ContextInfo.is_forwarded` + `forwarding_score = 1`, so
  WhatsApp shows "Forwarded". Our own forwarded messages show "↪ Forwarded" in the bubble. Still the "Share to…" chooser (one
  chat at a time); media is re-uploaded, not reused; several selected texts are joined into one forwarded message;
  editing the forwarded text before sending turns it into a normal message. Incoming "Forwarded" labels are not parsed.
  UNVERIFIED: `ContextInfo.is_forwarded` / `forwarding_score` field names and types.
- Room database migrated 4 -> 5 (`forwarded` column).
- Version 0.6.0 (versionCode 6).
- **Audio mimetype:** picked .ogg/.opus/.oga files are relabelled `audio/ogg; codecs=opus` before sending (official WhatsApp
  expects that exact string). UNVERIFIED as the cause of picked Ogg/Opus files not arriving. Recorded voice notes are now
  encoded with `MediaCodec` (Opus, 16 kHz mono, 24 kbit/s) and written into Ogg pages by our own muxer (`OggOpusRecorder`)
  with a 64-value waveform, replacing `MediaRecorder`. The muxing logic was checked off-device (ported to Python, accepted by
  ffprobe/ffmpeg, CRCs match ffmpeg-made pages); the Android encoder/AudioRecord side is UNVERIFIED on a device, as is
  whether official WhatsApp now accepts the notes.
- **Auto-scroll:** a new message scrolls the conversation to the newest one only when you were already at the bottom or sent it
  yourself; while you read older messages the list stays put (no "new messages" button yet). Re-keyed pending messages
  (send acknowledgement) do not count as new. UNVERIFIED on a device.
- **Unread indicators:** chat rows with unread messages get a green count badge, a green time and a bold title. Opening a chat
  with unread messages shows an "N unread messages" divider above the first one (it stays until you leave the chat); with 6 or
  more unread the chat opens at the divider instead of the bottom. UNVERIFIED on a device (scroll offset heuristic).
- **Channels (inside the Communities tab):** a collapsible "Channels" slot lists the followed channels as cards (name,
  follower count, latest post). It jumps to the top of the tab while any channel has posts newer than what you last saw and
  returns to the bottom once read. Tapping a card opens the channel's posts (cards, newest first, "Load older posts").
  Unread = fetched posts newer than the last seen server id (stored in SharedPreferences `channels`); a channel's existing
  posts count as read the first time it is loaded. Limits: fetched on tab open / refresh only (no live updates); only the
  latest 5 posts per channel are checked for unread (so the count can cap at 5); media posts show their inline thumbnail only
  (channel media is not downloadable yet); no channel avatars; no follow/unfollow/mute. UNVERIFIED: engine code against
  `newsletter().list_subscribed()` / `get_messages()` (field names were checked against the 0.7.0 source, not compiled).
- **Channel/community error text:** engine errors for these four calls now include the underlying cause (e.g. "IQ request failed: ..."),
  because upstream's `MexError::Request` alone only prints "IQ request failed".
