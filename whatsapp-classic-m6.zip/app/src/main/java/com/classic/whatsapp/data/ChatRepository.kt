package com.classic.whatsapp.data

import android.content.Context
import android.database.sqlite.SQLiteConstraintException
import androidx.room.withTransaction
import com.classic.whatsapp.messaging.Community
import com.classic.whatsapp.messaging.CommunityGroup
import com.classic.whatsapp.messaging.MediaDescriptor
import com.classic.whatsapp.messaging.MessagingClient
import com.classic.whatsapp.messaging.MessagingEvent
import java.io.File
import java.util.UUID
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow

private const val STATUS_CHAT_ID = "status@broadcast"
private const val STATUS_TTL_MS = 24L * 60 * 60 * 1000

class ChatRepository(
    private val ctx: Context,
    private val db: AppDatabase,
    private val client: MessagingClient,
    private val settings: AppSettings,
) {
    private val dao = db.dao()

    val chats: Flow<List<ChatEntity>> = dao.observeChats()
    fun chat(chatId: String): Flow<ChatEntity?> = dao.observeChat(chatId)
    fun messages(chatId: String): Flow<List<MessageEntity>> = dao.observeMessages(chatId)

    /** Chat whose screen is currently composed. */
    val openChatId = MutableStateFlow<String?>(null)

    /** True while the activity is visible (read receipts/notifications depend on it). */
    val foreground = MutableStateFlow(false)

    /** Message ids being downloaded right now. */
    val downloading = MutableStateFlow<Set<String>>(emptySet())
    val lastError = MutableStateFlow<String?>(null)

    fun viewing(chatId: String) = foreground.value && openChatId.value == chatId

    suspend fun openChat(chatId: String) {
        openChatId.value = chatId
    }

    fun closeChat() {
        openChatId.value = null
    }

    suspend fun title(chatId: String): String = dao.getChat(chatId)?.displayTitle ?: chatId.substringBefore('@')

    /** Creates (or un-hides) a 1:1 chat for a phone number given as digits with country code. */
    suspend fun createChat(digits: String): String {
        val chatId = "$digits@s.whatsapp.net"
        val existing = dao.getChat(chatId)
        if (existing == null) {
            dao.upsertChat(ChatEntity(chatId, digits, false, "", System.currentTimeMillis(), 0))
        } else if (existing.hidden) {
            dao.setHidden(chatId, false)
        }
        return chatId
    }

    // ---- local contact editing ----

    suspend fun rename(chatId: String, name: String) = dao.setCustomName(chatId, name.trim())

    suspend fun hide(chatId: String) = dao.setHidden(chatId, true)

    suspend fun delete(chatId: String) {
        for (m in dao.getMessages(chatId)) {
            if (m.mediaPath.isNotBlank()) File(m.mediaPath).delete()
            if (m.thumbPath.isNotBlank()) File(m.thumbPath).delete()
        }
        db.withTransaction {
            dao.deleteMessagesOf(chatId)
            dao.deleteChat(chatId)
        }
    }

    // ---- incoming ----

    /** Returns true if the message was new. Historical messages never notify or send receipts. */
    suspend fun onIncoming(m: MessagingEvent.MessageReceived): Boolean {
        val media = m.media
        val thumbPath = if (media != null && media.thumbnail.isNotEmpty()) {
            MediaFiles.saveThumb(ctx, m.messageId, media.thumbnail)
        } else ""
        val known = dao.contactName(m.chatId)
        val senderName = if (m.fromMe) "" else m.pushName.ifBlank {
            dao.contactName(m.senderId) ?: m.senderId.substringBefore('@')
        }
        return db.withTransaction {
            val msg = buildEntity(m, media, thumbPath, senderName)
            if (dao.insertMessage(msg) == -1L) {
                if (thumbPath.isNotEmpty()) File(thumbPath).delete()
                return@withTransaction false
            }
            val defaultTitle = when {
                m.chatId.endsWith("@newsletter") -> "Channel"
                m.isGroup -> "Group"
                else -> m.chatId.substringBefore('@')
            }
            val existing = dao.getChat(m.chatId)
            val base = existing ?: ChatEntity(
                chatId = m.chatId, title = defaultTitle, isGroup = m.isGroup,
                lastText = "", lastTimestamp = 0, unread = 0,
            )
            val title = when {
                !m.isGroup && !m.fromMe && m.pushName.isNotBlank() -> m.pushName
                existing == null -> known ?: defaultTitle
                (existing.title == defaultTitle || existing.title == m.chatId.substringBefore('@')) && known != null -> known
                else -> existing.title
            }
            val countsUnread = !m.fromMe && !m.historical && !viewing(m.chatId)
            val isNewest = m.timestampMs >= base.lastTimestamp
            dao.upsertChat(
                base.copy(
                    title = title,
                    isGroup = m.isGroup,
                    lastText = if (isNewest) previewWithPrefix(msg) else base.lastText,
                    lastTimestamp = if (isNewest) m.timestampMs else base.lastTimestamp,
                    unread = base.unread + if (countsUnread) 1 else 0,
                    hidden = if (m.historical) base.hidden else false, // live message brings a hidden chat back
                ),
            )
            true
        }
    }

    /** Status updates (status@broadcast): stored like messages but never shown as a chat. */
    suspend fun onStatus(m: MessagingEvent.MessageReceived): Boolean {
        val media = m.media
        val thumbPath = if (media != null && media.thumbnail.isNotEmpty()) {
            MediaFiles.saveThumb(ctx, m.messageId, media.thumbnail)
        } else ""
        val name = if (m.fromMe) "You" else m.pushName.ifBlank { dao.contactName(m.senderId) ?: m.senderId.substringBefore('@') }
        val msg = buildEntity(m, media, thumbPath, name).copy(incomingRead = m.fromMe)
        val inserted = dao.insertMessage(msg) != -1L
        if (!inserted && thumbPath.isNotEmpty()) File(thumbPath).delete()
        return inserted
    }

    private fun buildEntity(m: MessagingEvent.MessageReceived, media: MediaDescriptor?, thumbPath: String, senderName: String) =
        MessageEntity(
            chatId = m.chatId,
            messageId = m.messageId,
            senderId = m.senderId,
            senderName = senderName,
            text = m.text.ifBlank { media?.caption.orEmpty() },
            timestamp = m.timestampMs,
            fromMe = m.fromMe,
            status = STATUS_SENT,
            kind = media?.kind ?: "text",
            thumbPath = thumbPath,
            mimeType = media?.mimeType.orEmpty(),
            fileName = media?.fileName.orEmpty(),
            fileLength = media?.fileLength ?: 0,
            mediaRef = if (media != null && media.kind != "viewonce") media.toJson() else "",
            // history, and messages sent from our other devices, count as already read
            incomingRead = m.fromMe || m.historical,
            replyToId = m.replyToId,
            replyToSender = m.replyToSender,
            replyToText = m.replyToText,
            durationSecs = media?.durationSecs ?: 0,
            voice = media?.voice ?: false,
        )

    // ---- history sync results ----

    suspend fun applyContactNames(names: List<Pair<String, String>>) {
        if (names.isEmpty()) return
        db.withTransaction {
            dao.upsertContacts(names.map { ContactEntity(it.first, it.second) })
            names.forEach { (jid, name) -> dao.renameIfDefault(jid, name, jid.substringBefore('@')) }
        }
    }

    suspend fun applyChatName(chatId: String, name: String) {
        dao.upsertContacts(listOf(ContactEntity(chatId, name)))
        dao.renameIfDefault(chatId, name, chatId.substringBefore('@'))
    }

    // ---- statuses ----

    /** Status updates from the last 24 hours, oldest first. */
    fun statuses(): Flow<List<MessageEntity>> = dao.observeStatuses(System.currentTimeMillis() - STATUS_TTL_MS)

    suspend fun purgeExpiredStatuses() {
        val before = System.currentTimeMillis() - STATUS_TTL_MS
        for (m in dao.expiredStatuses(before)) {
            if (m.mediaPath.isNotBlank()) File(m.mediaPath).delete()
            if (m.thumbPath.isNotBlank()) File(m.thumbPath).delete()
        }
        dao.deleteExpiredStatuses(before)
    }

    /** Sends the "viewed" receipt for a status (respects the read-receipts setting). */
    suspend fun markStatusViewed(m: MessageEntity) {
        if (m.fromMe || m.incomingRead) return
        if (settings.sendReadReceipts.value) {
            try {
                client.markRead(STATUS_CHAT_ID, m.senderId, listOf(m.messageId))
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                return // retried the next time it is viewed
            }
        }
        dao.markIncomingRead(STATUS_CHAT_ID, listOf(m.messageId))
    }

    suspend fun mediaPath(chatId: String, messageId: String): String? =
        dao.getMessage(chatId, messageId)?.mediaPath?.takeIf { it.isNotBlank() && File(it).exists() }

    suspend fun onReceipt(e: MessagingEvent.ReceiptReceived) {
        if (e.messageIds.isEmpty()) return
        if (e.kind == "read") dao.markReadByPeer(e.messageIds) else dao.markDelivered(e.messageIds)
    }

    /**
     * Marks the chat read: sends read receipts (if enabled) for incoming messages not yet
     * acknowledged and clears the unread counter. Only call while the chat is on screen.
     */
    suspend fun markConversationRead(chatId: String) {
        val pending = dao.unreadIncoming(chatId)
        if (pending.isNotEmpty()) {
            val done = mutableListOf<String>()
            if (settings.sendReadReceipts.value) {
                pending.groupBy { it.senderId }.forEach { (sender, msgs) ->
                    val ids = msgs.map { it.messageId }
                    try {
                        client.markRead(chatId, if (chatId.endsWith("@g.us")) sender else "", ids)
                        done += ids
                    } catch (e: CancellationException) {
                        throw e
                    } catch (e: Exception) {
                        // not connected right now; retried the next time the chat is viewed
                    }
                }
            } else {
                done += pending.map { it.messageId }
            }
            if (done.isNotEmpty()) dao.markIncomingRead(chatId, done)
        }
        dao.markRead(chatId)
    }

    // ---- outgoing ----

    suspend fun sendText(chatId: String, text: String, replyTo: MessageEntity? = null, quotedChat: String = "", forwarded: Boolean = false) {
        val tempId = "local-" + UUID.randomUUID()
        val now = System.currentTimeMillis()
        val msg = MessageEntity(
            chatId, tempId, "", "", text, now, true, STATUS_SENDING,
            replyToId = replyTo?.messageId.orEmpty(),
            replyToSender = if (replyTo == null || replyTo.fromMe) "" else replyTo.senderId,
            replyToText = replyTo?.let { quoteText(it) }.orEmpty(),
            replyToChat = quotedChat,
            forwarded = forwarded,
        )
        db.withTransaction {
            dao.insertMessage(msg)
            touchChat(chatId, "You: $text", now)
        }
        deliver(msg)
    }

    /** Sends a recorded voice note (ogg/opus) that lives in [path]. */
    suspend fun sendVoice(chatId: String, path: String, secs: Int, waveform: ByteArray = ByteArray(0)) {
        val f = PendingFile(path, "voice.ogg", "audio/ogg; codecs=opus", File(path).length())
        sendMedia(chatId, f, "", voice = true, durationOverride = secs, waveform = waveform)
    }

    suspend fun sendMedia(chatId: String, f: PendingFile, caption: String, voice: Boolean = false, durationOverride: Int = 0, forwarded: Boolean = false, waveform: ByteArray = ByteArray(0)) {
        val src = File(f.path)
        val mime = MediaFiles.normalizeMime(f.mime, f.name)
        val kind = MediaFiles.kindOf(mime)
        val tempId = "local-" + UUID.randomUUID()
        val now = System.currentTimeMillis()
        val dest = File(MediaFiles.dir(ctx, "out"), MediaFiles.safe(tempId) + "." + MediaFiles.extension(mime, f.name))
        val file = try {
            src.copyTo(dest, overwrite = true)
            src.delete()
            dest
        } catch (e: Exception) {
            lastError.value = "Cannot read the file"
            return
        }
        // Kept beside the file so a retry can still send the waveform.
        if (voice && waveform.isNotEmpty()) runCatching { File(file.path + ".wf").writeBytes(waveform) }
        val thumb = MediaFiles.thumbnail(file, kind)
        val thumbPath = if (thumb.isNotEmpty()) MediaFiles.saveThumb(ctx, tempId, thumb) else ""
        val msg = MessageEntity(
            chatId = chatId, messageId = tempId, senderId = "", senderName = "",
            text = caption, timestamp = now, fromMe = true, status = STATUS_SENDING,
            kind = kind, mediaPath = file.path, thumbPath = thumbPath, mimeType = mime,
            fileName = f.name, fileLength = file.length(),
            durationSecs = when {
                durationOverride > 0 -> durationOverride
                kind == "video" || kind == "audio" -> MediaFiles.videoDurationSecs(file)
                else -> 0
            },
            voice = voice,
            forwarded = forwarded,
        )
        db.withTransaction {
            dao.insertMessage(msg)
            touchChat(chatId, "You: " + preview(msg), now)
        }
        deliver(msg)
    }

    /** Tap on a "failed to send" message. */
    suspend fun retry(chatId: String, messageId: String) {
        val m = dao.getMessage(chatId, messageId) ?: return
        if (m.status != STATUS_FAILED) return
        lastError.value = null
        dao.setStatus(chatId, messageId, STATUS_SENDING)
        deliver(m.copy(status = STATUS_SENDING))
    }

    private suspend fun deliver(m: MessageEntity) {
        try {
            val realId = if (m.kind == "text") {
                client.sendText(m.chatId, m.text, m.replyToId, m.replyToSender, m.replyToText, m.replyToChat, m.forwarded)
            } else {
                val file = File(m.mediaPath)
                if (!file.exists()) throw IllegalStateException("File is gone")
                if (file.length() > MediaFiles.MAX_UPLOAD_BYTES) throw IllegalStateException("File too large (limit 64 MB)")
                val thumb = if (m.thumbPath.isNotBlank() && File(m.thumbPath).exists()) File(m.thumbPath).readBytes() else ByteArray(0)
                val wf = if (m.voice) runCatching { File(m.mediaPath + ".wf").readBytes() }.getOrDefault(ByteArray(0)) else ByteArray(0)
                client.sendMedia(
                    m.chatId, m.kind, m.mediaPath, m.mimeType, m.fileName, m.text, thumb,
                    m.durationSecs, m.voice, m.forwarded, wf,
                )
            }
            rekey(m.chatId, m.messageId, realId)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            lastError.value = e.message ?: "Sending failed"
            dao.setStatus(m.chatId, m.messageId, STATUS_FAILED)
        }
    }

    // ---- delete / group names ----

    /** Removes the message on this device only. */
    suspend fun deleteForMe(chatId: String, messageId: String) {
        dao.getMessage(chatId, messageId)?.let {
            if (it.mediaPath.isNotBlank()) { File(it.mediaPath).delete(); File(it.mediaPath + ".wf").delete() }
            if (it.thumbPath.isNotBlank()) File(it.thumbPath).delete()
        }
        dao.deleteMessage(chatId, messageId)
        refreshPreview(chatId)
    }

    /** Incoming messages not yet acknowledged, read before [markConversationRead] clears them (for the "N unread" divider). */
    suspend fun unreadSnapshot(chatId: String): List<MessageEntity> = dao.unreadIncoming(chatId)

    /** Forwards each item to [chatId] as its own message, in order, with the "Forwarded" label. */
    suspend fun forwardAll(chatId: String, items: List<ForwardItem>) {
        for (it in items) {
            val f = it.file
            if (f == null) sendText(chatId, it.text, forwarded = true)
            else sendMedia(chatId, f, it.text, voice = it.voice, durationOverride = it.durationSecs, forwarded = true)
        }
    }

    /** Someone deleted a message for everyone: drop its content and files, keep the "deleted" placeholder. */
    suspend fun onRevoked(e: MessagingEvent.MessageRevoked) {
        val m = dao.getMessage(e.chatId, e.messageId) ?: return
        if (m.kind == "deleted") return
        if (m.mediaPath.isNotBlank()) { File(m.mediaPath).delete(); File(m.mediaPath + ".wf").delete() }
        if (m.thumbPath.isNotBlank()) File(m.thumbPath).delete()
        dao.markDeleted(e.chatId, e.messageId)
        refreshPreview(e.chatId)
    }

    /** Deletes one of our own sent messages for everyone, then marks it deleted locally. */
    suspend fun deleteForEveryone(chatId: String, messageId: String) {
        try {
            client.revokeMessage(chatId, messageId)
            dao.getMessage(chatId, messageId)?.let {
                if (it.mediaPath.isNotBlank()) File(it.mediaPath).delete()
                if (it.thumbPath.isNotBlank()) File(it.thumbPath).delete()
            }
            dao.markDeleted(chatId, messageId)
            refreshPreview(chatId)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            lastError.value = "Delete failed: ${e.message ?: "unknown error"}"
        }
    }

    /** Looks up the real name of a group whose title is still the placeholder. */
    suspend fun ensureGroupTitle(chatId: String) {
        val chat = dao.getChat(chatId) ?: return
        if (!chat.isGroup || chat.title != "Group") return
        try {
            val subject = client.groupSubject(chatId)
            if (subject.isNotBlank()) dao.setTitle(chatId, subject)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            // not connected / not available; tried again on the next incoming group message
        }
    }

    private suspend fun refreshPreview(chatId: String) {
        val last = dao.lastMessage(chatId)
        if (last == null) dao.setLast(chatId, "", dao.getChat(chatId)?.lastTimestamp ?: 0)
        else dao.setLast(chatId, (if (last.fromMe) "You: " else "") + preview(last), last.timestamp)
    }

    fun quoteText(m: MessageEntity): String = when {
        m.text.isNotBlank() -> m.text
        m.kind == "image" -> "[Photo]"
        m.kind == "video" -> "[Video]"
        m.kind == "document" -> m.fileName.ifBlank { "[File]" }
        m.kind == "audio" -> if (m.voice) "[Voice message]" else "[Audio]"
        else -> ""
    }

    // ---- communities / channels ----

    val communityCache = CommunityCache(File(ctx.filesDir, "communities-cache.json"))

    /** Channels are stored like chats (their posts arrive as incoming messages) but listed in the Communities tab. */
    val channelChats: Flow<List<ChatEntity>> = dao.observeChannels()

    fun clearCommunityData() = communityCache.clear()

    /** Reading a channel only clears the local unread state: no read receipts are sent for channel posts. */
    suspend fun markChannelRead(chatId: String) {
        val ids = dao.unreadIncoming(chatId).map { it.messageId }
        if (ids.isNotEmpty()) dao.markIncomingRead(chatId, ids)
        dao.markRead(chatId)
    }

    /**
     * Names the followed channels (and adds those without posts yet) from the server's list. The posts themselves come
     * from incoming messages, so a failure here only leaves default names.
     */
    suspend fun syncChannels() {
        val list = try {
            client.channels()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            return
        }
        for (ch in list) {
            val name = ch.name.ifBlank { "Channel" }
            if (dao.getChat(ch.id) == null) dao.upsertChat(ChatEntity(ch.id, name, true, "", 0L, 0))
            else dao.renameIfDefault(ch.id, name, "Channel")
        }
    }

    // ---- communities ----

    suspend fun communities(): List<Community> = client.communities()

    suspend fun communityGroups(communityId: String): List<CommunityGroup> = client.communityGroups(communityId)

    /**
     * Makes sure a local chat exists for a community group so its conversation can be opened.
     * A newly created row stays hidden (no empty entry in Chats) until a message arrives or is sent.
     */
    suspend fun openCommunityGroup(g: CommunityGroup): String {
        val existing = dao.getChat(g.id)
        if (existing == null) {
            dao.upsertChat(ChatEntity(g.id, g.name.ifBlank { "Group" }, true, "", System.currentTimeMillis(), 0, hidden = true))
        } else if (existing.title == "Group" && g.name.isNotBlank()) {
            dao.setTitle(g.id, g.name)
        }
        return g.id
    }

    // ---- received media ----

    suspend fun downloadMedia(chatId: String, messageId: String) {
        if (messageId in downloading.value) return
        val m = dao.getMessage(chatId, messageId) ?: return
        val ref = MediaDescriptor.fromJson(m.mediaRef) ?: return
        val dest = File(MediaFiles.dir(ctx, "in"), MediaFiles.safe(messageId) + "." + MediaFiles.extension(m.mimeType, m.fileName))
        downloading.value = downloading.value + messageId
        lastError.value = null
        try {
            client.downloadMedia(ref, dest.path)
            dao.setMediaPath(chatId, messageId, dest.path)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            lastError.value = "Download failed: ${e.message ?: "unknown error"}"
        } finally {
            downloading.value = downloading.value - messageId
        }
    }

    // ---- helpers ----

    private suspend fun rekey(chatId: String, tempId: String, realId: String) {
        try {
            dao.rekeyMessage(chatId, tempId, realId, STATUS_SENT)
        } catch (e: SQLiteConstraintException) {
            dao.deleteMessage(chatId, tempId) // the echo of our own message was stored first
        }
    }

    private suspend fun touchChat(chatId: String, lastText: String, ts: Long) {
        val existing = dao.getChat(chatId)
            ?: ChatEntity(chatId, chatId.substringBefore('@'), chatId.endsWith("@g.us"), "", 0, 0)
        dao.upsertChat(existing.copy(lastText = lastText, lastTimestamp = ts, hidden = false))
    }

    private fun previewWithPrefix(m: MessageEntity) = (if (m.fromMe) "You: " else "") + preview(m)

    private fun preview(m: MessageEntity): String = when (m.kind) {
        "image" -> "[Photo]" + if (m.text.isNotBlank()) " ${m.text}" else ""
        "video" -> "[Video]" + if (m.text.isNotBlank()) " ${m.text}" else ""
        "document" -> "[File] " + m.fileName.ifBlank { m.text }
        "viewonce" -> "[View once message]"
        "audio" -> if (m.voice) "[Voice message]" else "[Audio] " + m.fileName
        "deleted" -> "This message was deleted"
        else -> m.text
    }
}
