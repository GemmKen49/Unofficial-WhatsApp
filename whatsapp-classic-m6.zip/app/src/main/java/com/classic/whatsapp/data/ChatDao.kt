package com.classic.whatsapp.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface ChatDao {
    @Query("SELECT * FROM chats WHERE hidden = 0 AND chatId != 'status@broadcast' ORDER BY lastTimestamp DESC")
    fun observeChats(): Flow<List<ChatEntity>>

    @Query("SELECT * FROM chats WHERE chatId = :chatId")
    fun observeChat(chatId: String): Flow<ChatEntity?>

    @Query("SELECT * FROM chats WHERE chatId = :chatId")
    suspend fun getChat(chatId: String): ChatEntity?

    @Query("SELECT * FROM messages WHERE chatId = :chatId ORDER BY timestamp ASC")
    fun observeMessages(chatId: String): Flow<List<MessageEntity>>

    @Query("SELECT * FROM messages WHERE chatId = :chatId")
    suspend fun getMessages(chatId: String): List<MessageEntity>

    @Query("SELECT * FROM messages WHERE chatId = :chatId AND messageId = :id")
    suspend fun getMessage(chatId: String, id: String): MessageEntity?

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertMessage(m: MessageEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertChat(c: ChatEntity)

    @Query("UPDATE chats SET unread = 0 WHERE chatId = :chatId")
    suspend fun markRead(chatId: String)

    @Query("UPDATE chats SET customName = :name WHERE chatId = :chatId")
    suspend fun setCustomName(chatId: String, name: String)

    @Query("UPDATE chats SET hidden = :hidden WHERE chatId = :chatId")
    suspend fun setHidden(chatId: String, hidden: Boolean)

    @Query("DELETE FROM chats WHERE chatId = :chatId")
    suspend fun deleteChat(chatId: String)

    @Query("DELETE FROM messages WHERE chatId = :chatId")
    suspend fun deleteMessagesOf(chatId: String)

    @Query("UPDATE messages SET messageId = :newId, status = :status WHERE chatId = :chatId AND messageId = :oldId")
    suspend fun rekeyMessage(chatId: String, oldId: String, newId: String, status: Int)

    @Query("UPDATE messages SET status = :status WHERE chatId = :chatId AND messageId = :id")
    suspend fun setStatus(chatId: String, id: String, status: Int)

    @Query("UPDATE messages SET mediaPath = :path WHERE chatId = :chatId AND messageId = :id")
    suspend fun setMediaPath(chatId: String, id: String, path: String)

    @Query("DELETE FROM messages WHERE chatId = :chatId AND messageId = :id")
    suspend fun deleteMessage(chatId: String, id: String)

    @Query("SELECT * FROM messages WHERE chatId = :chatId AND fromMe = 0 AND incomingRead = 0")
    suspend fun unreadIncoming(chatId: String): List<MessageEntity>

    @Query("UPDATE messages SET incomingRead = 1 WHERE chatId = :chatId AND messageId IN (:ids)")
    suspend fun markIncomingRead(chatId: String, ids: List<String>)

    // Receipts are matched by message id only: the chat id a receipt carries can differ
    // (phone-number vs LID addressing) from the one we sent to.
    @Query("UPDATE messages SET status = 3 WHERE messageId IN (:ids) AND fromMe = 1 AND status IN (0, 1)")
    suspend fun markDelivered(ids: List<String>)

    @Query("UPDATE messages SET status = 4 WHERE messageId IN (:ids) AND fromMe = 1 AND status IN (0, 1, 3)")
    suspend fun markReadByPeer(ids: List<String>)

    @Query("SELECT * FROM messages WHERE chatId = :chatId ORDER BY timestamp DESC LIMIT 1")
    suspend fun lastMessage(chatId: String): MessageEntity?

    @Query("UPDATE messages SET kind = 'deleted', text = '', mediaPath = '', thumbPath = '', mediaRef = '' WHERE chatId = :chatId AND messageId = :id")
    suspend fun markDeleted(chatId: String, id: String)

    @Query("UPDATE chats SET title = :title WHERE chatId = :chatId")
    suspend fun setTitle(chatId: String, title: String)

    @Query("UPDATE chats SET lastText = :text, lastTimestamp = :ts WHERE chatId = :chatId")
    suspend fun setLast(chatId: String, text: String, ts: Long)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertContacts(list: List<ContactEntity>)

    @Query("SELECT name FROM contacts WHERE jid = :jid")
    suspend fun contactName(jid: String): String?

    @Query("UPDATE chats SET title = :name WHERE chatId = :chatId AND customName = '' AND (title = :defaultTitle OR title = 'Group')")
    suspend fun renameIfDefault(chatId: String, name: String, defaultTitle: String)

    @Query("SELECT * FROM messages WHERE chatId = 'status@broadcast' AND kind != 'deleted' AND timestamp > :since ORDER BY timestamp ASC")
    fun observeStatuses(since: Long): Flow<List<MessageEntity>>

    @Query("SELECT * FROM messages WHERE chatId = 'status@broadcast' AND timestamp <= :before")
    suspend fun expiredStatuses(before: Long): List<MessageEntity>

    @Query("DELETE FROM messages WHERE chatId = 'status@broadcast' AND timestamp <= :before")
    suspend fun deleteExpiredStatuses(before: Long)
}
