package com.classic.whatsapp.ui.communities

import android.graphics.BitmapFactory
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.classic.whatsapp.ClassicApp
import com.classic.whatsapp.messaging.ChannelPost
import com.classic.whatsapp.ui.formatTime
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.launch

private const val PAGE = 20
private val BadgeGreen = Color(0xFF25D366)

/** Green count badge, same look as in the chat list. */
@Composable
internal fun CountBadge(count: Int, modifier: Modifier = Modifier) {
    Box(
        modifier.defaultMinSize(minWidth = 20.dp, minHeight = 20.dp).background(BadgeGreen, CircleShape).padding(horizontal = 6.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(if (count > 99) "99+" else count.toString(), style = MaterialTheme.typography.labelSmall, color = Color.White, fontWeight = FontWeight.Bold)
    }
}

internal fun mediaLabel(p: ChannelPost): String = when (p.mediaKind) {
    "image" -> "Photo"
    "video" -> "Video"
    "audio" -> "Audio"
    "" -> ""
    else -> p.fileName.ifBlank { "File" }
}

/** The post's inline thumbnail (if any) as a small rounded square; nothing is drawn for text posts. */
@Composable
internal fun PostThumb(p: ChannelPost, modifier: Modifier) {
    val bmp = remember(p.messageId, p.serverId) {
        if (p.thumbnail.isEmpty()) null else BitmapFactory.decodeByteArray(p.thumbnail, 0, p.thumbnail.size)?.asImageBitmap()
    }
    if (bmp != null) {
        Image(bmp, contentDescription = null, contentScale = ContentScale.Crop, modifier = modifier.clip(RoundedCornerShape(8.dp)))
    }
}

/** All posts of one channel as cards, newest first. Opening it marks the channel as read. */
@Composable
fun ChannelScreen(channelId: String, onBack: () -> Unit) {
    val repo = (LocalContext.current.applicationContext as ClassicApp).repo
    val scope = rememberCoroutineScope()
    var posts by remember(channelId) { mutableStateOf<List<ChannelPost>>(emptyList()) }
    var loading by remember(channelId) { mutableStateOf(true) }
    var error by remember(channelId) { mutableStateOf<String?>(null) }
    var more by remember(channelId) { mutableStateOf(true) }

    suspend fun load(before: Long) {
        loading = true
        error = null
        try {
            val page = repo.channelPosts(channelId, PAGE, before)
            more = page.isNotEmpty()
            posts = (posts + page).distinctBy { it.serverId }.sortedByDescending { it.serverId }
            if (before == 0L) posts.firstOrNull()?.let { repo.markChannelSeen(channelId, it.serverId) }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            error = e.message ?: "Could not load posts"
        } finally {
            loading = false
        }
    }
    LaunchedEffect(channelId) { load(0) }

    Column(Modifier.fillMaxSize().statusBarsPadding()) {
        Row(Modifier.fillMaxWidth().padding(end = 16.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back") }
            Text(
                repo.channelName(channelId).ifBlank { "Channel" },
                style = MaterialTheme.typography.titleLarge,
                maxLines = 1,
                modifier = Modifier.weight(1f),
            )
        }
        LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 24.dp)) {
            items(posts, key = { it.serverId }) { PostCard(it) }
            item {
                Box(Modifier.fillMaxWidth().padding(16.dp), contentAlignment = Alignment.Center) {
                    when {
                        loading -> CircularProgressIndicator(Modifier.size(24.dp))
                        error != null -> Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(error!!, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error)
                            TextButton(onClick = { scope.launch { load(posts.minOfOrNull { it.serverId } ?: 0L) } }) { Text("Retry") }
                        }
                        posts.isEmpty() -> Text("No posts yet.", style = MaterialTheme.typography.bodyMedium)
                        more -> TextButton(onClick = { scope.launch { load(posts.minOf { it.serverId }) } }) { Text("Load older posts") }
                    }
                }
            }
        }
    }
}

@Composable
private fun PostCard(p: ChannelPost) {
    Card(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 6.dp)) {
        Column(Modifier.padding(12.dp)) {
            if (p.thumbnail.isNotEmpty()) {
                PostThumb(p, Modifier.fillMaxWidth().height(180.dp))
                Text(
                    mediaLabel(p) + " (opening channel media is not supported yet)",
                    style = MaterialTheme.typography.labelSmall,
                    modifier = Modifier.padding(top = 4.dp, bottom = 6.dp),
                )
            } else if (p.mediaKind.isNotEmpty()) {
                Text(mediaLabel(p) + " (opening channel media is not supported yet)", style = MaterialTheme.typography.labelMedium)
            }
            if (p.text.isNotBlank()) Text(p.text, style = MaterialTheme.typography.bodyMedium)
            Text(
                formatTime(p.timestampMs),
                style = MaterialTheme.typography.labelSmall,
                modifier = Modifier.padding(top = 6.dp).align(Alignment.End),
            )
        }
    }
}
