package com.classic.whatsapp.ui.communities

import android.widget.Toast
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.classic.whatsapp.ClassicApp
import com.classic.whatsapp.data.MessageEntity
import com.classic.whatsapp.ui.conversation.rememberBitmap
import com.classic.whatsapp.ui.formatTime
import java.io.File
import kotlinx.coroutines.launch

private val BadgeGreen = Color(0xFF25D366)

/** Green count badge, same look as in the chat list. */
@Composable
internal fun CountBadge(count: Int, modifier: Modifier = Modifier) {
    Box(
        modifier.defaultMinSize(minWidth = 20.dp, minHeight = 20.dp).background(BadgeGreen, CircleShape).padding(horizontal = 6.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(if (count > 99) "99+" else count.toString(), style = MaterialTheme.typography.labelSmall, color = Color.White, fontWeight = FontWeight.Bold)
    }
}

private fun hasFile(m: MessageEntity) = m.mediaPath.isNotBlank() && File(m.mediaPath).exists()

/**
 * The posts received from one channel (stored like messages), newest first, as cards. Opening it clears the unread count
 * locally; no read receipts are sent for channel posts.
 */
@Composable
fun ChannelScreen(chatId: String, onBack: () -> Unit, onViewMedia: (String) -> Unit) {
    val ctx = LocalContext.current
    val repo = (ctx.applicationContext as ClassicApp).repo
    val scope = rememberCoroutineScope()
    val chat by repo.chat(chatId).collectAsState(initial = null)
    val messages by repo.messages(chatId).collectAsState(initial = emptyList())
    val downloading by repo.downloading.collectAsState()
    val foreground by repo.foreground.collectAsState()
    LaunchedEffect(chatId, foreground, messages.size) { if (foreground) repo.markChannelRead(chatId) }

    Column(Modifier.fillMaxSize().statusBarsPadding()) {
        Row(Modifier.fillMaxWidth().padding(end = 16.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back") }
            Text(chat?.displayTitle ?: "Channel", style = MaterialTheme.typography.titleLarge, maxLines = 1, modifier = Modifier.weight(1f))
        }
        if (messages.isEmpty()) {
            Box(Modifier.fillMaxSize().padding(32.dp), contentAlignment = Alignment.Center) {
                Text("No posts received yet.", style = MaterialTheme.typography.bodyMedium)
            }
        } else {
            LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 24.dp)) {
                items(messages.asReversed(), key = { it.messageId }) { m ->
                    PostCard(m, downloading = m.messageId in downloading) {
                        if (hasFile(m)) {
                            onViewMedia(m.messageId)
                        } else {
                            scope.launch {
                                repo.downloadMedia(chatId, m.messageId)
                                repo.lastError.value?.let { Toast.makeText(ctx, it, Toast.LENGTH_SHORT).show() }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun PostCard(m: MessageEntity, downloading: Boolean, onOpenMedia: () -> Unit) {
    Card(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 6.dp)) {
        Column(Modifier.padding(12.dp)) {
            if (m.kind == "deleted") {
                Text("This post was deleted", style = MaterialTheme.typography.bodyMedium, fontStyle = FontStyle.Italic)
            } else {
                if (m.kind == "image" || m.kind == "video") {
                    val shown = if (hasFile(m)) m.mediaPath else m.thumbPath
                    val bmp = if (shown.isNotBlank()) rememberBitmap(shown, 1200) else null
                    Box(
                        Modifier.fillMaxWidth().height(200.dp).clip(RoundedCornerShape(8.dp))
                            .background(MaterialTheme.colorScheme.surfaceVariant).clickable(onClick = onOpenMedia),
                        contentAlignment = Alignment.Center,
                    ) {
                        if (bmp != null) Image(bmp, contentDescription = null, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
                        when {
                            downloading -> CircularProgressIndicator()
                            !hasFile(m) -> Text(
                                if (m.kind == "video") "Tap to download video" else "Tap to download photo",
                                style = MaterialTheme.typography.labelMedium,
                                color = Color.White,
                                modifier = Modifier.background(Color.Black.copy(alpha = 0.5f), RoundedCornerShape(8.dp)).padding(8.dp),
                            )
                            m.kind == "video" -> Text("▶", style = MaterialTheme.typography.headlineMedium, color = Color.White)
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                } else if (m.kind != "text") {
                    Text(
                        when (m.kind) {
                            "audio" -> "Audio"
                            else -> m.fileName.ifBlank { "File" }
                        },
                        style = MaterialTheme.typography.labelMedium,
                    )
                }
                if (m.text.isNotBlank()) Text(m.text, style = MaterialTheme.typography.bodyMedium)
            }
            Text(
                formatTime(m.timestamp),
                style = MaterialTheme.typography.labelSmall,
                modifier = Modifier.padding(top = 6.dp).align(Alignment.End),
            )
        }
    }
}
