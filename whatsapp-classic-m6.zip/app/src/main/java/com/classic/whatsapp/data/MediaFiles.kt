package com.classic.whatsapp.data

import android.content.ActivityNotFoundException
import android.content.ClipData
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaMetadataRetriever
import android.media.ThumbnailUtils
import android.net.Uri
import android.os.Environment
import android.provider.MediaStore
import android.provider.OpenableColumns
import android.util.Size
import android.webkit.MimeTypeMap
import androidx.core.content.FileProvider
import java.io.ByteArrayOutputStream
import java.io.File
import java.util.UUID

/** A local file waiting to be sent (picked or shared). */
data class PendingFile(val path: String, val name: String, val mime: String, val size: Long)

/** Files handed to the app from another app's share sheet. */
/** One message to forward: text, or a copied file with its caption in [text]. */
data class ForwardItem(
    val text: String = "",
    val file: PendingFile? = null,
    val voice: Boolean = false,
    val durationSecs: Int = 0,
)

/** Content to send: shared in from another app ([files]/[text], goes to a draft) or a forward ([forward], sent at once). */
data class ShareRequest(
    val files: List<PendingFile>,
    val text: String,
    val target: String? = null,
    val forward: List<ForwardItem> = emptyList(),
)

object MediaFiles {
    const val MAX_UPLOAD_BYTES = 64L * 1024 * 1024

    fun dir(ctx: Context, sub: String): File = File(ctx.filesDir, "media/$sub").apply { mkdirs() }

    fun safe(s: String) = s.replace(Regex("[^A-Za-z0-9._-]"), "_")

    fun kindOf(mime: String) = when {
        mime.startsWith("image/") -> "image"
        mime.startsWith("video/") -> "video"
        mime.startsWith("audio/") -> "audio"
        else -> "document"
    }

    /**
     * WhatsApp only plays Ogg audio labelled exactly `audio/ogg; codecs=opus`. Pickers often report plain
     * `audio/ogg`, `application/ogg` or nothing for .ogg/.opus/.oga files, so those are relabelled
     * (the file itself must really be Opus).
     */
    fun normalizeMime(mime: String, name: String): String {
        val ext = name.substringAfterLast('.', "").lowercase()
        val m = mime.lowercase().substringBefore(';').trim()
        val oggLike = m == "audio/ogg" || m == "audio/opus" || m == "application/ogg" || m == "application/octet-stream" || m.isEmpty()
        return if (ext in setOf("ogg", "opus", "oga") && oggLike) "audio/ogg; codecs=opus" else mime
    }

    fun extension(mime: String, name: String): String {
        val fromName = name.substringAfterLast('.', "")
        if (fromName.isNotBlank() && fromName.length <= 5) return fromName
        return MimeTypeMap.getSingleton().getExtensionFromMimeType(mime) ?: "bin"
    }

    private const val PUBLIC_FOLDER = "WhatsApp Classic"

    /**
     * Copies a downloaded image/video into shared storage (Pictures / Movies / WhatsApp Classic) via
     * MediaStore, so no storage permission is needed. Returns the folder it was saved to, or null on failure.
     */
    fun saveToGallery(ctx: Context, path: String, kind: String, mime: String, fileName: String): String? {
        val src = File(path)
        if (!src.exists()) return null
        val isVideo = kind == "video"
        val type = mime.ifBlank { if (isVideo) "video/mp4" else "image/jpeg" }
        val ext = extension(type, fileName)
        val name = fileName.ifBlank { (if (isVideo) "VID-" else "IMG-") + src.nameWithoutExtension + "." + ext }
        val folder = (if (isVideo) Environment.DIRECTORY_MOVIES else Environment.DIRECTORY_PICTURES) + "/" + PUBLIC_FOLDER
        val collection = if (isVideo) MediaStore.Video.Media.EXTERNAL_CONTENT_URI else MediaStore.Images.Media.EXTERNAL_CONTENT_URI
        val resolver = ctx.contentResolver
        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, name)
            put(MediaStore.MediaColumns.MIME_TYPE, type)
            put(MediaStore.MediaColumns.RELATIVE_PATH, folder)
            put(MediaStore.MediaColumns.IS_PENDING, 1)
        }
        val uri = resolver.insert(collection, values) ?: return null
        return try {
            resolver.openOutputStream(uri)?.use { out -> src.inputStream().use { it.copyTo(out) } } ?: throw IllegalStateException("no stream")
            resolver.update(uri, ContentValues().apply { put(MediaStore.MediaColumns.IS_PENDING, 0) }, null, null)
            folder
        } catch (e: Exception) {
            resolver.delete(uri, null, null)
            null
        }
    }

    /** Offers the file to other apps through a chooser. Returns false if nothing could be launched. */
    fun openWith(ctx: Context, path: String, mime: String): Boolean = try {
        val uri = FileProvider.getUriForFile(ctx, "${ctx.packageName}.files", File(path))
        val view = Intent(Intent.ACTION_VIEW)
            .setDataAndType(uri, mime.ifBlank { "*/*" })
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        view.clipData = ClipData.newRawUri("", uri)
        ctx.startActivity(Intent.createChooser(view, "Open with").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        true
    } catch (e: ActivityNotFoundException) {
        false
    } catch (e: Exception) {
        false
    }

    fun saveThumb(ctx: Context, id: String, bytes: ByteArray): String {
        val f = File(dir(ctx, "thumbs"), safe(id) + ".jpg")
        f.writeBytes(bytes)
        return f.path
    }

    /** Small JPEG preview for outgoing images/videos (empty if it cannot be made). */
    fun thumbnail(file: File, kind: String): ByteArray = try {
        val size = Size(160, 160)
        val bmp: Bitmap? = when (kind) {
            "image" -> ThumbnailUtils.createImageThumbnail(file, size, null)
            "video" -> ThumbnailUtils.createVideoThumbnail(file, size, null)
            else -> null
        }
        if (bmp == null) ByteArray(0)
        else ByteArrayOutputStream().also { bmp.compress(Bitmap.CompressFormat.JPEG, 60, it) }.toByteArray()
    } catch (e: Exception) {
        ByteArray(0)
    }

    fun videoDurationSecs(file: File): Int = try {
        val r = MediaMetadataRetriever()
        try {
            r.setDataSource(file.path)
            ((r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L) / 1000).toInt()
        } finally {
            r.release()
        }
    } catch (e: Exception) {
        0
    }

    /** Copies a content URI into the app cache so it can be uploaded later. */
    fun importUri(ctx: Context, uri: Uri): PendingFile? = try {
        val cr = ctx.contentResolver
        val mime = cr.getType(uri) ?: "application/octet-stream"
        var name = "file"
        cr.query(uri, null, null, null, null)?.use { c ->
            if (c.moveToFirst()) {
                val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (i >= 0) name = c.getString(i) ?: name
            }
        }
        val dir = File(ctx.cacheDir, "outgoing").apply { mkdirs() }
        val out = File(dir, UUID.randomUUID().toString() + "-" + safe(name))
        cr.openInputStream(uri)?.use { input -> out.outputStream().use { input.copyTo(it) } }
            ?: throw IllegalStateException("cannot open $uri")
        PendingFile(out.path, name, mime, out.length())
    } catch (e: Exception) {
        null
    }

    fun decodeSampled(path: String, maxSide: Int): Bitmap? = try {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(path, bounds)
        var sample = 1
        while (bounds.outWidth / sample > maxSide * 2 || bounds.outHeight / sample > maxSide * 2) sample *= 2
        BitmapFactory.decodeFile(path, BitmapFactory.Options().apply { inSampleSize = sample })
    } catch (e: Exception) {
        null
    }

    fun formatSize(bytes: Long): String = when {
        bytes <= 0 -> ""
        bytes < 1024 * 1024 -> "${(bytes / 1024).coerceAtLeast(1)} KB"
        else -> String.format("%.1f MB", bytes / 1024.0 / 1024.0)
    }
}
