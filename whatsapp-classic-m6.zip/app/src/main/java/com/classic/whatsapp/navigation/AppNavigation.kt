package com.classic.whatsapp.navigation

import android.net.Uri
import androidx.compose.animation.EnterTransition
import androidx.compose.animation.ExitTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.foundation.layout.consumeWindowInsets
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.MailOutline
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.classic.whatsapp.ClassicApp
import com.classic.whatsapp.R
import kotlinx.coroutines.launch
import com.classic.whatsapp.ui.chats.ChatsScreen
import com.classic.whatsapp.ui.communities.CommunitiesScreen
import com.classic.whatsapp.ui.media.MediaViewerScreen
import com.classic.whatsapp.ui.conversation.ConversationScreen
import com.classic.whatsapp.ui.pairing.PairingScreen
import com.classic.whatsapp.ui.settings.SettingsScreen
import com.classic.whatsapp.ui.share.ShareScreen
import com.classic.whatsapp.ui.status.StatusViewerScreen

private const val CHATS = "chats"
private const val SETTINGS = "settings"
private const val CHAT = "chat/{id}"
private const val SHARE = "share"
private const val COMMUNITIES = "communities"
private const val STATUS_VIEW = "status/{id}"
private const val MEDIA = "media/{chatId}/{id}"

/** Fast horizontal slide (Discord style) for opening/closing a conversation. */
private const val SLIDE_MS = 170
private fun isOverlay(route: String?) = route == CHAT || route == SHARE || route == STATUS_VIEW || route == MEDIA

private enum class Tab(val route: String, val label: String) {
    Chats(CHATS, "Chats"),
    Communities(COMMUNITIES, "Communities"),
    Settings(SETTINGS, "Settings"),
}

@Composable
fun AppRoot() {
    val app = LocalContext.current.applicationContext as ClassicApp
    val linked by app.session.linked.collectAsState()
    if (linked) MainScaffold() else PairingScreen()
}

@Composable
private fun MainScaffold() {
    val app = LocalContext.current.applicationContext as ClassicApp
    val nav = rememberNavController()
    val route = nav.currentBackStackEntryAsState().value?.destination?.route
    val request by app.openRequest.collectAsState()
    val share by app.pendingShare.collectAsState()
    val scope = rememberCoroutineScope()

    // Notification tap -> open that conversation.
    LaunchedEffect(request) {
        request?.let {
            nav.navigate("chat/${Uri.encode(it)}") { launchSingleTop = true }
            app.openRequest.value = null
        }
    }

    // Another app shared something with us -> choose a chat first.
    LaunchedEffect(share) {
        val s = share
        if (s != null && s.target == null) nav.navigate(SHARE) { launchSingleTop = true }
    }

    Scaffold(
        bottomBar = {
            if (route == CHATS || route == COMMUNITIES || route == SETTINGS) {
                NavigationBar {
                    Tab.entries.forEach { t ->
                        NavigationBarItem(
                            selected = route == t.route,
                            onClick = {
                                nav.navigate(t.route) {
                                    popUpTo(nav.graph.startDestinationId) { saveState = true }
                                    launchSingleTop = true
                                    restoreState = true
                                }
                            },
                            icon = {
                                when (t) {
                                    Tab.Chats -> Icon(Icons.Default.MailOutline, contentDescription = null)
                                    Tab.Communities -> Icon(painterResource(R.drawable.ic_communities), contentDescription = null)
                                    Tab.Settings -> Icon(Icons.Default.Settings, contentDescription = null)
                                }
                            },
                            label = { Text(t.label) },
                        )
                    }
                }
            }
        },
    ) { pad ->
        NavHost(
            nav,
            startDestination = CHATS,
            modifier = Modifier.padding(pad).consumeWindowInsets(pad),
            enterTransition = {
                if (isOverlay(targetState.destination.route)) slideInHorizontally(tween(SLIDE_MS)) { it }
                else EnterTransition.None
            },
            exitTransition = {
                if (isOverlay(targetState.destination.route)) slideOutHorizontally(tween(SLIDE_MS)) { -it / 4 }
                else ExitTransition.None
            },
            popEnterTransition = {
                if (isOverlay(initialState.destination.route)) slideInHorizontally(tween(SLIDE_MS)) { -it / 4 }
                else EnterTransition.None
            },
            popExitTransition = {
                if (isOverlay(initialState.destination.route)) slideOutHorizontally(tween(SLIDE_MS)) { it }
                else ExitTransition.None
            },
        ) {
            composable(CHATS) {
                Opaque {
                    ChatsScreen(
                        onOpen = { id -> nav.navigate("chat/${Uri.encode(id)}") },
                        onStatus = { id -> nav.navigate("status/${Uri.encode(id)}") },
                    )
                }
            }
            composable(SETTINGS) { Opaque { SettingsScreen() } }
            composable(COMMUNITIES) {
                Opaque { CommunitiesScreen(onOpenChat = { id -> nav.navigate("chat/${Uri.encode(id)}") }) }
            }
            composable(STATUS_VIEW, arguments = listOf(navArgument("id") { type = NavType.StringType })) { entry ->
                Opaque {
                    StatusViewerScreen(
                        senderId = Uri.decode(entry.arguments?.getString("id").orEmpty()),
                        onBack = { nav.popBackStack() },
                    )
                }
            }
            composable(SHARE) {
                Opaque { ShareScreen(
                    onChosen = { id ->
                        val s = app.pendingShare.value
                        if (s != null && s.forward.isNotEmpty()) {
                            // Forward: send every message now, each as its own forwarded message.
                            app.pendingShare.value = null
                            scope.launch { app.repo.forwardAll(id, s.forward) }
                        } else {
                            app.pendingShare.value = s?.copy(target = id)
                        }
                        nav.navigate("chat/${Uri.encode(id)}") {
                            popUpTo(SHARE) { inclusive = true }
                        }
                    },
                    onCancel = {
                        app.pendingShare.value = null
                        nav.popBackStack()
                    },
                ) }
            }
            composable(CHAT, arguments = listOf(navArgument("id") { type = NavType.StringType })) { entry ->
                Opaque {
                    ConversationScreen(
                        chatId = Uri.decode(entry.arguments?.getString("id").orEmpty()),
                        onBack = { nav.popBackStack() },
                        onViewMedia = { mid -> nav.navigate("media/${Uri.encode(entry.arguments?.getString("id").orEmpty())}/${Uri.encode(mid)}") },
                    )
                }
            }
            composable(
                MEDIA,
                arguments = listOf(
                    navArgument("chatId") { type = NavType.StringType },
                    navArgument("id") { type = NavType.StringType },
                ),
            ) { entry ->
                MediaViewerScreen(
                    chatId = Uri.decode(entry.arguments?.getString("chatId").orEmpty()),
                    messageId = Uri.decode(entry.arguments?.getString("id").orEmpty()),
                    onBack = { nav.popBackStack() },
                )
            }
        }
    }
}

@Composable
private fun Opaque(content: @Composable () -> Unit) {
    Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background, content = content)
}
