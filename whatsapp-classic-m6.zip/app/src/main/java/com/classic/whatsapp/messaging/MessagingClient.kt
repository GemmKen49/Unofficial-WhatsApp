package com.classic.whatsapp.messaging

import kotlinx.coroutines.flow.SharedFlow

class PairingException(message: String) : Exception(message)

/** A channel (newsletter) the account follows. */
data class Channel(val id: String, val name: String, val description: String, val subscribers: Long, val verified: Boolean)

/** One channel post; [mediaKind] is empty for text. Media is only described by [thumbnail], it cannot be opened yet. */
class ChannelPost(
    val serverId: Long,
    val messageId: String,
    val timestampMs: Long,
    val text: String,
    val mediaKind: String,
    val fileName: String,
    val thumbnail: ByteArray,
)

/** A community the account belongs to (the parent group, not a chat). */
data class Community(val id: String, val name: String)

/** A group linked to a community. [members] is 0 when unknown. */
data class CommunityGroup(val id: String, val name: String, val announcement: Boolean, val general: Boolean, val members: Int)

/** App-level messaging surface. Media/groups are added in later milestones. */
interface MessagingClient {
    val events: SharedFlow<MessagingEvent>
    val isRunning: Boolean

    /** Resume an existing linked-device session. */
    fun start()
    fun stop()

    /** Starts a fresh pairing attempt; returns when the code arrives. */
    suspend fun requestPairingCode(phoneNumber: String): MessagingEvent.PairingCode

    /** Sends a text message; returns the server-side message id. */
    suspend fun sendText(
        chatId: String,
        text: String,
        replyToId: String = "",
        replyToSender: String = "",
        replyToText: String = "",
        replyToChat: String = "",
        forwarded: Boolean = false,
    ): String

    /** Deletes one of our own messages for everyone. */
    suspend fun revokeMessage(chatId: String, messageId: String)

    /** Current name of a group chat. */
    suspend fun groupSubject(chatId: String): String

    /** Channels this account follows. */
    suspend fun channels(): List<Channel>

    /** Latest posts of a channel, newest first; [before] = server id to page back from (0 = latest). */
    suspend fun channelPosts(channelId: String, count: Int, before: Long = 0): List<ChannelPost>

    /** Communities this account participates in. */
    suspend fun communities(): List<Community>

    /** Groups linked to a community (announcement group first). */
    suspend fun communityGroups(communityId: String): List<CommunityGroup>

    /** Uploads a local file and sends it (kind: image | video | document); returns the message id. */
    suspend fun sendMedia(
        chatId: String,
        kind: String,
        path: String,
        mimeType: String,
        fileName: String,
        caption: String,
        thumbnail: ByteArray,
        durationSecs: Int,
        voice: Boolean = false,
        forwarded: Boolean = false,
        waveform: ByteArray = ByteArray(0),
    ): String

    /** Downloads and decrypts an attachment to [destPath]. */
    suspend fun downloadMedia(media: MediaDescriptor, destPath: String)

    /** Sends a read receipt. [senderId] is the author for groups, empty for 1:1 chats. */
    suspend fun markRead(chatId: String, senderId: String, messageIds: List<String>)

    /** Stops the engine and deletes the local session database. */
    suspend fun clearSession()
}
