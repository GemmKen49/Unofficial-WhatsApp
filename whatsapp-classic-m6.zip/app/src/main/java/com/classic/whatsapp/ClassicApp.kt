package com.classic.whatsapp

import android.app.Application
import android.content.Intent
import androidx.core.content.ContextCompat
import com.classic.whatsapp.data.AppDatabase
import com.classic.whatsapp.data.AppSettings
import com.classic.whatsapp.data.AudioPlayer
import com.classic.whatsapp.data.VoiceRecorder
import com.classic.whatsapp.data.ShareRequest
import com.classic.whatsapp.data.ChatRepository
import com.classic.whatsapp.data.SessionStore
import com.classic.whatsapp.messaging.MessagingClient
import com.classic.whatsapp.messaging.MessagingEvent
import com.classic.whatsapp.messaging.RustMessagingClient
import java.io.File
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

const val STATUS_CHAT = "status@broadcast"
private const val AUTO_DOWNLOAD_MAX_BYTES = 8L * 1024 * 1024
private const val VOICE_AUTO_MAX_BYTES = 4L * 1024 * 1024

class ClassicApp : Application() {
    lateinit var session: SessionStore
        private set
    lateinit var messaging: MessagingClient
        private set
    lateinit var db: AppDatabase
        private set
    lateinit var repo: ChatRepository
        private set
    lateinit var settings: AppSettings
        private set
    lateinit var voice: VoiceRecorder
        private set
    lateinit var player: AudioPlayer
        private set

    /** Files/text shared into the app from another app; consumed by the share screen. */
    val pendingShare = MutableStateFlow<ShareRequest?>(null)

    /** Chat id requested by a notification tap; consumed by the navigation host. */
    val openRequest = MutableStateFlow<String?>(null)

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private val _status = MutableStateFlow("Not connected")
    val status: StateFlow<String> = _status.asStateFlow()

    override fun onCreate() {
        super.onCreate()
        session = SessionStore(this)
        messaging = RustMessagingClient(File(filesDir, "wa"))
        db = AppDatabase.create(this)
        settings = AppSettings(this)
        voice = VoiceRecorder(this)
        player = AudioPlayer(CoroutineScope(SupervisorJob() + Dispatchers.Main))
        repo = ChatRepository(this, db, messaging, settings)
        Notifier.ensureChannels(this)

        // Status updates expire after 24 hours.
        scope.launch { repo.purgeExpiredStatuses() }

        scope.launch {
            messaging.events.collect { e ->
                when (e) {
                    is MessagingEvent.Paired -> {
                        session.setLinked(true)
                        _status.value = "Linked, connecting…"
                        ensureService() // app is in the foreground here, so this is allowed
                    }
                    is MessagingEvent.Connected -> _status.value = "Connected"
                    is MessagingEvent.Disconnected -> _status.value = "Disconnected, retrying…"
                    is MessagingEvent.LoggedOut -> {
                        session.setLinked(false)
                        stopService(Intent(this@ClassicApp, MessagingService::class.java))
                        _status.value = "Logged out from phone"
                    }
                    is MessagingEvent.Fatal -> _status.value = "Error: ${e.reason}"
                    is MessagingEvent.MessageReceived -> {
                        if (e.chatId == STATUS_CHAT) {
                            repo.onStatus(e)
                            return@collect
                        }
                        val isNew = repo.onIncoming(e)
                        if (!isNew || e.historical) return@collect // history never notifies
                        if (e.isGroup) launch { repo.ensureGroupTitle(e.chatId) }
                        if (!e.fromMe && e.media?.kind == "image" && settings.autoDownloadImages.value &&
                            e.media.fileLength in 1..AUTO_DOWNLOAD_MAX_BYTES
                        ) {
                            launch { repo.downloadMedia(e.chatId, e.messageId) }
                        }
                        // Voice notes are small: fetch them so they play instantly.
                        if (!e.fromMe && e.media?.kind == "audio" && e.media.voice && e.media.fileLength in 1..VOICE_AUTO_MAX_BYTES) {
                            launch { repo.downloadMedia(e.chatId, e.messageId) }
                        }
                        if (!e.fromMe && !repo.viewing(e.chatId)) {
                            val who = if (e.isGroup) "${e.pushName.ifBlank { e.senderId.substringBefore('@') }}: " else ""
                            val body = e.text.ifBlank {
                                when (e.media?.kind) {
                                    "image" -> "Photo"
                                    "video" -> "Video"
                                    "document" -> e.media.fileName.ifBlank { "File" }
                                    "audio" -> if (e.media.voice) "Voice message" else "Audio"
                                    "viewonce" -> "View once message"
                                    else -> ""
                                }
                            }
                            Notifier.message(this@ClassicApp, e.chatId, repo.title(e.chatId), who + body, e.timestampMs)
                        }
                    }
                    is MessagingEvent.ReceiptReceived -> repo.onReceipt(e)
                    is MessagingEvent.MessageRevoked -> repo.onRevoked(e)
                    is MessagingEvent.ChatInfo -> repo.applyChatName(e.chatId, e.name)
                    is MessagingEvent.ContactNames -> repo.applyContactNames(e.names)
                    else -> Unit
                }
            }
        }
        if (session.linked.value) _status.value = "Connecting…"
    }

    /** Starts the foreground service (which starts the engine) if this device is linked. */
    fun ensureService() {
        if (session.linked.value) {
            ContextCompat.startForegroundService(this, Intent(this, MessagingService::class.java))
        }
    }

    /** Disconnect, delete the Rust session and all local chats. */
    suspend fun clearEverything() {
        stopService(Intent(this, MessagingService::class.java))
        messaging.clearSession()
        withContext(Dispatchers.IO) { db.clearAllTables() }
        repo.clearCommunityData()
        session.setLinked(false)
        _status.value = "Not connected"
    }
}
