package com.classic.whatsapp.data

import android.util.Base64
import com.classic.whatsapp.messaging.Channel
import com.classic.whatsapp.messaging.ChannelPost
import com.classic.whatsapp.messaging.Community
import com.classic.whatsapp.messaging.CommunityGroup
import java.io.File
import org.json.JSONArray
import org.json.JSONObject

/**
 * Last known state of the Communities tab (communities, their groups, followed channels with their latest posts), kept in
 * one small JSON file so the tab can be shown offline and refreshed when a connection is available. Failures to read or
 * write are ignored: the cache is only a convenience.
 */
class CommunityCache(private val file: File) {
    class Data(
        val communities: List<Community>?,
        val groups: Map<String, List<CommunityGroup>>,
        val channels: List<Pair<Channel, List<ChannelPost>>>?,
    )

    private val lock = Any()

    fun load(): Data = synchronized(lock) {
        val root = read()
        Data(
            communities = root.optJSONArray("communities")?.objects()?.map { Community(it.getString("id"), it.getString("name")) },
            groups = root.optJSONObject("groups")?.let { g ->
                g.keys().asSequence().associateWith { id ->
                    g.getJSONArray(id).objects().map {
                        CommunityGroup(it.getString("id"), it.getString("name"), it.getBoolean("announcement"), it.getBoolean("general"), it.getInt("members"))
                    }
                }
            } ?: emptyMap(),
            channels = root.optJSONArray("channels")?.objects()?.map { o ->
                val c = Channel(o.getString("id"), o.getString("name"), o.getString("description"), o.getLong("subscribers"), o.getBoolean("verified"))
                c to o.getJSONArray("posts").objects().map { p ->
                    ChannelPost(
                        p.getLong("serverId"), p.getString("messageId"), p.getLong("timestampMs"), p.getString("text"),
                        p.getString("mediaKind"), p.getString("fileName"),
                        p.optString("thumb").let { if (it.isEmpty()) ByteArray(0) else Base64.decode(it, Base64.NO_WRAP) },
                    )
                }
            },
        )
    }

    /** Stores the community list; groups of communities that are no longer in it are dropped. */
    fun saveCommunities(list: List<Community>) = update { root ->
        root.put("communities", JSONArray(list.map { JSONObject().put("id", it.id).put("name", it.name) }))
        val keep = list.map { it.id }.toSet()
        root.optJSONObject("groups")?.let { g -> g.keys().asSequence().toList().filter { it !in keep }.forEach { g.remove(it) } }
    }

    fun saveGroups(communityId: String, list: List<CommunityGroup>) = update { root ->
        val g = root.optJSONObject("groups") ?: JSONObject().also { root.put("groups", it) }
        g.put(
            communityId,
            JSONArray(
                list.map {
                    JSONObject().put("id", it.id).put("name", it.name).put("announcement", it.announcement)
                        .put("general", it.general).put("members", it.members)
                },
            ),
        )
    }

    fun saveChannels(rows: List<Pair<Channel, List<ChannelPost>>>) = update { root ->
        root.put(
            "channels",
            JSONArray(
                rows.map { (c, posts) ->
                    JSONObject().put("id", c.id).put("name", c.name).put("description", c.description)
                        .put("subscribers", c.subscribers).put("verified", c.verified)
                        .put(
                            "posts",
                            JSONArray(
                                posts.map { p ->
                                    JSONObject().put("serverId", p.serverId).put("messageId", p.messageId)
                                        .put("timestampMs", p.timestampMs).put("text", p.text)
                                        .put("mediaKind", p.mediaKind).put("fileName", p.fileName)
                                        .put("thumb", if (p.thumbnail.isEmpty()) "" else Base64.encodeToString(p.thumbnail, Base64.NO_WRAP))
                                },
                            ),
                        )
                },
            ),
        )
    }

    fun clear() = synchronized(lock) { file.delete(); Unit }

    private fun read(): JSONObject =
        runCatching { if (file.exists()) JSONObject(file.readText()) else JSONObject() }.getOrDefault(JSONObject())

    private fun update(change: (JSONObject) -> Unit) {
        synchronized(lock) {
            runCatching {
                val root = read()
                change(root)
                val tmp = File(file.path + ".tmp")
                tmp.writeText(root.toString())
                if (!tmp.renameTo(file)) { file.delete(); tmp.renameTo(file) }
            }
        }
    }

    private fun JSONArray.objects(): List<JSONObject> = (0 until length()).map { getJSONObject(it) }
}
