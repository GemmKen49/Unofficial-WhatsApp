package com.classic.whatsapp.ui.communities

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.classic.whatsapp.ClassicApp
import com.classic.whatsapp.messaging.Channel
import com.classic.whatsapp.messaging.ChannelPost
import com.classic.whatsapp.messaging.Community
import com.classic.whatsapp.messaging.CommunityGroup
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class CommunitiesUi(
    val communities: List<Community>? = null,
    val loading: Boolean = false,
    val error: String? = null,
    val expanded: Set<String> = emptySet(),
    val groups: Map<String, List<CommunityGroup>> = emptyMap(),
    val loadingGroups: Set<String> = emptySet(),
    val groupErrors: Map<String, String> = emptyMap(),
)

data class ChannelRow(val channel: Channel, val posts: List<ChannelPost>) {
    val latest: ChannelPost? get() = posts.firstOrNull()
}

data class ChannelsUi(
    val rows: List<ChannelRow>? = null,
    val loading: Boolean = false,
    val error: String? = null,
    val expanded: Boolean = false,
)

class CommunitiesViewModel(app: Application) : AndroidViewModel(app) {
    private val repo = (app as ClassicApp).repo
    private val _state = MutableStateFlow(CommunitiesUi())
    val state: StateFlow<CommunitiesUi> = _state.asStateFlow()

    private val _channels = MutableStateFlow(ChannelsUi())
    val channels: StateFlow<ChannelsUi> = _channels.asStateFlow()

    /** Newest seen post per channel, to work out which channels have unread posts. */
    val seen: StateFlow<Map<String, Long>> = repo.channelSeen

    /** Fetches the community and channel lists once; later tab visits reuse them. */
    fun loadIfNeeded() {
        val s = _state.value
        if (s.communities == null && !s.loading) refresh()
        val c = _channels.value
        if (c.rows == null && !c.loading) loadChannels()
    }

    fun toggleChannels() = _channels.update { it.copy(expanded = !it.expanded) }

    /** Channels with their latest few posts. The first time a channel is seen, what it already has counts as read. */
    fun loadChannels() {
        if (_channels.value.loading) return
        _channels.update { it.copy(loading = true, error = null) }
        viewModelScope.launch {
            try {
                val rows = repo.channels().map { ch ->
                    val posts = try {
                        repo.channelPosts(ch.id, 5)
                    } catch (e: CancellationException) {
                        throw e
                    } catch (e: Exception) {
                        emptyList()
                    }
                    ChannelRow(ch, posts)
                }
                rows.forEach { r ->
                    if (repo.channelSeen.value[r.channel.id] == null) repo.markChannelSeen(r.channel.id, r.latest?.serverId ?: 0L)
                }
                _channels.update { it.copy(rows = rows, loading = false) }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                _channels.update { it.copy(loading = false, error = e.message ?: "Could not load channels") }
            }
        }
    }

    /** Re-fetches the list and every group list that was already loaded. */
    fun refresh() {
        loadChannels()
        if (_state.value.loading) return
        _state.update { it.copy(loading = true, error = null) }
        viewModelScope.launch {
            try {
                val list = repo.communities()
                _state.update { it.copy(communities = list, loading = false) }
                _state.value.groups.keys.filter { id -> list.any { it.id == id } }.forEach { loadGroups(it) }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                _state.update { it.copy(loading = false, error = e.message ?: "Could not load communities") }
            }
        }
    }

    fun toggle(id: String) {
        val open = id in _state.value.expanded
        _state.update { it.copy(expanded = if (open) it.expanded - id else it.expanded + id) }
        if (!open && id !in _state.value.groups) loadGroups(id)
    }

    fun loadGroups(id: String) {
        if (id in _state.value.loadingGroups) return
        _state.update { it.copy(loadingGroups = it.loadingGroups + id, groupErrors = it.groupErrors - id) }
        viewModelScope.launch {
            try {
                val list = repo.communityGroups(id)
                _state.update { it.copy(groups = it.groups + (id to list), loadingGroups = it.loadingGroups - id) }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                _state.update {
                    it.copy(
                        loadingGroups = it.loadingGroups - id,
                        groupErrors = it.groupErrors + (id to (e.message ?: "Could not load groups")),
                    )
                }
            }
        }
    }

    /** Ensures a local chat exists for the group and returns its chat id. */
    suspend fun chatFor(g: CommunityGroup): String = repo.openCommunityGroup(g)
}
