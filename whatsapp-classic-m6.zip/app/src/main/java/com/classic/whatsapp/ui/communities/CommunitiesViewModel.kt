package com.classic.whatsapp.ui.communities

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.classic.whatsapp.ClassicApp
import com.classic.whatsapp.messaging.Channel
import com.classic.whatsapp.messaging.ChannelPost
import com.classic.whatsapp.messaging.Community
import com.classic.whatsapp.messaging.CommunityGroup
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** [live] is false while the list is the saved copy from an earlier session (not yet refreshed from the server). */
data class CommunitiesUi(
    val communities: List<Community>? = null,
    val live: Boolean = false,
    val loading: Boolean = false,
    val error: String? = null,
    val expanded: Set<String> = emptySet(),
    val groups: Map<String, List<CommunityGroup>> = emptyMap(),
    val liveGroups: Set<String> = emptySet(),
    val loadingGroups: Set<String> = emptySet(),
    val groupErrors: Map<String, String> = emptyMap(),
)

data class ChannelRow(val channel: Channel, val posts: List<ChannelPost>) {
    val latest: ChannelPost? get() = posts.firstOrNull()
}

data class ChannelsUi(
    val rows: List<ChannelRow>? = null,
    val live: Boolean = false,
    val loading: Boolean = false,
    val error: String? = null,
    val expanded: Boolean = false,
)

/**
 * Communities and channels, offline-first: the saved copy is shown at once, and refreshed from the server whenever the
 * app is connected. A failed refresh never removes what is already on screen.
 */
class CommunitiesViewModel(app: Application) : AndroidViewModel(app) {
    private val classic = app as ClassicApp
    private val repo = classic.repo
    private val cache = repo.communityCache

    private val _state = MutableStateFlow(CommunitiesUi())
    val state: StateFlow<CommunitiesUi> = _state.asStateFlow()

    private val _channels = MutableStateFlow(ChannelsUi())
    val channels: StateFlow<ChannelsUi> = _channels.asStateFlow()

    /** Newest seen post per channel, to work out which channels have unread posts. */
    val seen: StateFlow<Map<String, Long>> = repo.channelSeen

    init {
        viewModelScope.launch {
            val saved = withContext(Dispatchers.IO) { cache.load() }
            // A refresh that already finished is newer than the saved copy: only fill what is still empty.
            _state.update {
                if (it.communities == null) it.copy(communities = saved.communities, groups = saved.groups + it.groups) else it
            }
            _channels.update {
                if (it.rows == null && saved.channels != null) it.copy(rows = saved.channels.map { (c, p) -> ChannelRow(c, p) }) else it
            }
        }
        // The tab can be opened before the socket is up (app start, reconnect): refresh as soon as it is connected.
        viewModelScope.launch {
            classic.status.collect { if (it == CONNECTED) loadIfNeeded() }
        }
    }

    /** Refreshes from the server once per session, when connected; offline the saved copy stays. */
    fun loadIfNeeded() {
        if (classic.status.value != CONNECTED) return
        if (!_state.value.live && !_state.value.loading) refresh()
        if (!_channels.value.live && !_channels.value.loading) loadChannels()
    }

    fun toggleChannels() = _channels.update { it.copy(expanded = !it.expanded) }

    /** Channels with their latest few posts. The first time a channel is seen, what it already has counts as read. */
    fun loadChannels() {
        if (_channels.value.loading) return
        _channels.update { it.copy(loading = true, error = null) }
        viewModelScope.launch {
            try {
                val rows = repo.channels().map { ch ->
                    val posts = try {
                        repo.channelPosts(ch.id, 5)
                    } catch (e: CancellationException) {
                        throw e
                    } catch (e: Exception) {
                        // keep what was saved for this channel rather than showing it empty
                        _channels.value.rows?.firstOrNull { it.channel.id == ch.id }?.posts.orEmpty()
                    }
                    ChannelRow(ch, posts)
                }
                rows.forEach { r ->
                    if (repo.channelSeen.value[r.channel.id] == null) repo.markChannelSeen(r.channel.id, r.latest?.serverId ?: 0L)
                }
                withContext(Dispatchers.IO) { cache.saveChannels(rows.map { it.channel to it.posts }) }
                _channels.update { it.copy(rows = rows, live = true, loading = false) }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                _channels.update { it.copy(loading = false, error = e.message ?: "Could not load channels") }
            }
        }
    }

    /** Re-fetches the lists and the groups of the communities that are expanded. */
    fun refresh() {
        loadChannels()
        if (_state.value.loading) return
        _state.update { it.copy(loading = true, error = null) }
        viewModelScope.launch {
            try {
                val list = repo.communities()
                withContext(Dispatchers.IO) { cache.saveCommunities(list) }
                val ids = list.map { it.id }.toSet()
                _state.update {
                    it.copy(
                        communities = list,
                        live = true,
                        loading = false,
                        groups = it.groups.filterKeys { k -> k in ids },
                        liveGroups = emptySet(), // saved group lists are stale again: re-fetched when expanded
                    )
                }
                _state.value.expanded.filter { it in ids }.forEach { loadGroups(it) }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                _state.update { it.copy(loading = false, error = e.message ?: "Could not load communities") }
            }
        }
    }

    fun toggle(id: String) {
        val open = id in _state.value.expanded
        _state.update { it.copy(expanded = if (open) it.expanded - id else it.expanded + id) }
        val s = _state.value
        // Offline with a saved group list: show it as is. Otherwise fetch (an error then shows with a Retry).
        if (!open && id !in s.liveGroups && (id !in s.groups || classic.status.value == CONNECTED)) loadGroups(id)
    }

    fun loadGroups(id: String) {
        if (id in _state.value.loadingGroups) return
        _state.update { it.copy(loadingGroups = it.loadingGroups + id, groupErrors = it.groupErrors - id) }
        viewModelScope.launch {
            try {
                val list = repo.communityGroups(id)
                withContext(Dispatchers.IO) { cache.saveGroups(id, list) }
                _state.update {
                    it.copy(groups = it.groups + (id to list), liveGroups = it.liveGroups + id, loadingGroups = it.loadingGroups - id)
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                _state.update {
                    it.copy(
                        loadingGroups = it.loadingGroups - id,
                        groupErrors = it.groupErrors + (id to (e.message ?: "Could not load groups")),
                    )
                }
            }
        }
    }

    private companion object {
        /** The value [ClassicApp.status] holds while the socket is up. */
        const val CONNECTED = "Connected"
    }

    /** Ensures a local chat exists for the group and returns its chat id. */
    suspend fun chatFor(g: CommunityGroup): String = repo.openCommunityGroup(g)
}
