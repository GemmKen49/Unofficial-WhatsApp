package com.classic.whatsapp.ui.communities

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.classic.whatsapp.ClassicApp
import com.classic.whatsapp.messaging.Community
import com.classic.whatsapp.messaging.CommunityGroup
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class CommunitiesUi(
    val communities: List<Community>? = null,
    val loading: Boolean = false,
    val error: String? = null,
    val expanded: Set<String> = emptySet(),
    val groups: Map<String, List<CommunityGroup>> = emptyMap(),
    val loadingGroups: Set<String> = emptySet(),
    val groupErrors: Map<String, String> = emptyMap(),
)

class CommunitiesViewModel(app: Application) : AndroidViewModel(app) {
    private val repo = (app as ClassicApp).repo
    private val _state = MutableStateFlow(CommunitiesUi())
    val state: StateFlow<CommunitiesUi> = _state.asStateFlow()

    /** Fetches the community list once; later tab visits reuse it. */
    fun loadIfNeeded() {
        val s = _state.value
        if (s.communities == null && !s.loading) refresh()
    }

    /** Re-fetches the list and every group list that was already loaded. */
    fun refresh() {
        if (_state.value.loading) return
        _state.update { it.copy(loading = true, error = null) }
        viewModelScope.launch {
            try {
                val list = repo.communities()
                _state.update { it.copy(communities = list, loading = false) }
                _state.value.groups.keys.filter { id -> list.any { it.id == id } }.forEach { loadGroups(it) }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                _state.update { it.copy(loading = false, error = e.message ?: "Could not load communities") }
            }
        }
    }

    fun toggle(id: String) {
        val open = id in _state.value.expanded
        _state.update { it.copy(expanded = if (open) it.expanded - id else it.expanded + id) }
        if (!open && id !in _state.value.groups) loadGroups(id)
    }

    fun loadGroups(id: String) {
        if (id in _state.value.loadingGroups) return
        _state.update { it.copy(loadingGroups = it.loadingGroups + id, groupErrors = it.groupErrors - id) }
        viewModelScope.launch {
            try {
                val list = repo.communityGroups(id)
                _state.update { it.copy(groups = it.groups + (id to list), loadingGroups = it.loadingGroups - id) }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                _state.update {
                    it.copy(
                        loadingGroups = it.loadingGroups - id,
                        groupErrors = it.groupErrors + (id to (e.message ?: "Could not load groups")),
                    )
                }
            }
        }
    }

    /** Ensures a local chat exists for the group and returns its chat id. */
    suspend fun chatFor(g: CommunityGroup): String = repo.openCommunityGroup(g)
}
