package com.classic.whatsapp.ui.communities

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.classic.whatsapp.messaging.Community
import com.classic.whatsapp.messaging.CommunityGroup
import com.classic.whatsapp.ui.formatTime
import kotlinx.coroutines.launch

/** Number of fetched posts newer than the last one the user saw in this channel. */
private fun unreadOf(row: ChannelRow, seen: Map<String, Long>): Int {
    val last = seen[row.channel.id] ?: return 0
    return row.posts.count { it.serverId > last }
}

/**
 * Browse-only view of the communities this account is in (tap a group to open it), plus a collapsible Channels slot that
 * jumps to the top of the list while any channel has unread posts and sits at the bottom otherwise.
 */
@Composable
fun CommunitiesScreen(
    onOpenChat: (String) -> Unit,
    onOpenChannel: (String) -> Unit,
    vm: CommunitiesViewModel = viewModel(),
) {
    val ui by vm.state.collectAsState()
    val ch by vm.channels.collectAsState()
    val seen by vm.seen.collectAsState()
    val scope = rememberCoroutineScope()
    LaunchedEffect(Unit) { vm.loadIfNeeded() }

    val rows = ch.rows.orEmpty()
        .sortedWith(
            compareByDescending<ChannelRow> { unreadOf(it, seen) > 0 }.thenByDescending { it.latest?.timestampMs ?: 0L },
        )
    val unreadTotal = rows.sumOf { unreadOf(it, seen) }
    val showChannels = rows.isNotEmpty() || ch.error != null
    val loading = ui.loading || ch.loading

    Column(Modifier.fillMaxSize().statusBarsPadding()) {
        Row(
            Modifier.fillMaxWidth().padding(start = 16.dp, end = 8.dp, top = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Column(Modifier.weight(1f)) {
                Text("Communities", style = MaterialTheme.typography.titleLarge)
                val saved = (ui.communities != null && !ui.live) || (ch.rows != null && !ch.live)
                if (loading && saved) Text("Updating…", style = MaterialTheme.typography.labelSmall)
                else if (saved) Text("Showing saved data", style = MaterialTheme.typography.labelSmall)
            }
            IconButton(enabled = !loading, onClick = { vm.refresh() }) {
                Icon(Icons.Default.Refresh, contentDescription = "Refresh")
            }
        }
        val list = ui.communities
        when {
            list == null && loading -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                CircularProgressIndicator()
            }
            list == null && !showChannels -> Message(
                (ui.error ?: "Waiting for connection…") + "\n\nTap refresh to try again.",
            )
            list != null && list.isEmpty() && !showChannels -> Message("You are not in any community.")
            else -> LazyColumn(Modifier.fillMaxSize()) {
                if (showChannels && unreadTotal > 0) {
                    item(key = "channels") {
                        ChannelsSlot(Modifier.animateItem(), ch, rows, seen, unreadTotal, vm::toggleChannels, vm::loadChannels, onOpenChannel)
                    }
                }
                items(list.orEmpty(), key = { it.id }) { c ->
                    CommunityBlock(
                        modifier = Modifier.animateItem(),
                        c = c,
                        expanded = c.id in ui.expanded,
                        groups = ui.groups[c.id],
                        loading = c.id in ui.loadingGroups,
                        error = ui.groupErrors[c.id],
                        onToggle = { vm.toggle(c.id) },
                        onRetry = { vm.loadGroups(c.id) },
                        onOpen = { g -> scope.launch { onOpenChat(vm.chatFor(g)) } },
                    )
                    HorizontalDivider()
                }
                if (showChannels && unreadTotal == 0) {
                    item(key = "channels") {
                        ChannelsSlot(Modifier.animateItem(), ch, rows, seen, unreadTotal, vm::toggleChannels, vm::loadChannels, onOpenChannel)
                    }
                }
            }
        }
    }
}

@Composable
private fun ChannelsSlot(
    modifier: Modifier,
    ch: ChannelsUi,
    rows: List<ChannelRow>,
    seen: Map<String, Long>,
    unreadTotal: Int,
    onToggle: () -> Unit,
    onRetry: () -> Unit,
    onOpen: (String) -> Unit,
) {
    Column(modifier.fillMaxWidth()) {
        Row(
            Modifier.fillMaxWidth().clickable(onClick = onToggle).padding(horizontal = 16.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Column(Modifier.weight(1f)) {
                Text("Channels", style = MaterialTheme.typography.titleMedium)
                Text(
                    when {
                        unreadTotal > 0 -> "New posts"
                        ch.error != null && rows.isEmpty() -> "Couldn't load channels"
                        else -> "${rows.size} followed"
                    },
                    style = MaterialTheme.typography.bodySmall,
                )
            }
            if (unreadTotal > 0) {
                CountBadge(unreadTotal, Modifier.padding(end = 12.dp))
            }
            Text(if (ch.expanded) "▲" else "▼", style = MaterialTheme.typography.labelMedium)
        }
        if (ch.expanded) {
            if (ch.error != null) {
                Column(Modifier.padding(horizontal = 32.dp, vertical = 8.dp)) {
                    Text(ch.error, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error)
                    TextButton(onClick = onRetry) { Text("Retry") }
                }
            }
            rows.forEach { row -> ChannelCard(row, unreadOf(row, seen)) { onOpen(row.channel.id) } }
            Spacer(Modifier.height(8.dp))
        }
        HorizontalDivider()
    }
}

@Composable
private fun ChannelCard(row: ChannelRow, unread: Int, onClick: () -> Unit) {
    Card(
        onClick = onClick,
        modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp),
    ) {
        Column(Modifier.padding(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier.size(40.dp).background(MaterialTheme.colorScheme.secondaryContainer, CircleShape),
                    contentAlignment = Alignment.Center,
                ) { Text(row.channel.name.take(1).uppercase(), style = MaterialTheme.typography.titleMedium) }
                Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            row.channel.name.ifBlank { "Channel" },
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = if (unread > 0) FontWeight.Bold else null,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.weight(1f, fill = false),
                        )
                        if (row.channel.verified) Text(" ✓", color = MaterialTheme.colorScheme.primary)
                    }
                    Text("${row.channel.subscribers} followers", style = MaterialTheme.typography.labelSmall)
                }
                if (unread > 0) CountBadge(unread)
            }
            row.latest?.let { post ->
                Spacer(Modifier.height(8.dp))
                Row(verticalAlignment = Alignment.Top) {
                    PostThumb(post, Modifier.padding(end = 10.dp).size(56.dp))
                    Column(Modifier.weight(1f)) {
                        Text(
                            post.text.ifBlank { mediaLabel(post) },
                            style = MaterialTheme.typography.bodyMedium,
                            maxLines = 3,
                            overflow = TextOverflow.Ellipsis,
                        )
                        Text(formatTime(post.timestampMs), style = MaterialTheme.typography.labelSmall)
                    }
                }
            }
        }
    }
}

@Composable
private fun Message(text: String) {
    Box(Modifier.fillMaxSize().padding(32.dp), contentAlignment = Alignment.Center) {
        Text(text, style = MaterialTheme.typography.bodyMedium)
    }
}

@Composable
private fun CommunityBlock(
    modifier: Modifier = Modifier,
    c: Community,
    expanded: Boolean,
    groups: List<CommunityGroup>?,
    loading: Boolean,
    error: String?,
    onToggle: () -> Unit,
    onRetry: () -> Unit,
    onOpen: (CommunityGroup) -> Unit,
) {
    Column(modifier.fillMaxWidth()) {
        Row(
            Modifier.fillMaxWidth().clickable(onClick = onToggle).padding(horizontal = 16.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Column(Modifier.weight(1f)) {
                Text(c.name.ifBlank { "Community" }, style = MaterialTheme.typography.titleMedium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(
                    groups?.let { "${it.size} group(s)" } ?: "Tap to show groups",
                    style = MaterialTheme.typography.bodySmall,
                )
            }
            Text(if (expanded) "▲" else "▼", style = MaterialTheme.typography.labelMedium)
        }
        if (expanded) {
            when {
                groups != null -> groups.forEach { g -> GroupRow(g, onClick = { onOpen(g) }) }
                loading -> Box(Modifier.fillMaxWidth().padding(16.dp), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator(Modifier.size(24.dp))
                }
                error != null -> Column(Modifier.padding(horizontal = 32.dp, vertical = 8.dp)) {
                    Text(error, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error)
                    TextButton(onClick = onRetry) { Text("Retry") }
                }
            }
        }
    }
}

@Composable
private fun GroupRow(g: CommunityGroup, onClick: () -> Unit) {
    Column(Modifier.fillMaxWidth().clickable(onClick = onClick).padding(start = 32.dp, end = 16.dp, top = 10.dp, bottom = 10.dp)) {
        Text(
            g.name.ifBlank { "Group" },
            style = MaterialTheme.typography.bodyLarge,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
        )
        val tag = when {
            g.announcement -> "Announcements"
            g.general -> "General"
            else -> "Group"
        }
        Text(
            if (g.members > 0) "$tag · ${g.members} members" else tag,
            style = MaterialTheme.typography.bodySmall,
        )
    }
}
