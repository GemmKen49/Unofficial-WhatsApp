package com.classic.whatsapp.ui.communities

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.classic.whatsapp.data.ChatEntity
import com.classic.whatsapp.messaging.Community
import com.classic.whatsapp.messaging.CommunityGroup
import com.classic.whatsapp.ui.formatTime
import kotlinx.coroutines.launch

/**
 * Communities (browse only; tap a group to open it) plus a collapsible Channels slot. The slot jumps to the top of the list
 * while any channel has unread posts and sits at the bottom otherwise.
 */
@Composable
fun CommunitiesScreen(
    onOpenChat: (String) -> Unit,
    onOpenChannel: (String) -> Unit,
    vm: CommunitiesViewModel = viewModel(),
) {
    val ui by vm.state.collectAsState()
    val channelChats by vm.channelChats.collectAsState()
    val channelsOpen by vm.channelsExpanded.collectAsState()
    val scope = rememberCoroutineScope()
    LaunchedEffect(Unit) { vm.loadIfNeeded() }

    val channels = channelChats.sortedWith(
        compareByDescending<ChatEntity> { it.unread > 0 }.thenByDescending { it.lastTimestamp },
    )
    val unreadTotal = channels.sumOf { it.unread }
    val showChannels = channels.isNotEmpty()
    val list = ui.communities

    Column(Modifier.fillMaxSize().statusBarsPadding()) {
        Row(
            Modifier.fillMaxWidth().padding(start = 16.dp, end = 8.dp, top = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Column(Modifier.weight(1f)) {
                Text("Communities", style = MaterialTheme.typography.titleLarge)
                val saved = list != null && !ui.live
                if (ui.loading && saved) Text("Updating…", style = MaterialTheme.typography.labelSmall)
                else if (saved) Text("Showing saved data", style = MaterialTheme.typography.labelSmall)
            }
            IconButton(enabled = !ui.loading, onClick = { vm.refresh() }) {
                Icon(Icons.Default.Refresh, contentDescription = "Refresh")
            }
        }
        when {
            list == null && !showChannels && ui.loading -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                CircularProgressIndicator()
            }
            list == null && !showChannels -> Message((ui.error ?: "Waiting for connection…") + "\n\nTap refresh to try again.")
            list != null && list.isEmpty() && !showChannels -> Message("You are not in any community.")
            else -> LazyColumn(Modifier.fillMaxSize()) {
                if (showChannels && unreadTotal > 0) {
                    item(key = "channels") {
                        ChannelsSlot(Modifier.animateItem(), channels, unreadTotal, channelsOpen, vm::toggleChannels, onOpenChannel)
                    }
                }
                if (list == null) {
                    item(key = "communities-status") {
                        Box(Modifier.fillMaxWidth().padding(24.dp), contentAlignment = Alignment.Center) {
                            if (ui.loading) CircularProgressIndicator(Modifier.size(24.dp))
                            else Text(ui.error ?: "Waiting for connection…", style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
                items(list.orEmpty(), key = { it.id }) { c ->
                    CommunityBlock(
                        modifier = Modifier.animateItem(),
                        c = c,
                        expanded = c.id in ui.expanded,
                        groups = ui.groups[c.id],
                        loading = c.id in ui.loadingGroups,
                        error = ui.groupErrors[c.id],
                        onToggle = { vm.toggle(c.id) },
                        onRetry = { vm.loadGroups(c.id) },
                        onOpen = { g -> scope.launch { onOpenChat(vm.chatFor(g)) } },
                    )
                    HorizontalDivider()
                }
                if (showChannels && unreadTotal == 0) {
                    item(key = "channels") {
                        ChannelsSlot(Modifier.animateItem(), channels, unreadTotal, channelsOpen, vm::toggleChannels, onOpenChannel)
                    }
                }
            }
        }
    }
}

@Composable
private fun ChannelsSlot(
    modifier: Modifier,
    channels: List<ChatEntity>,
    unreadTotal: Int,
    expanded: Boolean,
    onToggle: () -> Unit,
    onOpen: (String) -> Unit,
) {
    Column(modifier.fillMaxWidth()) {
        Row(
            Modifier.fillMaxWidth().clickable(onClick = onToggle).padding(horizontal = 16.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Column(Modifier.weight(1f)) {
                Text("Channels", style = MaterialTheme.typography.titleMedium)
                Text(if (unreadTotal > 0) "New posts" else "${channels.size} followed", style = MaterialTheme.typography.bodySmall)
            }
            if (unreadTotal > 0) CountBadge(unreadTotal, Modifier.padding(end = 12.dp))
            Text(if (expanded) "▲" else "▼", style = MaterialTheme.typography.labelMedium)
        }
        if (expanded) {
            channels.forEach { c -> ChannelCard(c) { onOpen(c.chatId) } }
            Spacer(Modifier.height(8.dp))
        }
        HorizontalDivider()
    }
}

@Composable
private fun ChannelCard(chat: ChatEntity, onClick: () -> Unit) {
    val unread = chat.unread > 0
    Card(onClick = onClick, modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp)) {
        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier.size(40.dp).background(MaterialTheme.colorScheme.secondaryContainer, CircleShape),
                contentAlignment = Alignment.Center,
            ) { Text(chat.displayTitle.take(1).uppercase(), style = MaterialTheme.typography.titleMedium) }
            Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
                Text(
                    chat.displayTitle,
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = if (unread) FontWeight.Bold else null,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
                if (chat.lastText.isNotBlank()) {
                    Text(chat.lastText, style = MaterialTheme.typography.bodyMedium, maxLines = 3, overflow = TextOverflow.Ellipsis)
                }
            }
            Column(horizontalAlignment = Alignment.End) {
                if (chat.lastTimestamp > 0) Text(formatTime(chat.lastTimestamp), style = MaterialTheme.typography.labelSmall)
                if (unread) CountBadge(chat.unread, Modifier.padding(top = 4.dp))
            }
        }
    }
}

@Composable
private fun Message(text: String) {
    Box(Modifier.fillMaxSize().padding(32.dp), contentAlignment = Alignment.Center) {
        Text(text, style = MaterialTheme.typography.bodyMedium)
    }
}

@Composable
private fun CommunityBlock(
    modifier: Modifier = Modifier,
    c: Community,
    expanded: Boolean,
    groups: List<CommunityGroup>?,
    loading: Boolean,
    error: String?,
    onToggle: () -> Unit,
    onRetry: () -> Unit,
    onOpen: (CommunityGroup) -> Unit,
) {
    Column(modifier.fillMaxWidth()) {
        Row(
            Modifier.fillMaxWidth().clickable(onClick = onToggle).padding(horizontal = 16.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Column(Modifier.weight(1f)) {
                Text(c.name.ifBlank { "Community" }, style = MaterialTheme.typography.titleMedium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(
                    groups?.let { "${it.size} group(s)" } ?: "Tap to show groups",
                    style = MaterialTheme.typography.bodySmall,
                )
            }
            Text(if (expanded) "▲" else "▼", style = MaterialTheme.typography.labelMedium)
        }
        if (expanded) {
            when {
                groups != null -> groups.forEach { g -> GroupRow(g, onClick = { onOpen(g) }) }
                loading -> Box(Modifier.fillMaxWidth().padding(16.dp), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator(Modifier.size(24.dp))
                }
                error != null -> Column(Modifier.padding(horizontal = 32.dp, vertical = 8.dp)) {
                    Text(error, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error)
                    TextButton(onClick = onRetry) { Text("Retry") }
                }
            }
        }
    }
}

@Composable
private fun GroupRow(g: CommunityGroup, onClick: () -> Unit) {
    Column(Modifier.fillMaxWidth().clickable(onClick = onClick).padding(start = 32.dp, end = 16.dp, top = 10.dp, bottom = 10.dp)) {
        Text(
            g.name.ifBlank { "Group" },
            style = MaterialTheme.typography.bodyLarge,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
        )
        val tag = when {
            g.announcement -> "Announcements"
            g.general -> "General"
            else -> "Group"
        }
        Text(
            if (g.members > 0) "$tag · ${g.members} members" else tag,
            style = MaterialTheme.typography.bodySmall,
        )
    }
}
