package com.classic.whatsapp.ui.communities

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.classic.whatsapp.messaging.Community
import com.classic.whatsapp.messaging.CommunityGroup
import kotlinx.coroutines.launch

/** Browse-only view of the communities this account is in; tapping a group opens its conversation. */
@Composable
fun CommunitiesScreen(onOpenChat: (String) -> Unit, vm: CommunitiesViewModel = viewModel()) {
    val ui by vm.state.collectAsState()
    val scope = rememberCoroutineScope()
    LaunchedEffect(Unit) { vm.loadIfNeeded() }

    Column(Modifier.fillMaxSize().statusBarsPadding()) {
        Row(
            Modifier.fillMaxWidth().padding(start = 16.dp, end = 8.dp, top = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text("Communities", style = MaterialTheme.typography.titleLarge, modifier = Modifier.weight(1f))
            IconButton(enabled = !ui.loading, onClick = { vm.refresh() }) {
                Icon(Icons.Default.Refresh, contentDescription = "Refresh")
            }
        }
        val list = ui.communities
        when {
            list == null && ui.loading -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                CircularProgressIndicator()
            }
            list == null -> Message(
                (ui.error ?: "Not loaded yet") + "\n\nTap refresh to try again.",
            )
            list.isEmpty() -> Message("You are not in any community.")
            else -> LazyColumn(Modifier.fillMaxSize()) {
                items(list, key = { it.id }) { c ->
                    CommunityBlock(
                        c = c,
                        expanded = c.id in ui.expanded,
                        groups = ui.groups[c.id],
                        loading = c.id in ui.loadingGroups,
                        error = ui.groupErrors[c.id],
                        onToggle = { vm.toggle(c.id) },
                        onRetry = { vm.loadGroups(c.id) },
                        onOpen = { g -> scope.launch { onOpenChat(vm.chatFor(g)) } },
                    )
                    HorizontalDivider()
                }
            }
        }
    }
}

@Composable
private fun Message(text: String) {
    Box(Modifier.fillMaxSize().padding(32.dp), contentAlignment = Alignment.Center) {
        Text(text, style = MaterialTheme.typography.bodyMedium)
    }
}

@Composable
private fun CommunityBlock(
    c: Community,
    expanded: Boolean,
    groups: List<CommunityGroup>?,
    loading: Boolean,
    error: String?,
    onToggle: () -> Unit,
    onRetry: () -> Unit,
    onOpen: (CommunityGroup) -> Unit,
) {
    Column(Modifier.fillMaxWidth()) {
        Row(
            Modifier.fillMaxWidth().clickable(onClick = onToggle).padding(horizontal = 16.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Column(Modifier.weight(1f)) {
                Text(c.name.ifBlank { "Community" }, style = MaterialTheme.typography.titleMedium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(
                    groups?.let { "${it.size} group(s)" } ?: "Tap to show groups",
                    style = MaterialTheme.typography.bodySmall,
                )
            }
            Text(if (expanded) "▲" else "▼", style = MaterialTheme.typography.labelMedium)
        }
        if (expanded) {
            when {
                loading -> Box(Modifier.fillMaxWidth().padding(16.dp), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator(Modifier.size(24.dp))
                }
                error != null -> Column(Modifier.padding(horizontal = 32.dp, vertical = 8.dp)) {
                    Text(error, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error)
                    TextButton(onClick = onRetry) { Text("Retry") }
                }
                groups != null -> groups.forEach { g -> GroupRow(g, onClick = { onOpen(g) }) }
            }
        }
    }
}

@Composable
private fun GroupRow(g: CommunityGroup, onClick: () -> Unit) {
    Column(Modifier.fillMaxWidth().clickable(onClick = onClick).padding(start = 32.dp, end = 16.dp, top = 10.dp, bottom = 10.dp)) {
        Text(
            g.name.ifBlank { "Group" },
            style = MaterialTheme.typography.bodyLarge,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
        )
        val tag = when {
            g.announcement -> "Announcements"
            g.general -> "General"
            else -> "Group"
        }
        Text(
            if (g.members > 0) "$tag · ${g.members} members" else tag,
            style = MaterialTheme.typography.bodySmall,
        )
    }
}
