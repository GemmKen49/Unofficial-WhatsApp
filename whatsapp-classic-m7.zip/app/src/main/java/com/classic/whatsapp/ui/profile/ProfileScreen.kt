package com.classic.whatsapp.ui.profile

import android.graphics.BitmapFactory
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.classic.whatsapp.ClassicApp
import com.classic.whatsapp.data.MediaFiles
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private const val ABOUT_MAX = 139

/** Edit the own display name, About text and profile picture. The current server values are not read back. */
@Composable
fun ProfileScreen(onBack: () -> Unit) {
    val ctx = LocalContext.current
    val app = ctx.applicationContext as ClassicApp
    val repo = app.repo
    val scope = rememberCoroutineScope()
    val savedName by app.settings.profileName.collectAsState()
    val savedAbout by app.settings.profileAbout.collectAsState()
    var name by remember { mutableStateOf(savedName) }
    var about by remember { mutableStateOf(savedAbout) }
    var busy by remember { mutableStateOf(false) }
    var photoRev by remember { mutableIntStateOf(0) }
    val photo = remember(photoRev) {
        repo.profilePhotoFile.takeIf { it.exists() }?.let { BitmapFactory.decodeFile(it.path)?.asImageBitmap() }
    }

    fun toast(text: String) = Toast.makeText(ctx, text, Toast.LENGTH_SHORT).show()

    /** Runs a profile change; shows the result and keeps the screen locked while it runs. */
    fun run(done: String, block: suspend () -> Unit) {
        if (busy) return
        busy = true
        scope.launch {
            try {
                block()
                photoRev++
                toast(done)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                toast(e.message ?: "Could not update the profile")
            } finally {
                busy = false
            }
        }
    }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) run("Profile picture updated") {
            val jpeg = withContext(Dispatchers.IO) { MediaFiles.profileJpeg(ctx, uri) } ?: throw IllegalStateException("Could not read that image")
            repo.setProfilePicture(jpeg)
        }
    }

    Column(Modifier.fillMaxSize().statusBarsPadding().verticalScroll(rememberScrollState())) {
        Row(Modifier.fillMaxWidth().padding(end = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back") }
            Text("Profile", style = MaterialTheme.typography.titleLarge)
        }
        Column(Modifier.padding(horizontal = 24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Box(
                Modifier.size(120.dp).clip(CircleShape).background(MaterialTheme.colorScheme.secondaryContainer),
                contentAlignment = Alignment.Center,
            ) {
                if (photo != null) Image(photo, contentDescription = null, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
                else Text(name.take(1).uppercase().ifBlank { "?" }, style = MaterialTheme.typography.displayMedium)
            }
            Row(Modifier.padding(top = 12.dp)) {
                OutlinedButton(enabled = !busy, onClick = { picker.launch("image/*") }) { Text("Change photo") }
                Spacer(Modifier.width(8.dp))
                OutlinedButton(enabled = !busy && photo != null, onClick = { run("Profile picture removed") { repo.removeProfilePicture() } }) {
                    Text("Remove")
                }
            }
            OutlinedTextField(
                value = name,
                onValueChange = { name = it.take(25) },
                label = { Text("Display name") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth().padding(top = 24.dp),
            )
            OutlinedTextField(
                value = about,
                onValueChange = { about = it.take(ABOUT_MAX) },
                label = { Text("About") },
                supportingText = { Text("${about.length}/$ABOUT_MAX") },
                modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
            )
            Button(
                enabled = !busy && name.isNotBlank() && (name.trim() != savedName || about.trim() != savedAbout),
                onClick = {
                    run("Profile saved") {
                        if (name.trim() != savedName) repo.setDisplayName(name.trim())
                        if (about.trim() != savedAbout) repo.setAbout(about.trim())
                    }
                },
                modifier = Modifier.padding(top = 16.dp),
            ) { Text(if (busy) "Saving…" else "Save") }
            Text(
                "Needs a connection. Shows what you last set here; the current values on your account are not read back.",
                style = MaterialTheme.typography.bodySmall,
                modifier = Modifier.padding(top = 12.dp, bottom = 24.dp),
            )
        }
    }
}
