package com.classic.whatsapp.ui.contacts

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.classic.whatsapp.ClassicApp
import com.classic.whatsapp.data.SavedContactEntity
import kotlinx.coroutines.launch

/** The app's own address book (name + number, stored only on this device). Tap a contact to open a chat with it. */
@Composable
fun ContactsScreen(onBack: () -> Unit, onOpenChat: (String) -> Unit) {
    val repo = (LocalContext.current.applicationContext as ClassicApp).repo
    val scope = rememberCoroutineScope()
    val contacts by repo.savedContacts.collectAsState(initial = emptyList())
    var adding by remember { mutableStateOf(false) }
    var editing by remember { mutableStateOf<SavedContactEntity?>(null) }

    Column(Modifier.fillMaxSize().statusBarsPadding()) {
        Row(Modifier.fillMaxWidth().padding(end = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back") }
            Text("Contacts", style = MaterialTheme.typography.titleLarge, modifier = Modifier.weight(1f))
            IconButton(onClick = { adding = true }) { Icon(Icons.Default.Add, contentDescription = "Add contact") }
        }
        if (contacts.isEmpty()) {
            Box(Modifier.fillMaxSize().padding(32.dp), contentAlignment = Alignment.Center) {
                Text("No contacts yet. Tap + to add one.", style = MaterialTheme.typography.bodyMedium)
            }
        } else {
            LazyColumn(Modifier.fillMaxSize()) {
                items(contacts, key = { it.jid }) { c ->
                    Row(
                        Modifier.fillMaxWidth()
                            .clickable { scope.launch { onOpenChat(repo.createChat(c.number)) } }
                            .padding(start = 16.dp, top = 8.dp, bottom = 8.dp, end = 4.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Column(Modifier.weight(1f)) {
                            Text(c.name, style = MaterialTheme.typography.titleMedium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text("+${c.number}", style = MaterialTheme.typography.bodySmall)
                        }
                        TextButton(onClick = { editing = c }) { Text("Edit") }
                    }
                    HorizontalDivider()
                }
            }
        }
    }

    if (adding || editing != null) {
        val initial = editing
        ContactDialog(
            initial = initial,
            onDismiss = { adding = false; editing = null },
            onSave = { name, digits ->
                adding = false
                editing = null
                scope.launch { repo.saveContact(name, digits, oldJid = initial?.jid) }
            },
            onDelete = initial?.let { c ->
                val delete: () -> Unit = {
                    editing = null
                    scope.launch { repo.deleteContact(c.jid) }
                }
                delete
            },
        )
    }
}

@Composable
private fun ContactDialog(
    initial: SavedContactEntity?,
    onDismiss: () -> Unit,
    onSave: (name: String, digits: String) -> Unit,
    onDelete: (() -> Unit)?,
) {
    var name by remember { mutableStateOf(initial?.name.orEmpty()) }
    var digits by remember { mutableStateOf(initial?.number.orEmpty()) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (initial == null) "New contact" else "Edit contact") },
        text = {
            Column {
                OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Name") }, singleLine = true)
                OutlinedTextField(
                    value = digits,
                    onValueChange = { digits = it.filter(Char::isDigit) },
                    label = { Text("Number with country code") },
                    prefix = { Text("+") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                    modifier = Modifier.padding(top = 8.dp),
                )
            }
        },
        confirmButton = {
            TextButton(enabled = name.isNotBlank() && digits.length in 8..15, onClick = { onSave(name.trim(), digits) }) { Text("Save") }
        },
        dismissButton = {
            Row {
                if (onDelete != null) TextButton(onClick = onDelete) { Text("Delete") }
                TextButton(onClick = onDismiss) { Text("Cancel") }
            }
        },
    )
}
