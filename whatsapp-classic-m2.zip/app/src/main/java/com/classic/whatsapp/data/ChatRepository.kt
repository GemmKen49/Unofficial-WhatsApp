package com.classic.whatsapp.data

import android.database.sqlite.SQLiteConstraintException
import androidx.room.withTransaction
import com.classic.whatsapp.messaging.MessagingClient
import com.classic.whatsapp.messaging.MessagingEvent
import java.util.UUID
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow

class ChatRepository(private val db: AppDatabase, private val client: MessagingClient) {
    private val dao = db.dao()

    val chats: Flow<List<ChatEntity>> = dao.observeChats()
    fun chat(chatId: String): Flow<ChatEntity?> = dao.observeChat(chatId)
    fun messages(chatId: String): Flow<List<MessageEntity>> = dao.observeMessages(chatId)

    /** Chat currently on screen (no unread count / notification for it). */
    val openChatId = MutableStateFlow<String?>(null)

    suspend fun openChat(chatId: String) {
        openChatId.value = chatId
        dao.markRead(chatId)
    }

    fun closeChat() {
        openChatId.value = null
    }

    suspend fun title(chatId: String): String = dao.getChat(chatId)?.title ?: chatId.substringBefore('@')

    /** Creates (if missing) a 1:1 chat for a phone number given as digits with country code. */
    suspend fun createChat(digits: String): String {
        val chatId = "$digits@s.whatsapp.net"
        if (dao.getChat(chatId) == null) {
            dao.upsertChat(ChatEntity(chatId, digits, false, "", System.currentTimeMillis(), 0))
        }
        return chatId
    }

    /** Returns true if the message was new. */
    suspend fun onIncoming(m: MessagingEvent.MessageReceived): Boolean = db.withTransaction {
        val msg = MessageEntity(
            chatId = m.chatId,
            messageId = m.messageId,
            senderId = m.senderId,
            senderName = if (m.fromMe) "" else m.pushName.ifBlank { m.senderId.substringBefore('@') },
            text = m.text,
            timestamp = m.timestampMs,
            fromMe = m.fromMe,
            status = STATUS_SENT,
        )
        if (dao.insertMessage(msg) == -1L) return@withTransaction false

        val existing = dao.getChat(m.chatId)
        val title = when {
            !m.isGroup && !m.fromMe && m.pushName.isNotBlank() -> m.pushName
            existing != null -> existing.title
            m.isGroup -> "Group"
            else -> m.chatId.substringBefore('@')
        }
        val isNewest = existing == null || m.timestampMs >= existing.lastTimestamp
        val unread = (existing?.unread ?: 0) + if (!m.fromMe && openChatId.value != m.chatId) 1 else 0
        dao.upsertChat(
            ChatEntity(
                chatId = m.chatId,
                title = title,
                isGroup = m.isGroup,
                lastText = if (isNewest) preview(m.text, m.fromMe) else existing!!.lastText,
                lastTimestamp = if (isNewest) m.timestampMs else existing!!.lastTimestamp,
                unread = unread,
            ),
        )
        true
    }

    suspend fun sendText(chatId: String, text: String) {
        val tempId = "local-" + UUID.randomUUID()
        val now = System.currentTimeMillis()
        db.withTransaction {
            dao.insertMessage(MessageEntity(chatId, tempId, "", "", text, now, true, STATUS_SENDING))
            val existing = dao.getChat(chatId)
                ?: ChatEntity(chatId, chatId.substringBefore('@'), chatId.endsWith("@g.us"), "", 0, 0)
            dao.upsertChat(existing.copy(lastText = preview(text, true), lastTimestamp = now))
        }
        try {
            val realId = client.sendText(chatId, text)
            try {
                dao.rekeyMessage(chatId, tempId, realId, STATUS_SENT)
            } catch (e: SQLiteConstraintException) {
                dao.deleteMessage(chatId, tempId) // the echo of our own message was stored first
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            dao.setStatus(chatId, tempId, STATUS_FAILED)
        }
    }

    private fun preview(text: String, fromMe: Boolean) = if (fromMe) "You: $text" else text
}
