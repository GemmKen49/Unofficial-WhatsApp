package com.classic.whatsapp.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface ChatDao {
    @Query("SELECT * FROM chats ORDER BY lastTimestamp DESC")
    fun observeChats(): Flow<List<ChatEntity>>

    @Query("SELECT * FROM chats WHERE chatId = :chatId")
    fun observeChat(chatId: String): Flow<ChatEntity?>

    @Query("SELECT * FROM chats WHERE chatId = :chatId")
    suspend fun getChat(chatId: String): ChatEntity?

    @Query("SELECT * FROM messages WHERE chatId = :chatId ORDER BY timestamp ASC")
    fun observeMessages(chatId: String): Flow<List<MessageEntity>>

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertMessage(m: MessageEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertChat(c: ChatEntity)

    @Query("UPDATE chats SET unread = 0 WHERE chatId = :chatId")
    suspend fun markRead(chatId: String)

    @Query("UPDATE messages SET messageId = :newId, status = :status WHERE chatId = :chatId AND messageId = :oldId")
    suspend fun rekeyMessage(chatId: String, oldId: String, newId: String, status: Int)

    @Query("UPDATE messages SET status = :status WHERE chatId = :chatId AND messageId = :id")
    suspend fun setStatus(chatId: String, id: String, status: Int)

    @Query("DELETE FROM messages WHERE chatId = :chatId AND messageId = :id")
    suspend fun deleteMessage(chatId: String, id: String)
}
