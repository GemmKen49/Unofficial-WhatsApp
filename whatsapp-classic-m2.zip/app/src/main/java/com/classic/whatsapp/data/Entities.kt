package com.classic.whatsapp.data

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

const val STATUS_SENDING = 0
const val STATUS_SENT = 1
const val STATUS_FAILED = 2

@Entity(tableName = "chats")
data class ChatEntity(
    @PrimaryKey val chatId: String,
    val title: String,
    val isGroup: Boolean,
    val lastText: String,
    val lastTimestamp: Long,
    val unread: Int,
)

@Entity(
    tableName = "messages",
    primaryKeys = ["chatId", "messageId"],
    indices = [Index("chatId", "timestamp")],
)
data class MessageEntity(
    val chatId: String,
    val messageId: String,
    val senderId: String,
    val senderName: String,
    val text: String,
    val timestamp: Long,
    val fromMe: Boolean,
    val status: Int,
)
