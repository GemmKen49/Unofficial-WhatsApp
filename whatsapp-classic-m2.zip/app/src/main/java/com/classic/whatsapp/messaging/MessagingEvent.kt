package com.classic.whatsapp.messaging

/** Stable app-level events. Never expose upstream protocol types to the UI. */
sealed interface MessagingEvent {
    data class PairingCode(val code: String, val expiresInSeconds: Long) : MessagingEvent
    data class PairingQr(val payload: String) : MessagingEvent
    data object Paired : MessagingEvent
    data class PairFailed(val reason: String) : MessagingEvent
    data object Connected : MessagingEvent
    data object Disconnected : MessagingEvent
    data object LoggedOut : MessagingEvent
    data class Fatal(val reason: String) : MessagingEvent
    data class MessageReceived(
        val chatId: String,
        val senderId: String,
        val messageId: String,
        val text: String,
        val timestampMs: Long,
        val fromMe: Boolean,
        val isGroup: Boolean,
        val pushName: String,
    ) : MessagingEvent
}
