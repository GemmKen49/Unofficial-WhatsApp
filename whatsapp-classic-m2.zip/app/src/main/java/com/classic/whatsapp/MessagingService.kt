package com.classic.whatsapp

import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.net.ConnectivityManager
import android.net.Network
import android.os.IBinder

/**
 * Keeps the process (and therefore the Rust WhatsApp connection) alive.
 * There is no push service: this foreground service IS the delivery mechanism.
 */
class MessagingService : Service() {
    private val app get() = application as ClassicApp
    private lateinit var cm: ConnectivityManager

    private val networkCallback = object : ConnectivityManager.NetworkCallback() {
        override fun onAvailable(network: Network) {
            // Reconnect after the engine gave up (e.g. long outage). Upstream handles short drops itself.
            if (app.session.linked.value && !app.messaging.isRunning) app.messaging.start()
        }
    }

    override fun onCreate() {
        super.onCreate()
        Notifier.ensureChannels(this)
        startForeground(Notifier.FGS_ID, Notifier.foreground(this), ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        if (app.session.linked.value) app.messaging.start()
        cm = getSystemService(ConnectivityManager::class.java)
        cm.registerDefaultNetworkCallback(networkCallback)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_STICKY

    override fun onDestroy() {
        runCatching { cm.unregisterNetworkCallback(networkCallback) }
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
