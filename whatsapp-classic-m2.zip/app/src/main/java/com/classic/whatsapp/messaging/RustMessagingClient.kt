package com.classic.whatsapp.messaging

import java.io.File
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.CoroutineStart
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeout
import uniffi.whatsapp_classic_engine.Engine
import uniffi.whatsapp_classic_engine.EngineEvent
import uniffi.whatsapp_classic_engine.EngineListener

/** Adapter between the UniFFI-generated Rust engine and the app's stable API. */
class RustMessagingClient(private val dataDir: File) : MessagingClient {

    private val _events = MutableSharedFlow<MessagingEvent>(extraBufferCapacity = 4096)
    override val events: SharedFlow<MessagingEvent> = _events.asSharedFlow()

    private val listener = object : EngineListener {
        override fun onEvent(event: EngineEvent) {
            _events.tryEmit(event.toDomain())
        }
    }

    private val engine: Engine by lazy {
        dataDir.mkdirs()
        Engine(dataDir.absolutePath, listener)
    }

    override val isRunning: Boolean get() = engine.isRunning()

    override fun start() = engine.start(null)

    override fun stop() = engine.stop()

    override suspend fun requestPairingCode(phoneNumber: String): MessagingEvent.PairingCode =
        withContext(Dispatchers.IO) {
            coroutineScope {
                val result = CompletableDeferred<MessagingEvent.PairingCode>()
                // UNDISPATCHED: subscribe before the engine can emit anything.
                val collector = launch(start = CoroutineStart.UNDISPATCHED) {
                    events.collect { e ->
                        when (e) {
                            is MessagingEvent.PairingCode -> result.complete(e)
                            is MessagingEvent.PairFailed -> result.completeExceptionally(PairingException(e.reason))
                            is MessagingEvent.Fatal -> result.completeExceptionally(PairingException(e.reason))
                            else -> Unit
                        }
                    }
                }
                try {
                    engine.stop()
                    engine.start(phoneNumber)
                    withTimeout(90_000) { result.await() }
                } finally {
                    collector.cancel()
                }
            }
        }

    override suspend fun sendText(chatId: String, text: String): String =
        withContext(Dispatchers.IO) { engine.sendText(chatId, text) }

    override suspend fun clearSession() = withContext(Dispatchers.IO) {
        engine.stop()
        delay(500) // let the aborted task release the database
        engine.clearSession()
    }
}

private fun EngineEvent.toDomain(): MessagingEvent = when (this) {
    is EngineEvent.PairingCode -> MessagingEvent.PairingCode(code, timeoutSecs.toLong())
    is EngineEvent.PairingQr -> MessagingEvent.PairingQr(code)
    is EngineEvent.Paired -> MessagingEvent.Paired
    is EngineEvent.PairFailed -> MessagingEvent.PairFailed(reason)
    is EngineEvent.Connected -> MessagingEvent.Connected
    is EngineEvent.Disconnected -> MessagingEvent.Disconnected
    is EngineEvent.LoggedOut -> MessagingEvent.LoggedOut
    is EngineEvent.Fatal -> MessagingEvent.Fatal(reason)
    is EngineEvent.MessageReceived -> MessagingEvent.MessageReceived(
        chatId = chatId,
        senderId = senderId,
        messageId = messageId,
        text = text,
        timestampMs = timestampMs,
        fromMe = fromMe,
        isGroup = isGroup,
        pushName = pushName,
    )
}
