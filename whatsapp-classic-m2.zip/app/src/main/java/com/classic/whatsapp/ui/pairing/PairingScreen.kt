package com.classic.whatsapp.ui.pairing

import android.os.SystemClock
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.TextButton
import androidx.compose.ui.Alignment
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.text.KeyboardOptions
import androidx.lifecycle.viewmodel.compose.viewModel
import kotlinx.coroutines.delay

private val COUNTRIES = listOf(
    "United States / Canada" to "1", "United Kingdom" to "44", "Germany" to "49", "France" to "33",
    "Spain" to "34", "Italy" to "39", "Netherlands" to "31", "Belgium" to "32", "Switzerland" to "41",
    "Austria" to "43", "Portugal" to "351", "Ireland" to "353", "Sweden" to "46", "Norway" to "47",
    "Denmark" to "45", "Finland" to "358", "Poland" to "48", "Czechia" to "420", "Romania" to "40",
    "Greece" to "30", "Turkey" to "90", "Russia / Kazakhstan" to "7", "Ukraine" to "380",
    "Israel" to "972", "Saudi Arabia" to "966", "UAE" to "971", "Egypt" to "20", "Nigeria" to "234",
    "South Africa" to "27", "Kenya" to "254", "India" to "91", "Pakistan" to "92", "Bangladesh" to "880",
    "Indonesia" to "62", "Malaysia" to "60", "Singapore" to "65", "Philippines" to "63", "Thailand" to "66",
    "Vietnam" to "84", "China" to "86", "Hong Kong" to "852", "Japan" to "81", "South Korea" to "82",
    "Australia" to "61", "New Zealand" to "64", "Mexico" to "52", "Brazil" to "55", "Argentina" to "54",
    "Colombia" to "57", "Chile" to "56",
)

@Composable
fun PairingScreen(vm: PairingViewModel = viewModel()) {
    val state by vm.state.collectAsState()
    var code by remember { mutableStateOf("") }
    var countryName by remember { mutableStateOf<String?>(null) }
    var number by remember { mutableStateOf("") }
    var menuOpen by remember { mutableStateOf(false) }
    val busy = state is PairingUiState.Requesting
    val canRequest = !busy && code.isNotEmpty() && number.isNotEmpty()

    Column(
        Modifier.fillMaxSize().statusBarsPadding().verticalScroll(rememberScrollState()).padding(24.dp),
    ) {
        Text("Link this device", style = MaterialTheme.typography.headlineSmall)
        Text(
            "Enter the number of your existing WhatsApp account. This app registers as an unofficial " +
                "Electron companion device; account restrictions are possible.",
            style = MaterialTheme.typography.bodySmall,
            modifier = Modifier.padding(top = 8.dp, bottom = 24.dp),
        )

        // Country code: type it manually, or pick a country to fill it in.
        Row(verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(
                value = code,
                onValueChange = { code = it.filter(Char::isDigit).take(4); countryName = null },
                label = { Text("Code") },
                prefix = { Text("+") },
                singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                modifier = Modifier.width(110.dp),
            )
            Box(Modifier.padding(start = 12.dp)) {
                TextButton(onClick = { menuOpen = true }) { Text(countryName ?: "Pick a country") }
                DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                    COUNTRIES.forEach { c ->
                        DropdownMenuItem(
                            text = { Text("${c.first} (+${c.second})") },
                            onClick = { code = c.second; countryName = c.first; menuOpen = false },
                        )
                    }
                }
            }
        }

        OutlinedTextField(
            value = number,
            onValueChange = { number = it.filter(Char::isDigit) },
            label = { Text("Phone number (without country code)") },
            singleLine = true,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
            modifier = Modifier.fillMaxWidth().padding(top = 12.dp),
        )

        Button(
            onClick = { vm.request(code, number) },
            enabled = canRequest,
            modifier = Modifier.padding(top = 16.dp),
        ) { Text(if (busy) "Requesting…" else "Request pairing code") }

        Spacer(Modifier.height(24.dp))

        when (val s = state) {
            is PairingUiState.CodeReady -> CodeCard(s, onRetry = { vm.request(code, number) })
            is PairingUiState.Failed -> {
                Text(s.message, color = MaterialTheme.colorScheme.error)
                OutlinedButton(onClick = { vm.request(code, number) }, modifier = Modifier.padding(top = 8.dp)) {
                    Text("Retry")
                }
            }
            else -> Unit
        }
    }
}

@Composable
private fun CodeCard(s: PairingUiState.CodeReady, onRetry: () -> Unit) {
    var remaining by remember(s) { mutableLongStateOf((s.expiresAtElapsed - SystemClock.elapsedRealtime()) / 1000) }
    LaunchedEffect(s) {
        while (remaining > 0) {
            delay(1000)
            remaining = (s.expiresAtElapsed - SystemClock.elapsedRealtime()) / 1000
        }
    }
    Column {
        Text(
            s.code.chunked(4).joinToString("-"),
            fontFamily = FontFamily.Monospace,
            fontSize = 36.sp,
            style = MaterialTheme.typography.headlineMedium,
        )
        Text(
            "In the official WhatsApp: Settings > Linked devices > Link a device > " +
                "Link with phone number instead, then enter this code.",
            style = MaterialTheme.typography.bodyMedium,
            modifier = Modifier.padding(top = 12.dp),
        )
        Row(Modifier.padding(top = 12.dp)) {
            if (remaining > 0) {
                Text("Waiting for approval… ${remaining}s left", style = MaterialTheme.typography.bodySmall)
            } else {
                Text("Code expired.", color = MaterialTheme.colorScheme.error)
            }
        }
        OutlinedButton(onClick = onRetry, modifier = Modifier.padding(top = 8.dp)) { Text("Get a new code") }
    }
}
