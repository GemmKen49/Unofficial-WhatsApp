package com.classic.whatsapp.ui

import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.format.DateTimeFormatter

private val TIME = DateTimeFormatter.ofPattern("HH:mm")
private val DATE = DateTimeFormatter.ofPattern("d MMM")

/** HH:mm for today, "d MMM" otherwise. */
fun formatTime(ms: Long): String {
    if (ms <= 0) return ""
    val zone = ZoneId.systemDefault()
    val t = Instant.ofEpochMilli(ms).atZone(zone)
    return if (t.toLocalDate() == LocalDate.now(zone)) t.format(TIME) else t.format(DATE)
}
