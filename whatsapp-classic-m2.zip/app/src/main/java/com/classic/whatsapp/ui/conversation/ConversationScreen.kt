package com.classic.whatsapp.ui.conversation

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.classic.whatsapp.ClassicApp
import com.classic.whatsapp.Notifier
import com.classic.whatsapp.data.ChatEntity
import com.classic.whatsapp.data.MessageEntity
import com.classic.whatsapp.data.STATUS_FAILED
import com.classic.whatsapp.data.STATUS_SENDING
import com.classic.whatsapp.ui.formatTime
import kotlinx.coroutines.launch

@Composable
fun ConversationScreen(chatId: String, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val app = ctx.applicationContext as ClassicApp
    val messages by app.repo.messages(chatId).collectAsState(initial = emptyList())
    val chat by app.repo.chat(chatId).collectAsState(initial = null as ChatEntity?)
    val scope = rememberCoroutineScope()
    var draft by remember { mutableStateOf("") }

    LaunchedEffect(chatId) {
        app.repo.openChat(chatId)
        Notifier.cancel(ctx, chatId)
    }
    DisposableEffect(chatId) { onDispose { app.repo.closeChat() } }

    Column(Modifier.fillMaxSize().statusBarsPadding().imePadding()) {
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(end = 16.dp)) {
            IconButton(onClick = onBack) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
            }
            Text(chat?.title ?: chatId.substringBefore('@'), style = MaterialTheme.typography.titleMedium)
        }
        HorizontalDivider()

        LazyColumn(
            modifier = Modifier.weight(1f).fillMaxWidth(),
            reverseLayout = true,
            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp),
        ) {
            items(messages.asReversed(), key = { it.messageId }) { m -> Bubble(m, chat?.isGroup == true) }
        }

        Row(
            Modifier.fillMaxWidth().padding(8.dp),
            verticalAlignment = Alignment.Bottom,
        ) {
            OutlinedTextField(
                value = draft,
                onValueChange = { draft = it },
                placeholder = { Text("Message") },
                maxLines = 5,
                modifier = Modifier.weight(1f),
            )
            IconButton(
                enabled = draft.isNotBlank(),
                onClick = {
                    val text = draft.trim()
                    draft = ""
                    scope.launch { app.repo.sendText(chatId, text) }
                },
            ) { Icon(Icons.AutoMirrored.Filled.Send, contentDescription = "Send") }
        }
    }
}

@Composable
private fun Bubble(m: MessageEntity, isGroup: Boolean) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = if (m.fromMe) Arrangement.End else Arrangement.Start) {
        Surface(
            shape = RoundedCornerShape(6.dp),
            color = if (m.fromMe) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant,
            modifier = Modifier.widthIn(max = 300.dp),
        ) {
            Column(Modifier.padding(horizontal = 10.dp, vertical = 6.dp)) {
                if (isGroup && !m.fromMe && m.senderName.isNotBlank()) {
                    Text(m.senderName, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
                }
                Text(m.text, style = MaterialTheme.typography.bodyMedium)
                val meta = when (m.status) {
                    STATUS_SENDING -> "sending…"
                    STATUS_FAILED -> "failed to send"
                    else -> formatTime(m.timestamp)
                }
                Text(
                    meta,
                    style = MaterialTheme.typography.labelSmall,
                    color = if (m.status == STATUS_FAILED) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.align(Alignment.End),
                )
            }
        }
    }
}
