package com.classic.whatsapp

import android.app.Application
import android.content.Intent
import androidx.core.content.ContextCompat
import com.classic.whatsapp.data.AppDatabase
import com.classic.whatsapp.data.ChatRepository
import com.classic.whatsapp.data.SessionStore
import com.classic.whatsapp.messaging.MessagingClient
import com.classic.whatsapp.messaging.MessagingEvent
import com.classic.whatsapp.messaging.RustMessagingClient
import java.io.File
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class ClassicApp : Application() {
    lateinit var session: SessionStore
        private set
    lateinit var messaging: MessagingClient
        private set
    lateinit var db: AppDatabase
        private set
    lateinit var repo: ChatRepository
        private set

    /** Chat id requested by a notification tap; consumed by the navigation host. */
    val openRequest = MutableStateFlow<String?>(null)

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private val _status = MutableStateFlow("Not connected")
    val status: StateFlow<String> = _status.asStateFlow()

    override fun onCreate() {
        super.onCreate()
        session = SessionStore(this)
        messaging = RustMessagingClient(File(filesDir, "wa"))
        db = AppDatabase.create(this)
        repo = ChatRepository(db, messaging)
        Notifier.ensureChannels(this)

        scope.launch {
            messaging.events.collect { e ->
                when (e) {
                    is MessagingEvent.Paired -> {
                        session.setLinked(true)
                        _status.value = "Linked, connecting…"
                        ensureService() // app is in the foreground here, so this is allowed
                    }
                    is MessagingEvent.Connected -> _status.value = "Connected"
                    is MessagingEvent.Disconnected -> _status.value = "Disconnected, retrying…"
                    is MessagingEvent.LoggedOut -> {
                        session.setLinked(false)
                        stopService(Intent(this@ClassicApp, MessagingService::class.java))
                        _status.value = "Logged out from phone"
                    }
                    is MessagingEvent.Fatal -> _status.value = "Error: ${e.reason}"
                    is MessagingEvent.MessageReceived -> {
                        val isNew = repo.onIncoming(e)
                        if (isNew && !e.fromMe && repo.openChatId.value != e.chatId) {
                            val who = if (e.isGroup) "${e.pushName.ifBlank { e.senderId.substringBefore('@') }}: " else ""
                            Notifier.message(this@ClassicApp, e.chatId, repo.title(e.chatId), who + e.text, e.timestampMs)
                        }
                    }
                    else -> Unit
                }
            }
        }
        if (session.linked.value) _status.value = "Connecting…"
    }

    /** Starts the foreground service (which starts the engine) if this device is linked. */
    fun ensureService() {
        if (session.linked.value) {
            ContextCompat.startForegroundService(this, Intent(this, MessagingService::class.java))
        }
    }

    /** Disconnect, delete the Rust session and all local chats. */
    suspend fun clearEverything() {
        stopService(Intent(this, MessagingService::class.java))
        messaging.clearSession()
        withContext(Dispatchers.IO) { db.clearAllTables() }
        session.setLinked(false)
        _status.value = "Not connected"
    }
}
