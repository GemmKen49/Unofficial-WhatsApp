package com.classic.whatsapp.messaging

import kotlinx.coroutines.flow.SharedFlow

class PairingException(message: String) : Exception(message)

/** App-level messaging surface. Media/groups are added in later milestones. */
interface MessagingClient {
    val events: SharedFlow<MessagingEvent>
    val isRunning: Boolean

    /** Resume an existing linked-device session. */
    fun start()
    fun stop()

    /** Starts a fresh pairing attempt; returns when the code arrives. */
    suspend fun requestPairingCode(phoneNumber: String): MessagingEvent.PairingCode

    /** Sends a text message; returns the server-side message id. */
    suspend fun sendText(chatId: String, text: String): String

    /** Stops the engine and deletes the local session database. */
    suspend fun clearSession()
}
