# Known limitations

- **Companion identity: Electron.** Pairing registers as an Electron (desktop-type) companion via
  `PairCodeOptions.platform_id`. Android companion types need server-side attestation upstream and are not used.
  The official app lists this device as a desktop/web-type device.
- **Unofficial client.** Account restrictions or bans are possible.
- **Rust adapter partly verified.** Dependencies compile; adapter fixed against compiler errors (Backend by value, Arc<Event>, PairingCode struct). Kotlin side never compiled.
  signatures (`Bot::builder`, `with_runtime`, `Event` variants, `SqliteStore`) may need small fixes.
- **Cargo features unverified:** `SqliteStore` / transport re-exports assumed to be in default features.
- **Android build of the Rust tree unverified** (bundled SQLite and TLS crypto need NDK clang).
- **No background service yet.** The connection lives only while the process lives (Milestone 2: foreground service).
- **Storage:** session DB is in app-private storage (`filesDir/wa/whatsapp.db`), not Keystore-wrapped yet.
  Backups are excluded via manifest rules.
- **Linked-device rules:** the primary phone (official WhatsApp, user 1) must connect at least about every 14 days.
- **GrapheneOS profiles:** unverified whether user 0 keeps its connection alive and posts notifications while user 1 is active.
- **SIMD disabled.** Upstream's `simd` feature needs nightly Rust, so it is turned off (slower binary parsing only).
  If the build still pulls `simd` through another crate, switch CI to `dtolnay/rust-toolchain@nightly`.
- Upstream requires Rust >= 1.94 (edition 2024); CI uses the latest stable.

## Milestone 2 notes
- **Unverified:** `.on_message(...)` and `.on_event(...)` are both registered on the bot builder; I assume they coexist
  (upstream uses an event bus with multiple handlers). If messages never arrive, this is the first suspect.
- **Text only.** Media, reactions, edits and other message kinds are ignored (no placeholder).
- **No history sync.** The chat list starts empty and fills from messages received while connected (plus messages
  sent from your phone). Use "+" to start a chat by number.
- **Names:** contact names are WhatsApp push names seen on incoming messages; groups are titled "Group".
- **No delivery/read receipts.** Sent messages show a time once the server accepted them.
- **Chats are stored unencrypted** in app-private storage (Room), like the session DB.
- **Background:** foreground service (`specialUse`), boot start, reconnect on network change. Battery-optimization
  exemption is requested from Settings. Behaviour while GrapheneOS user 1 is active is untested.
- Sending to `@lid` chats and to phone-number chats created via "+" is untested.
- Failed sends show "failed to send"; there is no retry button yet.
